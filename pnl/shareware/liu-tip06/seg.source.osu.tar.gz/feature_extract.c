#define  FEATURE_EXTRACT_SOURCE_C_C

#include "feature_extract.h"
#if !defined(DELTA)
# define DELTA 1e-9
#endif

/***********************************************************
							    
   Compute histogram of a local window

********************************************************/

/* Neighborhood system */
POINT2D Neighbor_Table[] = {
  {0,-1},  /* 0 */
  {-1,-1}, /* 1 */
  {-1,0},  /* 2 */
  {-1,+1}, /* 3 */
  {0,1},   /* 4 */
  {1,1},   /* 5 */
  {1,0},   /* 6 */
  {1,-1},  /* 7 */
  {0,0}    /* 8 */
};



void Homogeous_Between_Test_Before(FILTERBANK *ffamily,
				   IMAGEINT *animage)
{
  int k;
  float *histTmp[2];
  float diverge;
  int row[2], col[2];
  int windex;
  float *tmpRes;
  
  tmpRes = (float *)malloc(sizeof(float)*ffamily->nfilter);
  for (k=0; k<2; k++) 
    histTmp[k] = (float *)malloc(sizeof(float)*ffamily->totalBin);
  do {
    printf("Please specify the window level (1->%d): ",
	   ffamily->nlevel);
    scanf("%d", &windex);
    if (windex < 1 || windex > ffamily->nlevel) break;
    windex--;
    printf("Please input two pixels (col, row): ");
    for (k=0; k<2; k++) {
      scanf("%d%d", &(col[k]), &(row[k]));
      Compute_Local_Window_Hist(row[k],col[k],windex,
				ffamily, animage, histTmp[k]);
      Print_Pixel_Feature_Vector(row[k], col[k],  histTmp[k], 
				 ffamily, windex);
    }
    diverge = 0.0;
   
    for (k=0; k < ffamily->nfilter; k++) {
      tmpRes[k] = Calc_Hist_Divergence_AFilter(&(histTmp[0][0]),
					 &(histTmp[1][0]),
					 k,
					 ffamily);
      
      diverge += tmpRes[k];
    }
    printf("Divergence for each filter: ");
    for (k=0; k < ffamily->nfilter; k++) {
      printf("%8.6f ", tmpRes[k]);
    }
    printf("Total: %8.6f\n", diverge);
    diverge = 0.0;
    for (k=0; k < ffamily->nfilter; k++) {
      tmpRes[k] = Calc_Hist_Chi_AFilter(&(histTmp[0][0]),
					&(histTmp[1][0]),
					k,
					ffamily);
      
      diverge += tmpRes[k];
    }
    printf("Chi Distance for each filter: ");
    for (k=0; k < ffamily->nfilter; k++) {
      printf("%8.6f ", tmpRes[k]);
    }
    printf("Total: %8.6f\n", diverge);
    
    printf("Total divergence and chi dist between (%d,%d) and (%d,%d) ",
	   col[0], row[0], col[1], row[1]);
    printf("at level %d (%d x %d) is ", windex+1,
	   ffamily->winLevels[windex].x*2+1,
	   ffamily->winLevels[windex].y*2+1);
    
    diverge = Calc_Hist_Divergence(&(histTmp[0][0]),
				   &(histTmp[1][0]),
				   ffamily->totalBin);
    printf("%8.6f and %8.6f.\n", diverge,
	   Calc_Hist_Chi(&(histTmp[1][0]),
			 &(histTmp[0][0]),
			 ffamily->totalBin));
  } while(1);
  for (k=0; k<2; k++)
    free(histTmp[k]);
  return;
}

void Homogeous_Layer_Test_Before(FILTERBANK *ffamily,
				 IMAGEINT *animage,
				 CONTROL_INFO *controlInfo)
{
  int i, j, k;
  float **histTmp;
  int windex;
  float *tmpRes;
  IMAGEFLOAT segImg;
  IMAGEFLOAT probImg;
  IMAGEINT  labelImg;
  REGION_LABEL  regLabels[MAX_LABEL_IMAGE];
  int           segOrder[MAX_LABEL_IMAGE];
  int nextLab;
  char fname[256], comm[256];


  segImg.nrow = 0;
  probImg.nrow = 0;
  Create_An_Image_Float(animage->nrow, animage->ncol, &segImg);
  labelImg.nrow = 0;
  Create_An_Image_Int(animage->nrow, animage->ncol, &labelImg);
  for (k=0; k<MAX_LABEL_IMAGE; k++) {
    regLabels[k].resImg.nrow = 0;
    regLabels[k].label = 0;
  }
  
  for (i=0; i<animage->nrow; i++) {
    for (j=0; j<animage->ncol; j++) {
      labelImg.data[i][j] = 0;
    }
  }
  
  tmpRes = (float *)malloc(sizeof(float)*ffamily->nlevel);
  histTmp = (float **)malloc(sizeof(float *)*ffamily->nlevel);
  for (k=0; k < ffamily->nlevel; k++) 
    histTmp[k] = (float *)malloc(sizeof(float)*ffamily->totalBin);
  
  for (i=0; i<animage->nrow; i++) {
    for (j=0; j<animage->ncol; j++) {
      labelImg.data[i][j] = 0;
    }
  }
  

  windex = controlInfo->topWin;
  printf("The upper level is %d out of (1->%d).\n",
	 controlInfo->topWin+1,
	 ffamily->nlevel);
  if (controlInfo->npoint ==0) {
    printf("How many seed points to extract: ");
    scanf("%d", &(controlInfo->npoint));
    printf("Enter %d points in col row format: ");
    for (k=0; k< controlInfo->npoint; k++) {
      scanf("%d%d",&(controlInfo->seedPoints[k].x), 
	    &(controlInfo->seedPoints[k].y));
    }
  }
  
  for (i=0; i< controlInfo->npoint; i++) {
    for (k=0; k<= windex; k++) {
      Compute_Local_Window_Hist(controlInfo->seedPoints[i].y,
				controlInfo->seedPoints[i].x,
				k,
				ffamily, animage, histTmp[k]); 
    }
    
    for (k=1; k <= windex; k++) {
      tmpRes[k-1] = Calc_Hist_Divergence(histTmp[k-1],
					 histTmp[k],
					 ffamily->totalBin);
    }
    printf("Divergence between layers at (%d, %d): \n\t", 
	   controlInfo->seedPoints[i].x,
	   controlInfo->seedPoints[i].y);
    for (k=0; k < windex; k++) {
      printf("%8.6f ", tmpRes[k]);
    }
    printf("\n");
  }
  
  printf("Window for segmentation of the regions is %d.\n",
	   controlInfo->segWin+1);
  printf("The relax factor for background is %8.2f.\n",
	 controlInfo->lammda);
  
  printf("There are in total %d points (col, row format). \n", 
	 controlInfo->npoint);
  for (k=0; k<controlInfo->npoint; k++) {
    printf("\t%d, %d\n", controlInfo->seedPoints[k].x, 
	   controlInfo->seedPoints[k].y);
  }
  nextLab = 1;
  for (k=0; k<controlInfo->npoint; k++) {
    regLabels[nextLab].label = nextLab;
    regLabels[nextLab].lammda = controlInfo->lammda;
    Estimate_Region_Parameter(controlInfo->seedPoints[k].y,
			      controlInfo->seedPoints[k].x,
			      controlInfo->segWin,
			      ffamily, animage, 
			      &labelImg, &(regLabels[nextLab]));
    sprintf(fname,"%s_div_%d.pgm", controlInfo->prefix, nextLab);
    Write_An_Image_Float(&(regLabels[nextLab].resImg), fname); 
    Compute_Prob_Image(&(regLabels[nextLab]), &probImg);
    sprintf(fname,"%s_prob_%d.pgm", controlInfo->prefix, nextLab);
    Write_An_Image_Float(&probImg, fname); 
    nextLab++;
    if (nextLab >= MAX_LABEL_IMAGE) {
      printf("Exceeds the maximum of labels per image. ");
      printf("Increase MAX_LABEL_IMAGE and recompile.\n");
      exit(-1);
    }
    
  }
  for (k=1; k < nextLab; k++) {
    segOrder[k-1] = k;
  }
  do {
    i = 0;
    for (k=0; k < (nextLab-2); k++) {
      if ( regLabels[segOrder[k]].peakVal > 
	   regLabels[segOrder[k+1]].peakVal ) {
	i = segOrder[k];
	segOrder[k] = segOrder[k+1];
	segOrder[k+1] = i;
	i = 1;
      }
    }
  } while (i);
  printf("Labels will be processed in the following order: \n");
  for (k=0; k < (nextLab-1); k++) {
    printf("   %d -> ", segOrder[k]);
    i = segOrder[k];
    printf("Region %d, %d: threshold: %6.4f refLev: %d refWin: %d wsize: %d",
	   regLabels[i].seed_col,
	   regLabels[i].seed_row,
	   regLabels[i].threshold,
	   regLabels[i].refWin,
	   regLabels[i].refWsize,
	   regLabels[i].wsize);
    printf(" Peak val: %6.4f regThres: %6.2f Lammda: %6.2f\n", 
	   regLabels[i].peakVal, regLabels[i].regThres,
	   regLabels[i].lammda);
    printf("\tProb Hist (len=%d unit=%6.4f): ", regLabels[i].histLen,
	   regLabels[i].histUnit);
    for(j=0; j < regLabels[i].histLen; j++) {
      printf("%6.4f ", regLabels[i].probHist[j]);
    }
    printf("\n");
  }
  if (controlInfo->refinedWin) {
    /* Use the refined window and redo the parameter estimation */
    for (k=0; k < (nextLab-1); k++) {
      i = segOrder[k];
      /* regLabels[i].lammda = controlInfo->lammda; */
      Free_Array(regLabels[i].fvector);
      Free_Array(regLabels[i].refineVec);
      Free_Array(regLabels[i].probHist);
      
      Estimate_Region_Parameter(regLabels[i].seed_row,
				regLabels[i].seed_col,
				regLabels[i].refWin,
				ffamily, animage, 
				&labelImg, &(regLabels[i]));
      
      
    }
    printf("Updated version: ");
    printf("Labels will be processed in the following order: \n");
    for (k=0; k < (nextLab-1); k++) {
      printf("   %d -> ", segOrder[k]);
      i = segOrder[k];
      printf("Region %d, %d: threshold: %6.4f segLev: %d segWin: %d wsize: %d",
	     regLabels[i].seed_col,
	     regLabels[i].seed_row,
	     regLabels[i].threshold,
	     regLabels[i].segWin,
	     regLabels[i].refWsize,
	     regLabels[i].wsize);
      printf(" Peak val: %6.4f regThres: %6.2f Lammda: %6.2f\n", 
	     regLabels[i].peakVal, regLabels[i].regThres,
	     regLabels[i].lammda);
      printf("\tProb Hist (len=%d unit=%6.4f): ", regLabels[i].histLen,
	     regLabels[i].histUnit);
      for(j=0; j < regLabels[i].histLen; j++) {
	printf("%6.4f ", regLabels[i].probHist[j]);
      }
      printf("\n");
    }
  }
  for (i=0; i<animage->nrow; i++) {
    for (j=0; j<animage->ncol; j++) {
      labelImg.data[i][j] = 0;
    }
  }
  for (k=0; k < (nextLab-1); k++) {  
    i = segOrder[k];
    Extract_OneRegion(&(regLabels[0]),
		      &labelImg,
		      regLabels[i].threshold,
		      regLabels[i].label,
		      (int)(regLabels[i].regThres+0.5));
    
  }
  for (k=0; k < (nextLab-1); k++) {
    i = segOrder[k];
    Remove_Not_Calc_Points(&(regLabels[i]));
    
  }
  /*  
  for (k=0; k < (nextLab-1); k++) {
    i = segOrder[k];
    sprintf(fname,"%s_div_%d.pgm", controlInfo->prefix, i);
    Write_An_Image_Float(&(regLabels[i].resImg), fname);
  }
  */
  
  sprintf(fname,"%s_Init_Label.pgm",controlInfo->prefix);
  Write_An_Image_Int(&labelImg, (int)(256/(nextLab)), fname);
  return;
  sprintf(comm,"xv %s &\n", fname);
  /* system(comm); */
  Refine_Region_Boundary(&(regLabels[0]),
			 nextLab,
			 &labelImg,
			 animage,
			 ffamily, 
			 controlInfo);
  
  sprintf(fname,"%s_Final_Label.pgm",controlInfo->prefix);
  Write_An_Image_Int(&labelImg, (int)(256/(nextLab)), fname);
  /* sprintf(comm,"xv %s &\n", fname);
  system(comm); */
  
  
  for (k=0; k< ffamily->nlevel; k++)
    free(histTmp[k]);
  free(histTmp);
  free(tmpRes);
  
  
  Free_Image_Int(&labelImg);
  for (k=0; k<MAX_LABEL_IMAGE; k++) {
    if (regLabels[k].label > 0) {
      Free_Image_Float(&(regLabels[k].resImg));
      Free_Array(regLabels[k].fvector);
      Free_Array(regLabels[k].refineVec);
      Free_Array(regLabels[k].probHist);
    }
  }
  return;
}


void Homogeous_Between_Test_After(int windex,
				  FILTERBANK *ffamily,
				  IMAGEINT *animage,
				  IMAGEVECTOR *featureImg)
{
  int k;
  float diverge;
  int row[2], col[2];
  int srow[2], scol[2];
  int max_row, max_col;
  max_row = animage->nrow-featureImg->wsize_y-1;
  max_col = animage->ncol-featureImg->wsize_x-1;
  printf("Performance pixel-pair similarity test.\n");
  do {
    printf("Please input two pixels (col: %d->%d, row: %d->%d): ",
	   featureImg->wsize_x, max_col,
	   featureImg->wsize_y, max_row);
    scanf("%d",&(col[0]));
    if (col[0] < featureImg->wsize_x || col[0] > max_col) {
      fflush(stdin);
      break;
    }
    scanf("%d",&(row[0]));
    if (row[0] < featureImg->wsize_y || row[0] > max_row) {
      fflush(stdin);
      break;
    }
    scanf("%d",&(col[1]));
    if (col[1] < featureImg->wsize_x || col[1] > max_col) {
      fflush(stdin);
      break;
    }
    scanf("%d",&(row[1]));
    if (row[1] < featureImg->wsize_y || row[1] > max_row) {
      fflush(stdin);
      break;
    }
    
    for (k=0; k<2; k++) {
      srow[k] = row[k]-featureImg->wsize_y;
      scol[k] = col[k]-featureImg->wsize_x;
      Print_Pixel_Feature_Vector(row[k], col[k],  
				 featureImg->data[srow[k]][scol[k]],
				 ffamily, windex);
    }
    printf("Divergence and Chi distance between (%d,%d) and (%d,%d) ",
	   col[0], row[0], col[1], row[1]);
    printf("at level %d (%d x %d) are ", windex+1,
	   ffamily->winLevels[windex].x*2+1,
	   ffamily->winLevels[windex].y*2+1);
    diverge = 
      Calc_Hist_Divergence(featureImg->data[srow[0]][scol[0]],
			   featureImg->data[srow[1]][scol[1]],
			   ffamily->totalBin);
    printf("%8.6f and %8.6f.\n", diverge,
	   Calc_Hist_Chi(featureImg->data[srow[0]][scol[0]],
			 featureImg->data[srow[1]][scol[1]],
			 ffamily->totalBin));
  } while(1);
  
  return;
}

void Print_Pixel_Feature_Vector(int row, int col, 
				float *hist,
				FILTERBANK *ffamily, 
				int windex)
{
  int startDim =0;
  int k,i;
  printf("Feature vector at pixel (%d,%d) ", col, row);
  printf("at level %d with size %d, %d.\n",
	 windex+1, 2*ffamily->winLevels[windex].x+1,
	 2*ffamily->winLevels[windex].y+1);
  for (k=0; k < ffamily->nfilter; k++) {
    printf("Filter %2d -> ", ffamily->fbank[k].id);
    for (i=0; i < ffamily->fbank[k].bin_num; i++) {
      printf("%8.6f ", hist[i+startDim]);
    }
    printf("\n");
    startDim += ffamily->fbank[k].bin_num;
  }
}


void Calc_Between_Layer_Div(int windex,
			    int upindex,
			    FILTERBANK *ffamily,
			    IMAGEINT *animage,
			    IMAGEFLOAT *layerDiv)
{
  
  float *histTmp[2];
  int i, j;
  int bound_x, bound_y;
 
  for (i=0; i<2; i++) 
    histTmp[i] = (float *)malloc(sizeof(float)*ffamily->totalBin);
  bound_x = ffamily->winLevels[upindex].x+
    ffamily->max_wid;
  bound_y = ffamily->winLevels[upindex].y+
    ffamily->max_ht;
  printf("Computing Divergence between level %d(%d,%d) ",
	 windex+1, ffamily->winLevels[windex].x*2+1,
	 ffamily->winLevels[windex].y*2+1);
  printf("and %d(%d,%d). \n", upindex+1,
	 ffamily->winLevels[upindex].x*2+1,
	 ffamily->winLevels[upindex].y*2+1);
  for (i = bound_y; i < (animage->nrow-bound_y); i++) {
    printf("%3d ",i);
    if ((i+1-bound_y)%18==0) printf("\n");
    else
      fflush(stdout);
    
    for (j=bound_x; j < (animage->ncol-bound_x); j++) {
      Compute_Local_Window_Hist_Inside(i,j, windex,
				       ffamily, animage,
				       histTmp[0]);
      Compute_Local_Window_Hist_Inside(i,j, upindex,
				       ffamily, animage,
				       histTmp[1]);
      layerDiv->data[i-bound_y][j-bound_x] =  
	Calc_Hist_Divergence(histTmp[0],
			     histTmp[1],
			     ffamily->totalBin);
      
    }
  }
  printf("\n");
  for (i=0; i<2; i++) 
    free(histTmp[i]);
  return;
}




void Check_Connection_After(int windex,
			    FILTERBANK *ffamily,
			    IMAGEINT *animage,
			    IMAGEVECTOR *featureImg)
{
  int k;
  float diverge[8];
  float chi[8];
  int row[2], col[2];
  int srow[2], scol[2];
  
  int max_row, max_col;
  max_row = animage->nrow - featureImg->wsize_y-1;
  max_col = animage->ncol - featureImg->wsize_x-1;
  printf("Performing lateral connection testing.\n");
  do {
    printf("Please input a pixel (col: %d->%d, row: %d->%d): ",
	   featureImg->wsize_x, max_col,
	   featureImg->wsize_y, max_row);
    scanf("%d",&(col[0]));
    if (col[0] < featureImg->wsize_x || col[0] > max_col) {
      fflush(stdin);
      break;
    }
    scanf("%d",&(row[0]));
    if (row[0] < featureImg->wsize_y || row[0] > max_row) {
      fflush(stdin);
      break;
    }
    srow[0] = row[0] - featureImg->wsize_y;
    scol[0] = col[0] - featureImg->wsize_x;
    Print_Pixel_Feature_Vector(row[0], col[0],  
			       featureImg->data[srow[0]][scol[0]],
			       ffamily, windex);
    for (k=0; k<8; k++) {
      col[1] = col[0] + Neighbor_Table[k].x;
      diverge[k] = -1;
      chi[k] = -1;
      if (col[1] < featureImg->wsize_x || col[1] > max_col) {
	continue;
      }
      row[1] = row[0] + Neighbor_Table[k].y;
      if (row[1] < featureImg->wsize_y || row[1] > max_row) {
	continue;
      }
      srow[1] = row[1] - featureImg->wsize_y;
      scol[1] = col[1] - featureImg->wsize_x;
      
      diverge[k] = Calc_Hist_Divergence(featureImg->data[srow[0]][scol[0]],
					featureImg->data[srow[1]][scol[1]],
					ffamily->totalBin);
      chi[k] = Calc_Hist_Chi(featureImg->data[srow[0]][scol[0]],
			     featureImg->data[srow[1]][scol[1]],
			     ffamily->totalBin);
    }
    printf("Divergence: "); 
    for (k=0; k<8; k++) {
      if (diverge[k] < -0.2) 
	printf("  ----   ");
      else
	printf("%8.6f ", diverge[k]);
    }
    printf("\nChi:        "); 
    for (k=0; k<8; k++) {
      if (chi[k] < -0.2) 
	printf("  ----   ");
      else
	printf("%8.6f ", chi[k]);
    }
    printf("\n");
  } while(1);
  
  return;
}


void Compute_Prob_Image(REGION_LABEL *alabel,
			IMAGEFLOAT *probImg)
{
  int i, j;
  int k;
  float nextVal;
  float weight;
  //assert(probImg->nrow == alabel->resImg.nrow);
  //assert(probImg->ncol == alabel->resImg.ncol);
  Create_An_Image_Float(alabel->resImg.nrow, alabel->resImg.ncol, probImg);
  for (i=0; i < probImg->nrow; i++) {
    for (j=0; j < probImg->ncol; j++) {
      k = (int)(alabel->resImg.data[i][j]/alabel->histUnit);
      if (k >= (alabel->histLen) ) {
	probImg->data[i][j] = 0.0;
      }
      else {
	if (k==(alabel->histLen-1)) {
	  nextVal = 0.0;
	}
	else {
	  nextVal = alabel->probHist[k+1];
	}
	weight = alabel->resImg.data[i][j]/alabel->histUnit - k;
	probImg->data[i][j] = alabel->probHist[k] * (1.0-weight) +
	  nextVal * weight;
      }
    }
  }
  return;
}


void Estimate_Region_Parameter(int row, int col, 
			      int segWin,
			      FILTERBANK *ffamily,
			      IMAGEINT *animage,
			      IMAGEINT *labelImg,
			      REGION_LABEL *alabel)
{ 
  float *histTmp;
  int i, j, k, k1,k2;
  int bound_x, bound_y;
  float *resHist;
  float tmp;
  float min, max;
  float unit;
  int bin_num;
  int index;
  int wsize;
  int peak, trough;
  float threshold;
  float regArea;
  float minThresh;
  alabel->segWin = segWin;
  alabel->segWsize = ffamily->winLevels[alabel->segWin].y;
  alabel->len = ffamily->totalBin;
  alabel->fvector = (float *)malloc(sizeof(float)*ffamily->totalBin);
  Create_An_Image_Float(animage->nrow, animage->ncol, 
			&(alabel->resImg));
  /* We can find the min/max from the image. Here we simply use
     reasonable values */
  min = 0.; max = 2.0; unit = SMOOTH_HIST_UNIT;
  bin_num = (max-min)/unit;
  resHist = (float *)malloc(sizeof(float)*bin_num);
  for (k=0; k< bin_num; k++)
    resHist[k] =0.0;
  
  bound_x = ffamily->winLevels[segWin].x;
  bound_y = ffamily->winLevels[segWin].y;
  
  wsize = (bound_y+1)/4;
  if (wsize < 1) wsize = 1;
  if (wsize > bound_y) wsize = bound_y;
  wsize = 0;
  /* Rememver the size of the window */
  alabel->wsize = wsize;
  
  histTmp  = (float *)malloc(sizeof(float)*ffamily->totalBin);
  Compute_Local_Window_Hist(row,col, segWin,
			    ffamily, animage, 
			    alabel->fvector);
  
  
  for (i=0; i< alabel->resImg.nrow; i++) {
    for (j=0; j< alabel->resImg.ncol; j++) {
      alabel->resImg.data[i][j] = 2.0;
    }
  }
  alabel->bound_x = bound_x;
  alabel->bound_y = bound_y;
  printf("Estimating parameter for candidate label %d with ",
	 alabel->label);
  printf("Window level %d and size %d x %d\n",
	 segWin, bound_x*2+1, bound_y*2+1);
  
  for (i=bound_y; i < (animage->nrow-bound_y); i+= (2*wsize+1)) {
    printf("%d ", i);
    fflush(stdout);
    
    for (j=bound_x; j < (animage->ncol-bound_x); j+= (2*wsize+1)) {
      Compute_Local_Window_Hist(i,j,segWin,
				ffamily, animage, histTmp);
      tmp  = 
	Calc_Hist_Divergence(alabel->fvector, histTmp,
			     ffamily->totalBin);
      index = (int)((tmp-min)/unit);
      if (index < 0)
	index = 0;
      else {
	if (index >= bin_num)
	  index = bin_num-1;
      }
      resHist[index]++;
      
      for (k1=-wsize; k1<=wsize; k1++) {
	for (k2=-wsize; k2 <= wsize; k2++) {
	  alabel->resImg.data[i+k1][j+k2] = tmp;
	}
      }
      
    }
  }
  printf("Done.\n");
  
  printf("Resulting histogram:\n");
  for (k=0; k<bin_num; k++) {
    printf("%4.2f ", resHist[k]);
  }
  printf("\n");
  Smoothing_Hist(resHist, bin_num, (int)SMOOTH_HIST_SCALE);
  printf("Smoothed version of Resulting histogram:\n");
  for (k=0; k<bin_num; k++) {
    printf("%4.2f ", resHist[k]);
  }
  printf("\n");
  
  peak = 0;
  if ((resHist[0] > resHist[1]) && (resHist[1]>2.0))
    peak = 0;
  else {
    minThresh = 2.0;
    for (k=1; k < (bin_num-1); k++) {
      if ( (resHist[k] > resHist[k-1]) && 
	   (resHist[k] > resHist[k+1]) && (resHist[k]>minThresh)) {
	peak = k;
	break;
      }
      else {
	minThresh -= 0.05*k;
      }
    }
  }
  
  /* Peak value in the histogram */
  alabel->peakVal = ((float)peak*unit)+min;
 
  trough = peak+1;
  for (k=peak+1; k < (bin_num-1); k++) {
    if ( (resHist[k] <= resHist[k-1]) &&
	 (resHist[k] <= resHist[k+1])) {
      trough = k;
      break;
    }
  }
  
  
  alabel->threshold = ((float)trough*unit)+min;
  alabel->threshold = (alabel->peakVal+alabel->threshold)/2.;

  regArea = 0;
  for (k=0; k<= trough; k++) {
    regArea += resHist[k];
  }
  regArea *= (2*wsize+1) * (2*wsize+1);
  i = regArea/10;
  if (i < 100)
    i = regArea/2;
  
  alabel->regThres = i;
  /* Create the probability hist model here */
  alabel->histLen = trough+1;
  alabel->histUnit = unit;
  alabel->probHist = Create_Array(alabel->histLen);
  tmp = 0.0;
  for (k=0; k < alabel->histLen; k++) {
    alabel->probHist[k] = resHist[k];
    tmp += alabel->probHist[k];
  }
  for (k=0; k < alabel->histLen; k++) {
    alabel->probHist[k] /= tmp;
  }
  
  alabel->refWin = 
    Find_Refine_Window(row, col,
		       ffamily,
		       animage,
		       segWin,
		       alabel->threshold);
  alabel->refWsize = ffamily->winLevels[alabel->refWin].y;
  alabel->refineVec = (float *)malloc(sizeof(float)*ffamily->totalBin);
  
  Compute_Local_Window_Hist(row,col, alabel->refWin,
			    ffamily, animage, 
			    alabel->refineVec);
  
  
  alabel->seed_row = row;
  alabel->seed_col = col;
  free(histTmp);
  free(resHist);
  return;
}

int Find_Refine_Window(int row, int col,
		       FILTERBANK *ffamily,
		       IMAGEINT *animage,
		       int segWin,
		       float segthresh)
{
  int i, k;
  float *histTmp[2];
  float threshold;
  int next;
  
  threshold = segthresh * 0.25;
  
  for (k=0; k < 2; k++) 
    histTmp[k] = (float *)malloc(sizeof(float)*ffamily->totalBin);
  
  Compute_Local_Window_Hist(row, col, segWin,
			    ffamily, animage, histTmp[0]);
  next = 1;
  for (i=segWin-1; i >=0; i--) {
    Compute_Local_Window_Hist(row,col, i,
			      ffamily, animage, histTmp[next]);
    if ( Calc_Hist_Divergence(histTmp[next],
			      histTmp[1-next],
			      ffamily->totalBin) > threshold) {
      break;
    }
    next = 1-next;
  }
  
  for (k=0; k< 2 ; k++)
    free(histTmp[k]);
  i = i+1;
  if (i > segWin) i = segWin;
  return i;
}

void Remove_Not_Calc_Points(REGION_LABEL *alabel)
{ 
  
  int i, j, k1,k2;
  IMAGEINT tmpImg;

  tmpImg.nrow = 0;
  Create_An_Image_Int(alabel->resImg.nrow, alabel->resImg.ncol,
		      &tmpImg);
  for (i=0; i < alabel->resImg.nrow; i++) {
    for (j=0; j < alabel->resImg.ncol; j++) {
      tmpImg.data[i][j] = 0;
    }
  }
  
  for (i=alabel->bound_y; i < (alabel->resImg.nrow-alabel->bound_y);
       i+= (2*alabel->wsize+1)) {
    for (j=alabel->bound_x; j < (alabel->resImg.ncol-alabel->bound_x); 
	 j+= (2*alabel->wsize+1)) {
      tmpImg.data[i][j] = 1;
    }
  }
  for (i=0; i < alabel->resImg.nrow; i++) {
    for (j=0; j < alabel->resImg.ncol; j++) {
      /*  if (tmpImg.data[i][j] == 0) */
      alabel->resImg.data[i][j]  =
	(float)(NOT_CALC_VALUE_DEFAULT+1.0);
    }
  }
  Free_Image_Int(&tmpImg);
  return;
}
  

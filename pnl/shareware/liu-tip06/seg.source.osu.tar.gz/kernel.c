/***********************************************************

   This file inludes all operators on the data structure : kernel

     wid, ht                (must be odd numbers)
     * * * * *
     * * * * *
     * * * * *

***********************************************************/
#define  KERNEL_SOURCE_C_C

#include "kernel.h"

/*************************************************

     Read kernel from file to filter

*************************************************/

void Read_Kernel(FILTER *filter, char *name, int layer_no)
     /*FILTER *filter: read to this filter which uses this kernel */
     /*char *name: file name storing the kernel */
     /* int layer_no; */ 
{
  FILE *kernel;
  float   *p;
  int row, col, i,j, count, scale;
  static int fold[4]={1,2,4,8};
  
  kernel=fopen(name, "r");
  if(kernel==NULL) {
    printf(" open kernel file %s error\n", name);
    exit(-1);
  }

  fscanf(kernel, "%d%d", &row, &col);
  if( (row%2==0) || (col%2==0) ) {
    printf("error: kernel size must be odd number!\n");
    exit(-1);
  }
  
  filter->size=row*col;  scale=fold[layer_no];
  
  filter->ht=row/2 *scale; filter->wid=col/2 *scale;
  
  filter->kernel=Create_Array(filter->size);
  
  p=filter->kernel;
  
  for(i=0; i<filter->size; i++)
    fscanf(kernel, "%f", p++);
  strcpy(filter->name, name);
  printf("  Reading kernel %d  from %s: ",  filter->id,
	 name);
  printf("size %d x %d, expanded to %d x %d\n", 
	 row, col,
	 filter->ht*2+1, filter->wid*2+1);
  
  if(filter->ht!=0 || filter->wid!=0)
    Normalize_Kernel(filter);
  
  filter->rlist=(int *)malloc(filter->size*sizeof(int));
  filter->clist=(int *)malloc(filter->size*sizeof(int));
  count=0;
  for(i=-filter->ht; i<=filter->ht; i+=scale)
    for(j=-filter->wid; j<=filter->wid; j+=scale) {
      filter->rlist[count]=i;
      filter->clist[count]=j;
      count++;
    }
  fclose(kernel);
  /* Create the filter mark array */
  filter->mark = Create_Array(filter->bin_num);
  filter->hist = Create_Array(filter->bin_num);
  
}


/*****************************************************
    Create a kernel of size (2*height+1)x(2*width+1)
    then put the pointers at the center
******************************************************/
MAT  Create_Kernel(int height, int  width)
{
  MAT  p;
  int  i;
  
  p=(float **)malloc((2*height+1)*sizeof(float *));
  p+=height;
  for(i=-height; i<=height; i++) {
    p[i]=(float *)malloc((2*width+1)*sizeof(float));
    p[i]+=width;
  }
  
  return(p);
}

void Free_Filter(FILTER *filter)
{
  if (filter->id >=0) {
    free(filter->kernel);
    free(filter->rlist);
    free(filter->clist);
    free(filter->mark);
    free(filter->hist);
    filter->id = -1;
  }

}

/******************************************************/
void Normalize_Kernel(FILTER *filter)
{
  float sum, amp;
  int i,j;
  
  sum=0; amp=0;
  for(i=0; i<filter->size; i++)
    sum+=filter->kernel[i];
  sum /=filter->size;
  for(i=0; i<filter->size; i++)
    amp+=(filter->kernel[i]-sum)*(filter->kernel[i]-sum);
  amp = sqrtf(amp);
  for(i=0; i<filter->size; i++) {
    filter->kernel[i]=(filter->kernel[i]-sum)/amp;
  }
  return;
}

int Read_Filters(char *name, FILTERBANK *ffamily)
{
  int i,j, k, layer_no;
  FILE *IN;
  float ratio;
  float csize;
  
  if ( (IN=fopen(name,"rb"))==NULL) {
    printf("read filter error %s\n", name);
    return -1;
  }
  if (ffamily->nfilter > 0) {
    Free_Filter_Bank(ffamily);
  }
  
  fscanf(IN, "%d", &(ffamily->nfilter));
  printf("Loading %d filters from file '%s' ... \n",
	 ffamily->nfilter, name);
  ffamily->fbank = (FILTER *)malloc(sizeof(FILTER)*ffamily->nfilter);
  ffamily->filterDim = (int *)malloc(sizeof(int)*ffamily->nfilter);
  ffamily->longestBin =0;
  ffamily->totalBin = 0;
  ffamily->max_wid = 0;
  ffamily->max_ht = 0;
  for(i=0; i< ffamily->nfilter; i++) {
    fscanf(IN, "%d", &layer_no);
    fscanf(IN, "%s", ffamily->fbank[i].name);
    fscanf(IN, "%d", &(ffamily->fbank[i].bin_num));
    /*  Kernel_List */
    ffamily->fbank[i].id = i+1;
    Read_Kernel(&(ffamily->fbank[i]), ffamily->fbank[i].name, 
		layer_no);
    ffamily->totalBin += ffamily->fbank[i].bin_num;
    if (i==0) {
      ffamily->filterDim[i] = 0;
    }
    else {
      ffamily->filterDim[i] = ffamily->filterDim[i-1] +
	ffamily->fbank[i].bin_num;
    }
    if (ffamily->longestBin < ffamily->fbank[i].bin_num)
      ffamily->longestBin = ffamily->fbank[i].bin_num;
    if (ffamily->max_wid < ffamily->fbank[i].wid)
      ffamily->max_wid = ffamily->fbank[i].wid;
    if (ffamily->max_ht < ffamily->fbank[i].ht)
      ffamily->max_ht = ffamily->fbank[i].ht;
  }
  printf("%d filters loaded successfully with total %d bins.\n", 
	 ffamily->nfilter, ffamily->totalBin);
  printf("Loading ");
  /* Read the window levels */
  
  ffamily->nlevel = 10;
  ratio = 1.5;
  if ( fscanf(IN, "%d", &(ffamily->nlevel)) ==1) {
    if (fscanf(IN,"%f", &ratio) == 0)
      ratio = 1.5;
    printf("user specfied ");
  }
  else {
    ffamily->nlevel = 10;
    printf("DEFAULT ");
  }
  
  ffamily->winLevels = (POINT2D *) malloc(sizeof(POINT2D)*ffamily->nlevel);
  j=0;
  ffamily->winLevels[0].x = ffamily->winLevels[0].y = 0;
  j++;
  csize = ratio * (2*ffamily->winLevels[0].x+1)*(2*ffamily->winLevels[0].y+1);
  for (i=1; i<ffamily->nlevel; i++) {
    do {
      j=j+1;
      k = (2*j+1)*(2*j+1);
    } while ((float)k < csize);
    if ( ((float)k/csize-1) > (1.0-(float)((2*j-1)*(2*j-1))/csize)) 
      j = j-1;
    ffamily->winLevels[i].x = ffamily->winLevels[i].y = j;
    csize = ratio * (2*ffamily->winLevels[i].x+1)*
      (2*ffamily->winLevels[i].y+1);
    j++;
  }
  
  printf("structure .... %d levels loaded\n", ffamily->nlevel);
  printf("Levels:\t");
  for (i=0; i<ffamily->nlevel; i++) {
    printf("%2d(%3d,%3d) ", i+1,
	   2*ffamily->winLevels[i].x+1, 2*ffamily->winLevels[i].y+1);
    if ( (i+1)%5 ==0 && i!= (ffamily->nlevel-1)) printf("\n\t");
  }
  printf("\n");
  ffamily->clevel = 0;
  
  fclose(IN);
  return ffamily->nfilter;
  
}

void Free_Filter_Bank(FILTERBANK *ffamily)
{
  if (ffamily->nfilter > 0) {
    int i;
    for (i=0; i < ffamily->nfilter; i++) {
      Free_Filter(&(ffamily->fbank[i]));
    }
    free(ffamily->fbank);
    free(ffamily->winLevels);
    free(ffamily->filterDim);
    ffamily->nfilter = 0;
  }
  return;
}


int Read_Filter_Marks(char *name, FILTERBANK *ffamily)
{
  int i, j, k;
  FILE *IN;
  
  if ( (IN=fopen(name,"rb")) == NULL) return -1;
  fscanf(IN, "%d", &i);
  if (i != ffamily->nfilter) {
    printf("Number of filters (%d) in filter mark file ", i);
    printf("does not match the current number of filters (%d).\n",
	   ffamily->nfilter);
    fclose(IN);
    return -1;
  }
  for (i=0; i<ffamily->nfilter; i++) {
    fscanf(IN, "%d%f", &j, &(ffamily->fbank[i].unit));
    if (i != j) {
      printf("Wrong bin mark file format. ");
      printf("Filter %d starts with %d instead.\n", i, j);
      fclose(IN);
      return -1;
    }
    for (k=0; k < ffamily->fbank[i].bin_num; k++) 
      fscanf(IN, "%f", &(ffamily->fbank[i].mark[k]));
  }
  
  /* Read out the histogram */
  for (i=0; i<ffamily->nfilter; i++) {
    fscanf(IN, "%d", &j);
    if (i != j) {
      printf("Wrong bin mark file format. ");
      printf("Filter %d starts with %d instead.\n", i, j);
      fclose(IN);
      return -1;
    }
    for (k=0; k < ffamily->fbank[i].bin_num; k++) 
      fscanf(IN, "%f", &(ffamily->fbank[i].hist[k]));
  }
  fclose(IN);
  printf("Histogram unit and bin marks are loaded successfully from '%s'.\n",
	 name);
  return 0;
}

int Save_Filter_Marks(char *name, FILTERBANK *ffamily)
{     
  int i,k;
  FILE *OUT;

  if ( (OUT=fopen(name,"wb")) == NULL) return -1;
  fprintf(OUT, "%d\n", ffamily->nfilter);
  for (i=0; i<ffamily->nfilter; i++) {
    fprintf(OUT, "%d %f ",i, ffamily->fbank[i].unit);
    for (k=0; k < ffamily->fbank[i].bin_num; k++) 
      fprintf(OUT, "%f ", ffamily->fbank[i].mark[k]);
    fprintf(OUT,"\n");
  }
  /* Save the histogram also */
  fprintf(OUT,"\n\n");
  for (i=0; i<ffamily->nfilter; i++) {
    fprintf(OUT, "%d ",i);
    for (k=0; k < ffamily->fbank[i].bin_num; k++) {
      fprintf(OUT, "%f ", ffamily->fbank[i].hist[k]);
    }
    fprintf(OUT,"\n");
  }

  fclose(OUT);
  printf("Histogram unit and bin marks are saved successfully into '%s'\n",
	 name);
  return 0;
}

int Generate_Marks_From_Image(FILTERBANK *ffamily, 
			      IMAGEINT *animage)
{
  MAT  Resp;
  int ht, wid;
  ARRAY hist;
  float minTail;
  int i, i1, i2, k;
  int r, c;
  FILTER *filter;
  float min, max, sum;
  int adjustTail;
  int index;
  
  hist = Create_Array(ffamily->longestBin);
  Resp = Create_Matrix(animage->nrow, animage->ncol);
  
  for (k=0; k < ffamily->nfilter; k++) {
    filter = &(ffamily->fbank[k]);
    ht = filter->ht; wid=filter->wid; 
    minTail = 0.1 * (float)((animage->nrow-2*ht)*(animage->ncol-2*wid))/ 
      (float)filter->bin_num;
    min=1000; max=-10000;
    for(r=ht; r<animage->nrow-ht; r++) {
      for(c=wid; c<animage->ncol-wid; c++) {
	sum=0.0;    
	for(i=0; i<filter->size; i++) { 
	  i1 = (r+filter->rlist[i]+animage->nrow)%animage->nrow;
	  i2 = (c+ filter->clist[i]+animage->ncol)%animage->ncol;
	  sum += filter->kernel[i]*
	    animage->data[i1][i2]; 
	}
	if(min>sum) min=sum;
	if(max<sum) max=sum;
	
	Resp[r][c]=sum;
      }
    }
    if( (filter->wid==0)&&(filter->ht==0)) { /* the intensity histogram */
      for(i=0; i<filter->bin_num; i++)
	filter->mark[i]= i*(float)(max-min)/(float)filter->bin_num+min;
      filter->unit=(float)(max-min)/(float)filter->bin_num;
    }
    else {
      do {
	adjustTail = 0;
	for(i=0; i<filter->bin_num; i++)
	  filter->mark[i]=((float)i)*(max-min)/((float)filter->bin_num) +
	    min;
	filter->unit = (max-min)/((float)filter->bin_num);
	for(i=0; i<filter->bin_num; i++) hist[i]=0.0;
	for(r=ht; r<animage->nrow-ht; r++) {
	  for(c=wid; c<animage->ncol-wid; c++) {
	    index=Round((Resp[r][c]-filter->mark[0])/(filter->unit));
	    if(index<0) {
	      hist[0]+=1; continue;
	    }
	    if(index>=filter->bin_num-1) {
	      hist[filter->bin_num-1]+=1; continue;
	    }
	    hist[index]+=1;
	  }
	}
	
	if (hist[0] < minTail || hist[filter->bin_num-1] < minTail) {
	  /*printf("Hist needs to be adjusted: ");
	    printf("min = %6.4f max=%6.4f unit=%6.4f\n",
	    min, max, filter->unit);
	    printf("Histogram: ");
	    for (i=0; i<bin_num; i++) {
	    printf("%5.1f ", hist[i]);
	    }
	    printf("\n");*/
	  adjustTail = 1;
	}
	if (hist[0] < minTail) {
	  for (i=1; i < filter->bin_num; i++) {
	    if ( (hist[0]+hist[i]) > minTail) {
	      min += 0.05*(minTail-hist[0])*filter->unit/hist[i];
	      min += 0.0005*filter->unit;
	      break;
	    }
	    min += filter->unit;
	    hist[0] += hist[i];
	  }
	}
	if (hist[filter->bin_num-1] < minTail) {
	  for (i=filter->bin_num-2; i >= 1; i--) {
	    if ( (hist[filter->bin_num-1]+hist[i]) > minTail) {
	      max -= 0.05*(minTail-hist[filter->bin_num-1])*
		filter->unit/hist[i];
	      max -= 0.0005*filter->unit;
	      break;
	    }
	    max -= filter->unit;
	    hist[filter->bin_num-1] += hist[i];
	  }
	}
      } while(adjustTail);
    }
    
    for(i=0; i<filter->bin_num; i++) hist[i]=0.0;  /* clean up */
    
    for(r=ht; r<animage->nrow-ht; r++) {
      for(c=wid; c<animage->ncol-wid; c++) {
	index=Round((Resp[r][c]-filter->mark[0])/(filter->unit));
	if(index<0) {
	  index = 0;
	}
	else {
	  if(index > filter->bin_num-1) {
	    index = filter->bin_num-1;
	  }
	}
	hist[index]+=1;
      }
    }
    printf("\n\nParameters: ");
    printf("min = %6.4f max=%6.4f unit=%6.4f\n", min, max, filter->unit);
    printf("Final Histogram: ");
    sum = 0.0;
    /* Also save the histogram */
    sum = 0.0;
    for (i=0; i< filter->bin_num; i++) {
      sum += hist[i];
    }
    for (i=0; i< filter->bin_num; i++) {
      filter->hist[i] = hist[i]/sum;
    }
    for (i=0; i< filter->bin_num; i++) {
      printf("%5.1f ", hist[i]);  
    }
    printf("\n\n");
  }
  Free_Array(hist);
  Free_Matrix(Resp, animage->nrow);
  return 0;
}






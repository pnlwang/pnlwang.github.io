#if !defined(SMOOTHING_H_H)
#define SMOOTHING_H_H
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "type-def.h"
#include "util.h"
#include "feature_extract.h"

#if defined(SMOOTHING_SOURCE_C_C)
#define GAUSSIAN_SMOOTH_SCALE           20
#define EXTERN_FLAG
#else
#define EXTERN_FLAG extern
#endif
EXTERN_FLAG void NonLinearSmooth_ImageVector(IMAGEVECTOR *featureImg,
					     int wsize,
					     FILTERBANK *ffamily);

EXTERN_FLAG void Extract_Homogeous_Region(IMAGEVECTOR *featureImg,
					  int wsize,
					  FILTERBANK *ffamily,
					  IMAGEFLOAT *homoImg);

#undef  EXTERN_FLAG
#endif


#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#include "type-def.h"
#include "util.h"
#include "kernel.h"
#include "imageio.h"
#include "smoothing.h"
#include "para-util.h"

int main(int argc, char **argv)
{
  char paraFile[256];
  IMAGEINT obsImg;
  
  int windex, upindex;
  int wsize;
  char prefix[256];
  char fname[256];
  int i,k;
  CONTROL_INFO  para_setting;
  
  FILTERBANK  fbank;
  if (argc < 1) {
    printf("Please specify the parameter file: ");
    scanf("%s", paraFile);
  }
  else {
    strcpy(paraFile, argv[1]);
  }
  
  LoadParameter(paraFile, &para_setting);
  DisplayParameter(&para_setting);
  
  srand(para_setting.seed);

  fbank.nfilter = 0;
  obsImg.nrow = 0;

  Read_An_Image_Int(para_setting.inputFile, &obsImg);
  Read_Filters(para_setting.filterFile, &fbank);
  
  
  sprintf(fname,"%s_syn.pgm", para_setting.prefix);
  Write_An_Image_Int(&obsImg, (int)1, fname);

  i = 1;
  if (para_setting.histMark[0] != '\0') {
    i = Read_Filter_Marks(para_setting.histMark, &fbank);
  }
  if (i !=0 ) {
    Generate_Marks_From_Image(&fbank, &obsImg);
  }
  sprintf(fname,"%s_mark.dat", para_setting.prefix);
  /*if (para_setting.histMark[0] != '\0' && i ==0) {
    i = strcmp(fname, para_setting.histMark);
  }
  */
  if (i !=0) /* Save the marks when necessary */
    Save_Filter_Marks(fname,&fbank); 
  /* Check values here */
  if (para_setting.topWin >= fbank.nlevel)
    para_setting.topWin = fbank.nlevel-1;
  if (para_setting.segWin > para_setting.topWin) {
    para_setting.segWin = para_setting.topWin;
  }
  Homogeous_Layer_Test_Before(&fbank,
			      &obsImg,
			      &para_setting);
  Free_Filter_Bank(&fbank);
  Free_Image_Int(&obsImg);
  return 0;
}









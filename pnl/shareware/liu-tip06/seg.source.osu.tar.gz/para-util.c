#define  PARA_UTIL_SOURCE_CODE
#include "para-util.h"

void SetDefaultParameter(CONTROL_INFO *controlInfo)
{
  /* Set file names to be null initially */
  controlInfo->inputFile[0] = '\0';
  controlInfo->filterFile[0] = '\0';
  controlInfo->prefix[0] = '\0';
  controlInfo->histMark[0] = '\0';
  
  controlInfo->lammda = 1000.;
  controlInfo->topWin = 20-1;
  controlInfo->segWin = 10;
  controlInfo->npoint = 0;
  controlInfo->boundWeight = 0.1;
  controlInfo->refinedWin = 0;
  controlInfo->interactive = 0;
  controlInfo->seed = 517;
  return;
}

void DisplayParameter(CONTROL_INFO *controlInfo)
{
  int i,j,wsize;
  printf("\nNow Parameters are set as follows.\n");
  printf("\tInput texture Image:\t%s\n", controlInfo->inputFile);
  printf("\tOutput File Prefix:\t%s\n", controlInfo->prefix);
  if (controlInfo->histMark[0] == '\0' ) {
    printf("\tHistogram marks will be computed.\n");
  }
  else {
    printf("\tHistogram mark file:\t%s\n", controlInfo->histMark);
  }
  printf("\tRelax factor between labeled and the background: %8.2f.\n",
	 controlInfo->lammda);
  printf("\tBoundary term weight:  %8.6f.\n",
	 controlInfo->boundWeight);
  printf("\tTop layer that will be computed: %d.\n",
	 controlInfo->topWin+1);
  printf("\tSegment window level: %d.\n",
	 controlInfo->segWin+1);
   if (controlInfo->refinedWin) {
    printf("\tRefined window will be used ");
  }
  else {
    printf("\tOriginal segment window will be used ");
  }
  printf("for segmentation.\n");
  printf("\tThere are %d seed points loaded in col, row format.\n", 
	 controlInfo->npoint);
  for (i= 0; i < controlInfo->npoint; i++) {
    printf("\t\t%d %d\n",  controlInfo->seedPoints[i].x,
	   controlInfo->seedPoints[i].y);
    
  }
  if (controlInfo->interactive) {
    printf("\tPrompt for checking intermediate region boundaries.\n");
  }
  else {
    printf("\tProgram will run continuosly until finished.\n");
  }
  printf("\tSeed for random number generator:  %d\n",
	 controlInfo->seed);
  printf("End of Parameters.\n\n");
  return;
}
  
int LoadParameter(char *fName,CONTROL_INFO *controlInfo)
{
  char string[MAXFILENAME];
  FILE *fp;
  int i, tmp;
  SetDefaultParameter(controlInfo);
  if ( (fp = fopen(fName,"rb")) == NULL) return -1;
  /* reading all parameters */
  while(fscanf(fp,"%s",string) >0) {
    if (string[0] =='#')  {
      /* it is a comment */
      while (getc(fp) != '\n');
      continue;
    }
    if (strcasecmp(string,"input-image") == 0) {
      fscanf(fp,"%s",controlInfo->inputFile);
      continue;
    }
    if (strcasecmp(string,"filter-file") == 0) {
      fscanf(fp,"%s",controlInfo->filterFile);
      continue;
    }
    
    if (strcasecmp(string,"output-prefix") == 0) {
      fscanf(fp,"%s",controlInfo->prefix);
      continue;
    }
 
    if (strcasecmp(string,"hist-mark-file") == 0) {
      fscanf(fp,"%s",controlInfo->histMark);
      continue;
    } 
    if (strcasecmp(string,"lammda") == 0) {
      fscanf(fp,"%f",&(controlInfo->lammda));
      continue;
    }
    if (strcasecmp(string,"bound-term") == 0) {
      fscanf(fp,"%f",&(controlInfo->boundWeight));
      if (controlInfo->boundWeight > 1.0 || controlInfo->boundWeight < 0.0)
	controlInfo->boundWeight = 0.1;
      
      continue;
    } 
    if (strcasecmp(string,"top-window") == 0) {
      fscanf(fp,"%d",&(controlInfo->topWin));
      controlInfo->topWin--;
      continue;
    }
    if (strcasecmp(string,"seg-window") == 0) {
      fscanf(fp,"%d",&(controlInfo->segWin));
      controlInfo->segWin--;
      continue;
    }
    if (strcasecmp(string,"use-refine-win") == 0) {
      fscanf(fp,"%d",&(controlInfo->refinedWin));
      continue;
    }

    if (strcasecmp(string,"interactive") == 0) {
      fscanf(fp,"%d",&(controlInfo->interactive));
      continue;
    }
    if (strcasecmp(string,"rand-seed") == 0) {
      fscanf(fp,"%d",&(controlInfo->seed));
      continue;
    } 
    if (strcasecmp(string,"seed-points") == 0) {
      fscanf(fp,"%d",&(controlInfo->npoint));
      for (i=0; i < controlInfo->npoint; i++) {
	if (i < MAX_LABEL_IMAGE) {
	  fscanf(fp,"%d%d", 
		 &(controlInfo->seedPoints[i].x),
		 &(controlInfo->seedPoints[i].y));
	}
	else {
	  fscanf(fp,"%d%d",&tmp, &tmp);
	}
      }
      if (controlInfo->npoint > MAX_LABEL_IMAGE) {
	printf(" Too many seed points. Only the first %d will be used.\n",
	       MAX_LABEL_IMAGE);
	controlInfo->npoint = MAX_LABEL_IMAGE;
      }
      continue;
    }
    
    printf("\nInvalid choice: %s\n",string);
    while (getc(fp) !='\n');
  }
  fclose(fp);
 
  if (controlInfo->prefix[0] == '\0') {
    sprintf(controlInfo->prefix,"%s_%s",controlInfo->inputFile,
	    controlInfo->filterFile);
  }
  
  return 0;
}


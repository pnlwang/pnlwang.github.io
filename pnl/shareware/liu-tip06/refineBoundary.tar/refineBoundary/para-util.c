#define  PARA_UTIL_SOURCE_CODE
#include "para-util.h"

void SetDefaultParameter(CONTROL_INFO *controlInfo)
{
  /* Set file names to be null initially */
  controlInfo->inputFile[0] = '\0';
  controlInfo->probModel[0] = '\0';
  controlInfo->filterFile[0] = '\0';
  controlInfo->segFile[0] = '\0';
  controlInfo->prefix[0] = '\0';
  controlInfo->histMark[0] = '\0';
  
  controlInfo->lammda = 1000.;
  controlInfo->topWin = 20-1;
  controlInfo->segWin = 10;
  controlInfo->npoint = 0;
  controlInfo->boundWeight = 0.1;
  controlInfo->refinedWin = 0;
  controlInfo->interactive = 0;
  controlInfo->seed = 517;
  controlInfo->iterationAtMost = 10;
  controlInfo->boundRefineNPoint = 10;
  controlInfo->exclude_size = (int)(sqrtf(controlInfo->boundRefineNPoint)+1.0);
  return;
}

void DisplayParameter(CONTROL_INFO *controlInfo)
{
  int i,j,wsize;
  printf("\nNow Parameters are set as follows.\n");
  printf("\tInput texture Image:\t%s\n", controlInfo->inputFile);
  printf("\tStarting segmentation result: \t%s\n",
	 controlInfo->segFile);
  printf("\tOutput File Prefix:\t%s\n", controlInfo->prefix);
  if (controlInfo->probModel[0] == '\0') {
    printf("\tProbability model will be computed.\n");
  }
  else {
    printf("\tProbability model will be loaded from '%s'.\n",
	   controlInfo->probModel);
  }
  /*if (controlInfo->histMark[0] == '\0' ) {
    printf("\tHistogram marks will be computed.\n");
  }
  else {
    printf("\tHistogram mark file:\t%s\n", controlInfo->histMark);
  }
  printf("\tRelax factor between labeled and the background: %8.2f.\n",
	 controlInfo->lammda);
  printf("\tBoundary term weight:  %8.6f.\n",
	 controlInfo->boundWeight);
  printf("\tTop layer that will be computed: %d.\n",
	 controlInfo->topWin+1);
  printf("\tSegment window level: %d.\n",
	 controlInfo->segWin+1);
   if (controlInfo->refinedWin) {
    printf("\tRefined window will be used ");
  }
  else {
    printf("\tOriginal segment window will be used ");
  }
  printf("for segmentation.\n");
  */
  printf("\tParameters for boundary refinement.\n");
  printf("\t\tTemplate size (full window): \t%d\n",
	 controlInfo->boundRefineWin*2+1);
  printf("\t\tTotal points would be used:  \t%d\n",
	 controlInfo->boundRefineNPoint);
  printf("\tThere are %d seed points loaded in col, row format.\n", 
	 controlInfo->npoint);
  for (i= 0; i < controlInfo->npoint; i++) {
    printf("\t\t%d %d\n",  controlInfo->seedPoints[i].x,
	   controlInfo->seedPoints[i].y);
    
  }
  if (controlInfo->interactive) {
    printf("\tPrompt for checking intermediate region boundaries.\n");
  }
  else {
    printf("\tProgram will run continuosly until finished.\n");
  }
  if (controlInfo->iterationAtMost > 0) {
    printf("\tProgram will run for at most %d iterations.\n",
	   controlInfo->iterationAtMost);
  }
  else {
    printf("\tProgram will run until it converges.\n");
  }
  printf("\tSeed for random number generator:  %d\n",
	 controlInfo->seed);
  printf("End of Parameters.\n\n");
  return;
}
  
int LoadParameter(char *fName,CONTROL_INFO *controlInfo)
{
  char string[MAXFILENAME];
  FILE *fp;
  int i, tmp;
  SetDefaultParameter(controlInfo);
  if ( (fp = fopen(fName,"rb")) == NULL) return -1;
  /* reading all parameters */
  while(fscanf(fp,"%s",string) >0) {
    if (string[0] =='#')  {
      /* it is a comment */
      while (getc(fp) != '\n');
      continue;
    }
    if (strcasecmp(string,"input-image") == 0) {
      fscanf(fp,"%s",controlInfo->inputFile);
      continue;
    }
     if (strcasecmp(string,"prob-model") == 0) {
      fscanf(fp,"%s",controlInfo->probModel);
      continue;
    }
    if (strcasecmp(string,"starting-res") == 0) {
      fscanf(fp,"%s",controlInfo->segFile);
      continue;
    } 
    if (strcasecmp(string,"filter-file") == 0) {
      fscanf(fp,"%s",controlInfo->filterFile);
      continue;
    }
    
    if (strcasecmp(string,"output-prefix") == 0) {
      fscanf(fp,"%s",controlInfo->prefix);
      continue;
    }
 
    if (strcasecmp(string,"hist-mark-file") == 0) {
      fscanf(fp,"%s",controlInfo->histMark);
      continue;
    } 
    if (strcasecmp(string,"lammda") == 0) {
      fscanf(fp,"%f",&(controlInfo->lammda));
      continue;
    }
    if (strcasecmp(string,"bound-term") == 0) {
      fscanf(fp,"%f",&(controlInfo->boundWeight));
      if (controlInfo->boundWeight > 1.0 || controlInfo->boundWeight < 0.0)
	controlInfo->boundWeight = 0.1;
      
      continue;
    } 
    if (strcasecmp(string,"top-window") == 0) {
      fscanf(fp,"%d",&(controlInfo->topWin));
      controlInfo->topWin--;
      continue;
    }
    if (strcasecmp(string,"seg-window") == 0) {
      fscanf(fp,"%d",&(controlInfo->segWin));
      controlInfo->segWin--;
      continue;
    }
    if (strcasecmp(string,"use-refine-win") == 0) {
      fscanf(fp,"%d",&(controlInfo->refinedWin));
      continue;
    }

    if (strcasecmp(string,"interactive") == 0) {
      fscanf(fp,"%d",&(controlInfo->interactive));
      continue;
    }
    if (strcasecmp(string,"rand-seed") == 0) {
      fscanf(fp,"%d",&(controlInfo->seed));
      continue;
    }
    if (strcasecmp(string,"boundary-refine")==0) {
      fscanf(fp,"%d%d",&(controlInfo->boundRefineWin),
	     &(controlInfo->boundRefineNPoint));
      controlInfo->boundRefineWin /= 2;
      controlInfo->exclude_size = 
	(int)(sqrtf(controlInfo->boundRefineNPoint)+1.0);
      continue;
    }
    if (strcasecmp(string,"iteration-at-most")==0) {
      fscanf(fp,"%d",&(controlInfo->iterationAtMost));
      continue;
    }
    if (strcasecmp(string,"seed-points") == 0) {
      fscanf(fp,"%d",&(controlInfo->npoint));
      for (i=0; i < controlInfo->npoint; i++) {
	if (i < MAX_LABEL_IMAGE) {
	  fscanf(fp,"%d%d", 
		 &(controlInfo->seedPoints[i].x),
		 &(controlInfo->seedPoints[i].y));
	}
	else {
	  fscanf(fp,"%d%d",&tmp, &tmp);
	}
      }
      if (controlInfo->npoint > MAX_LABEL_IMAGE) {
	printf(" Too many seed points. Only the first %d will be used.\n",
	       MAX_LABEL_IMAGE);
	controlInfo->npoint = MAX_LABEL_IMAGE;
      }
      continue;
    }
    
    printf("\nInvalid choice: %s\n",string);
    while (getc(fp) !='\n');
  }
  fclose(fp);
 
  if (controlInfo->prefix[0] == '\0') {
    sprintf(controlInfo->prefix,"%s_%s",controlInfo->inputFile,
	    controlInfo->filterFile);
  }
  
  return 0;
}


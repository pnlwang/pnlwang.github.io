#if !defined(KERNEL_H_H)
#define KERNEL_H_H
#include <stdio.h>
#include <math.h>
#include <string.h>
#include "type-def.h"
#include "util.h"

#if defined(KERNEL_SOURCE_C_C)
#define EXTERN_FLAG
#else
#define EXTERN_FLAG extern
#endif

EXTERN_FLAG void Read_Kernel(FILTER *filter, char *name, int layer_no);
EXTERN_FLAG MAT  Create_Kernel(int height, int  width);
EXTERN_FLAG void Free_Filter(FILTER *filter);
EXTERN_FLAG void Normalize_Kernel(FILTER *filter);
EXTERN_FLAG int Read_Filters(char *name, FILTERBANK *ffamily);
EXTERN_FLAG void Free_Filter_Bank(FILTERBANK *ffamily);
EXTERN_FLAG int Read_Filter_Marks(char *name, FILTERBANK *ffamily);
EXTERN_FLAG int Save_Filter_Marks(char *name, FILTERBANK *ffamily);
EXTERN_FLAG int Generate_Marks_From_Image(FILTERBANK *ffamily, 
					  IMAGEINT *animage);
#undef  EXTERN_FLAG
#endif



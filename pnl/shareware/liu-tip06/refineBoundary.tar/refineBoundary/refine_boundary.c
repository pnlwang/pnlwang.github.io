#define REFINE_BOUNDARY_SOURCE_C_C

#include "refine_boundary.h"

void Contract_Regions(IMAGEINT *animage, IMAGEINT *labelmask,
		      CONTROL_INFO *controlInfo)
{
  int boundWidth;
  int i,j,k,i1,j1;
  int nowId;
  int crow, ccol;
  int labelTable[256];
  POINT2D *borderPoints;
  int nborderpoint;
 
  for (k=0; k<256; k++)
    labelTable[k] = 0;
  boundWidth = (int)(sqrtf(controlInfo->boundRefineNPoint)+0.5);
  boundWidth += (controlInfo->segWinSize);
  
  nborderpoint = 4 * 2 * boundWidth;
  borderPoints = (POINT2D *)malloc(sizeof(POINT2D) * nborderpoint);
  k = 0;
  for (i=0-boundWidth; i < boundWidth; i++) {
    borderPoints[k].x = i;
    borderPoints[k].y = boundWidth;
    k++;
  }
  for (i=boundWidth; i > 0-boundWidth; i--) {
    borderPoints[k].x = boundWidth;
    borderPoints[k].y = i;
    k++;
  }
  for (i=boundWidth; i > 0-boundWidth; i--) {
    borderPoints[k].x = i;
    borderPoints[k].y = 0-boundWidth;
    k++;
  }
  for (i=0-boundWidth; i < boundWidth; i++) {
    borderPoints[k].x = 0-boundWidth;
    borderPoints[k].y = i;
    k++;
  }
  if (k !=  nborderpoint) {
    printf("Total number of borders %d do not match with traced points %d\n",
	   nborderpoint, k);
    exit(-1);
  }
  Create_An_Image_Int_Init(animage->nrow, animage->ncol, 
			   labelmask, (int)0);
  for (k=0; k < controlInfo->npoint; k++) {
    crow = controlInfo->seedPoints[k].y;
    ccol = controlInfo->seedPoints[k].x;
    if (labelTable[animage->data[crow][ccol]] ==0) {
      labelTable[animage->data[crow][ccol]] = k+1;
    }
    else {
      printf("Warning: two seed regions have the same label.\n");
    }
  }
  for (i=0; i < animage->nrow; i++) {
    for (j=0; j < animage->ncol; j++) {
      animage->data[i][j] = labelTable[animage->data[i][j]];
    }
  }
  
  for (i=0; i < animage->nrow; i++) {
    for (j=0; j < animage->ncol; j++) {
      for (k=0; k < nborderpoint; k++) {
	crow = borderPoints[k].y + i;
	ccol = borderPoints[k].x + j;
	if (crow >=0 && crow < animage->nrow &&
	    ccol >=0 && ccol < animage->ncol) {
	  if (animage->data[crow][ccol] != animage->data[i][j])
	    break;
	}
      }
      if (k >= nborderpoint) {
	labelmask->data[i][j] = animage->data[i][j];
      }
    }
  }
  
  free(borderPoints);
  return;
}

float CalcRMS_Prob(IMAGEINT *orgimage, IMAGEINT *initLabel,
		   REGION_LABEL *alabel, IMAGEINT *maskImg,
		   int col, int row, CONTROL_INFO *controlInfo)
{
  float prob, dist;
  int index;
  dist = CalcRMS_Distance(orgimage, initLabel, alabel,maskImg,
			  col, row, controlInfo);
  index = (int)(dist/alabel->histUnit);
  if (index < alabel->histLen)
    prob = alabel->probHist[index];
  else 
    prob = 0.0;
  
  return prob;
}

/* Use all the pixels in the initial results to calculate the
   minimum distance
*/

float CalcRMS_Distance(IMAGEINT *orgimage, IMAGEINT *initLabel,
		       REGION_LABEL *alabel, IMAGEINT *maskImg,
		       int col, int row, CONTROL_INFO *controlInfo)
{
  int thelabel;
  int ccol, crow;
  int i,j,k,k1,k2, k3;
  float bestDist, dist;
  
  thelabel = initLabel->data[row][col];
  k =0;
  for (i=0; i<2; i++) {
    controlInfo->alabelregion.xy[i].x=0;
    controlInfo->alabelregion.xy[i].y=0;
  }
  for (k1=0; k1 < controlInfo->pixelOrderList.npoint; k1++) {
    ccol = col + controlInfo->pixelOrderList.dList[k1].x;
    crow = row + controlInfo->pixelOrderList.dList[k1].y;
    if (ccol >=0 && ccol < initLabel->ncol &&
	crow >=0 && crow < initLabel->nrow) {
      if (initLabel->data[crow][ccol] == thelabel) {
	controlInfo->alabelregion.dList[k].x = 
	  controlInfo->pixelOrderList.dList[k1].x;
	controlInfo->alabelregion.dList[k].y = 
	 controlInfo-> pixelOrderList.dList[k1].y;
	if (controlInfo->alabelregion.xy[0].x > 
	    controlInfo->alabelregion.dList[k].x)
	  controlInfo->alabelregion.xy[0].x = 
	    controlInfo->alabelregion.dList[k].x;
	if (controlInfo->alabelregion.xy[0].y > 
	    controlInfo->alabelregion.dList[k].y)
	  controlInfo->alabelregion.xy[0].y = 
	    controlInfo->alabelregion.dList[k].y;
	/* Maximum number */
	if (controlInfo->alabelregion.xy[1].x < 
	    controlInfo->alabelregion.dList[k].x)
	  controlInfo->alabelregion.xy[1].x = 
	    controlInfo->alabelregion.dList[k].x;
	if (controlInfo->alabelregion.xy[1].y < 
	    controlInfo->alabelregion.dList[k].y)
	  controlInfo->alabelregion.xy[1].y = 
	    controlInfo->alabelregion.dList[k].y;
	
	controlInfo->alabelregion.dList[k].z =
	  orgimage->data[crow][ccol];
	k++;
	if (k== controlInfo->alabelregion.npoint) break;
      }
    }
  }
  //thelabel = 1 + (2-thelabel);
  if (k != controlInfo->alabelregion.npoint) {
    printf("Not enough data points at <%d,%d>", col, row);
  }
  bestDist = 255.*255.*controlInfo->alabelregion.npoint;

  for (i=0; i < orgimage->nrow; i++) {
    for (j=0; j < orgimage->ncol; j++) {
      if (maskImg->data[i][j] != thelabel) continue;
      if (abs(i-row) < controlInfo->exclude_size) continue;
      if (abs(j-col) < controlInfo->exclude_size) continue;
      
      k2 = 0;
      dist =0.0;
      for (k1=0; k1< k; k1++) {
	crow = controlInfo->alabelregion.dList[k1].y + i;
	ccol = controlInfo->alabelregion.dList[k1].x + j;
	if ( ccol >=0 && ccol < initLabel->ncol &&
	     crow >=0 && crow < initLabel->nrow) {
	  if (maskImg->data[crow][ccol] != thelabel)
	    break;
	  dist += (controlInfo->alabelregion.dList[k1].z-
		   orgimage->data[crow][ccol])*
	    (controlInfo->alabelregion.dList[k1].z-
	     orgimage->data[crow][ccol]);
	  k2++;
	}
	else {
	  break;
	}
      }
      if (k2 == k) {
	dist /= k2;
	k3++;
	if (bestDist > dist) {
	  bestDist = dist;
	  if (bestDist < alabel->histUnit ) {
	    break;
	  }
	}
      }
      
    }
  }
  bestDist = sqrtf(bestDist);
  return bestDist;
}

/* Calculate distance from randomly selected sites,
   which is much more efficient 
*/

float CalcRMS_Distance_Random(IMAGEINT *orgimage, IMAGEINT *initLabel,
			      REGION_LABEL *alabel, IMAGEINT *maskImg,
			      int col, int row, CONTROL_INFO *controlInfo,
			      IMAGEINT *processedImg)
{
  int thelabel;
  int ccol, crow;
  int i,j,k,k1,k2, k3, k4;
  float bestDist, dist;
  int trow, tcol; /* Try row and column */
  int foundMin;
  float localBest;
  
  thelabel = initLabel->data[row][col];
  k =0;
  for (i=0; i<2; i++) {
    controlInfo->alabelregion.xy[i].x=0;
    controlInfo->alabelregion.xy[i].y=0;
  }
  for (i=0; i < processedImg->nrow; i++) {
    for (j=0; j < processedImg->ncol; j++) {
      processedImg->data[i][j] = 0;
    }
  }

  for (k1=0; k1 < controlInfo->pixelOrderList.npoint; k1++) {
    ccol = col + controlInfo->pixelOrderList.dList[k1].x;
    crow = row + controlInfo->pixelOrderList.dList[k1].y;
    if (ccol >=0 && ccol < initLabel->ncol &&
	crow >=0 && crow < initLabel->nrow) {
      if (initLabel->data[crow][ccol] == thelabel) {
	controlInfo->alabelregion.dList[k].x = 
	  controlInfo->pixelOrderList.dList[k1].x;
	controlInfo->alabelregion.dList[k].y = 
	 controlInfo-> pixelOrderList.dList[k1].y;
	if (controlInfo->alabelregion.xy[0].x > 
	    controlInfo->alabelregion.dList[k].x)
	  controlInfo->alabelregion.xy[0].x = 
	    controlInfo->alabelregion.dList[k].x;
	if (controlInfo->alabelregion.xy[0].y > 
	    controlInfo->alabelregion.dList[k].y)
	  controlInfo->alabelregion.xy[0].y = 
	    controlInfo->alabelregion.dList[k].y;
	/* Maximum number */
	if (controlInfo->alabelregion.xy[1].x < 
	    controlInfo->alabelregion.dList[k].x)
	  controlInfo->alabelregion.xy[1].x = 
	    controlInfo->alabelregion.dList[k].x;
	if (controlInfo->alabelregion.xy[1].y < 
	    controlInfo->alabelregion.dList[k].y)
	  controlInfo->alabelregion.xy[1].y = 
	    controlInfo->alabelregion.dList[k].y;
	
	controlInfo->alabelregion.dList[k].z =
	  orgimage->data[crow][ccol];
	k++;
	if (k== controlInfo->alabelregion.npoint) break;
      }
    }
  }
  //thelabel = 1 + (2-thelabel);
  if (k != controlInfo->alabelregion.npoint) {
    printf("Not enough data points at <%d,%d>", col, row);
  }
  bestDist = 255.*255.*controlInfo->alabelregion.npoint;
  k3 = 0;
  do {
    k1 = 0;
    do {
      i = (int)(Unit_Random() * orgimage->nrow);
      j = (int)(Unit_Random() * orgimage->ncol);
      if (i>=0 && i < orgimage->nrow &&
	  j>=0 && j < orgimage->ncol ) {
	if (maskImg->data[i][j] == thelabel &&
	    processedImg->data[i][j]==0) {
	  if (abs(i-row) >= controlInfo->exclude_size &&
	      abs(j-col) >= controlInfo->exclude_size ) {
	    break;
	  }
	}
      }
      k1++;
    } while(k1 <= 1000);
    if (k1 > 1000) {
      printf("Warning: only %d sites found for distance calculation.\n",
	     k3);
      break;
    }
    k2 = 0;
    dist =0.0;
    for (k1=0; k1< k; k1++) {
      crow = controlInfo->alabelregion.dList[k1].y + i;
      ccol = controlInfo->alabelregion.dList[k1].x + j;
      if ( ccol >=0 && ccol < initLabel->ncol &&
	   crow >=0 && crow < initLabel->nrow) {
	if (maskImg->data[crow][ccol] != thelabel)
	  break;
	dist += (controlInfo->alabelregion.dList[k1].z-
		 orgimage->data[crow][ccol])*
	  (controlInfo->alabelregion.dList[k1].z-
	   orgimage->data[crow][ccol]);
	k2++;
      }
      else {
	break;
      }
    }
    if (k2 == k) {
      dist /= k2;
      k3++;
      processedImg->data[i][j] = 1;
      if (bestDist > dist) {
	bestDist = dist;
	if (bestDist < alabel->histUnit ) {
	  break;
	}
      }
      /* Check the 8-neighbors to see whether */
      //localBest = bestDist;
      localBest = dist;
      do {
	foundMin = -1;
	for (k4=0; k4 < 8; k4++) {
	  trow = Neighbor_Table[k4].y+i;
	  tcol = Neighbor_Table[k4].x+j;
	  if (trow < 0 || trow >= orgimage->nrow) continue;
	  if (tcol < 0 || tcol >= orgimage->ncol) continue;
	  if (maskImg->data[trow][tcol] != thelabel ||
	      processedImg->data[trow][tcol] !=0) continue;
	  if (abs(trow-row) < controlInfo->exclude_size ||
	      abs(tcol-col) < controlInfo->exclude_size ) {
	    continue;
	  }
	  k2 = 0;
	  dist =0.0;
	  for (k1=0; k1< k; k1++) {
	    crow = controlInfo->alabelregion.dList[k1].y + trow;
	    ccol = controlInfo->alabelregion.dList[k1].x + tcol;
	    if ( ccol >=0 && ccol < initLabel->ncol &&
		 crow >=0 && crow < initLabel->nrow) {
	      if (maskImg->data[crow][ccol] != thelabel)
		break;
	      dist += (controlInfo->alabelregion.dList[k1].z-
		       orgimage->data[crow][ccol])*
		(controlInfo->alabelregion.dList[k1].z-
		 orgimage->data[crow][ccol]);
	      k2++;
	    }
	    else {
	      break;
	    }
	  }
	  if (k2 == k) {
	    dist /= k2;
	    //k3++;
	    processedImg->data[trow][tcol] = 1;
	    if (localBest > dist) {
	      localBest = dist;
	      foundMin = k4;
	      if (localBest < alabel->histUnit ) {
		break;
	      }
	    }
	  }
	}
	if (foundMin != -1) {
	  i = Neighbor_Table[foundMin].y+i;
	  j = Neighbor_Table[foundMin].x+j;
	}
      } while(foundMin != -1);
      if (bestDist > localBest) {
	bestDist = localBest;
	if (bestDist < alabel->histUnit ) {
	  break;
	}
      }
    }
    
  } while (k3 <100);
  bestDist = sqrtf(bestDist);
  return bestDist;
}


int RefineLabelPoint(IMAGEINT *orgimage, IMAGEINT *initLabel,
		     REGION_LABEL *alabel, IMAGEINT *maskImg,
		     CONTROL_INFO *controlInfo,
		     int col, int row,
		     int otherLabel)
{
  int Labels[2];
  int i,j,k;
  int crow, ccol;
  float prob[2];
  int sameLabels[2];
  int checkWinSize;

  checkWinSize = 2;
  
  Labels[0] = initLabel->data[row][col];
  Labels[1] = otherLabel;
  sameLabels[0]=0;
  for (i=0-checkWinSize; i<=checkWinSize; i++) {
    for (j=0-checkWinSize; j<=checkWinSize; j++) {
      crow = row+i;
      ccol = col+j;
      if (crow >=0 && crow < initLabel->nrow &&
	  ccol >=0 && ccol < initLabel->ncol) {
	sameLabels[0] += (initLabel->data[crow][ccol] == Labels[0] );
      }
    }
  }
			  
 
  
  prob[0] = CalcRMS_Prob(orgimage, initLabel, &(alabel[Labels[0]]),maskImg,
			 col, row, 
			 controlInfo) + 
    controlInfo->boundWeight*((float)sameLabels[0])/
    ((float)(((2*checkWinSize+1)*(2*checkWinSize+1))));
  
  initLabel->data[row][col] = Labels[1];
 
  sameLabels[1]=0;
  for (i=0-checkWinSize; i<=checkWinSize; i++) {
    for (j=0-checkWinSize; j<=checkWinSize; j++) {
      crow = row+i;
      ccol = col+j;
      if (crow >=0 && crow < initLabel->nrow &&
	  ccol >=0 && ccol < initLabel->ncol) {
	sameLabels[1] += (initLabel->data[crow][ccol] == Labels[1] );
      }
    }
  }
			  
 
  prob[1] = CalcRMS_Prob(orgimage, initLabel, &(alabel[Labels[1]]),maskImg,
			 col, row,
			 controlInfo)+
    controlInfo->boundWeight*((float)sameLabels[1])/
    ((float)(((2*checkWinSize+1)*(2*checkWinSize+1))));
  if (prob[1] > prob[0])
    return 1;
  
  initLabel->data[row][col] = Labels[0];
  return 0;
}

int RefineLabelImage(IMAGEINT *orgimage, IMAGEINT *initLabel,
		     IMAGEINT *maskImg,
		     REGION_LABEL *alabel, 
		     CONTROL_INFO *controlInfo)
{
  int i,j,k,k1,k2;
  char fname[256];
  int iter =0;
  int updated;
  int crow, ccol;
  for (k=1; k<= controlInfo->npoint; k++) {
    alabel[k].regThres = 1000;
  }
  do {
    updated = 0;
    printf("Iteration %d -> ", iter);
    for (i=0; i < (initLabel->nrow); i++) {
      printf("%d ",i);
      fflush(stdout);
      for (j=0; j < (initLabel->ncol); j++) {
	if (initLabel->data[i][j] == 0) continue;
	for (k=0; k < 8; k++) {
	  crow = Neighbor_Table[k].y+i;
	  ccol = Neighbor_Table[k].x+j;
	  if (ccol >= 0 && ccol < initLabel->ncol &&
	      crow >= 0 && crow < initLabel->nrow) {
	    if ( (initLabel->data[crow][ccol] != initLabel->data[i][j])) {
	      if (initLabel->data[crow][ccol] == 0) {
		initLabel->data[crow][ccol] = initLabel->data[i][j];
		continue;
	      }
	      k1 = RefineLabelPoint(orgimage, initLabel,
				    alabel, maskImg,
				    controlInfo,
				    j,i,
				    initLabel->data[crow][ccol]);
	      updated += k1;
	      if (k1) break;
	    }
	  }
	}
      }
    }
    Remove_Small_Holes(alabel, initLabel);
    printf("Iteration: %d with %d updated.\n", iter, updated);
    iter++;
    if (updated > 100) {
      sprintf(fname,"%s_RMS_%d.pgm",controlInfo->prefix,iter);
      Write_An_Image_Int(initLabel, 
			 (int)(255/(controlInfo->npoint+1)), fname);
    }
  } while(updated >10 && iter != controlInfo->iterationAtMost);
  return;
}

void BuildProbModel(IMAGEINT *orgimage, IMAGEINT *initLabel,
		    IMAGEINT *labelmask,
		    REGION_LABEL *alabel,
		    CONTROL_INFO *controlInfo)
{
 
  int i,j,k,k1,k2;
  int ccol, crow;
  float dist;
  IMAGEINT flagimage;

  flagimage.nrow = 0;
  Create_An_Image_Int_Init(orgimage->nrow, orgimage->ncol, 
			   &flagimage, (int)0);
  for (k=1; k <= controlInfo->npoint; k++) {
    alabel[k].seedPoint = controlInfo->seedPoints[k-1];
    alabel[k].histUnit = 1.0;
    //alabel[k].histLen = (int)(255.0/alabel[k].histUnit) + 1;
    alabel[k].histLen = 100;
    alabel[k].probHist = (float *)malloc(sizeof(float)*alabel[k].histLen);
    for (i=0; i<alabel[k].histLen; i++)
      alabel[k].probHist[i] = 0.0;
  }
  printf("Building probability model: ");
  for (i=0; i < labelmask->nrow; i++) {
    printf("%d ",i);
    fflush(stdout);
    for (j=0; j < labelmask->ncol; j++) {
      if (labelmask->data[i][j] == 0) continue;
      k = labelmask->data[i][j];
      dist = CalcRMS_Distance_Random(orgimage, initLabel,
				     &(alabel[k]), labelmask,
				     j, i,
				     controlInfo, &flagimage);
      
      k1 = (int)(dist/alabel[k].histUnit);
      if (k1 < alabel[k].histLen) {
	alabel[k].probHist[k1] += 1.0;
      }
    }
  }
  for (k=1; k <= controlInfo->npoint; k++) {
    Smoothing_Hist(alabel[k].probHist, alabel[k].histLen, (int)5);
  }
  printf("\n");
  for (k=1; k <= controlInfo->npoint; k++) {
    dist = 0.0;
    for (i=0; i < alabel[k].histLen; i++)
      dist += alabel[k].probHist[i];
    for (i=0; i < alabel[k].histLen; i++)
      alabel[k].probHist[i] /= dist;
  }
  Print_Prob_Model(alabel, controlInfo);
  Free_Image_Int(&flagimage);
}

int Save_Prob_Model(char *fName, 
		    REGION_LABEL *alabel,
		    CONTROL_INFO *controlInfo)
{
  int i, k;
  FILE *fp;
  fp = fopen(fName,"wb");
  for (k=1; k <= controlInfo->npoint; k++) {
    fprintf(fp,"%d %d %d %10.8f %d\n", 
	    k, alabel[k].seedPoint.x,alabel[k].seedPoint.y, 
	    alabel[k].histUnit, alabel[k].histLen);
    for (i=0; i<alabel[k].histLen; i++)
      fprintf(fp,"%12.10f ", alabel[k].probHist[i]);
    fprintf(fp,"\n");
  }
  fclose(fp);
  return 0;
}


int Load_Prob_Model(char *fName, 
		    REGION_LABEL *alabel,
		    CONTROL_INFO *controlInfo)
{
  int i,k;
  FILE *fp;
  fp = fopen(fName,"rb");
  if (fp == NULL) return -1;
  for (k=1; k <= controlInfo->npoint; k++) {
    fscanf(fp,"%d%d%d%f%d",
	   &i,&(alabel[k].seedPoint.x),
	   &(alabel[k].seedPoint.y),
	   &(alabel[k].histUnit), 
	   &(alabel[k].histLen));
    if (i != k) {
      printf("Invalid data format when loading from '%s'\n",
	     fName);
      for (i=1; i<k; i++) {
	free(alabel[k].probHist);
	return -1;
      }
    }
    alabel[k].probHist = (float *)malloc(sizeof(float)*alabel[k].histLen);
    for (i=0; i<alabel[k].histLen; i++)
      fscanf(fp,"%f", &(alabel[k].probHist[i]));
  }
  fclose(fp);
  return 0;
}

void Print_Prob_Model(REGION_LABEL *alabel,
		      CONTROL_INFO *controlInfo)
{
  int k,i;
  for (k=1; k <= controlInfo->npoint; k++) {
    printf("For label %d at <%d,%d>: unit = %6.4f len = %d\n\t",k,
	   alabel[k].seedPoint.x,alabel[k].seedPoint.y, 
	   alabel[k].histUnit, alabel[k].histLen);
    for (i=0; i<alabel[k].histLen; i++)
      printf("%6.4f ",alabel[k].probHist[i]);
    printf("\n");
  }
  return;
}

void Free_Prob_Model(REGION_LABEL *alabel,
		     CONTROL_INFO *controlInfo)
{
  int k;
  for (k=1; k <= controlInfo->npoint; k++) {
    free(alabel[k].probHist);
  }
  return;
}

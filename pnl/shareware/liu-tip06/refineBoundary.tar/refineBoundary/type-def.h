#if !defined(TYPE_DEF_H_H)
#define TYPE_DEF_H_H

#define MAX_LABEL_IMAGE 100

#if !defined(MAXFILENAME)
#define MAXFILENAME 256
#endif

typedef float **MAT;
typedef int   **MAT_I;
typedef float  *ARRAY;
typedef float ***MAT_VECT;
typedef double **DMAT;

typedef struct {
  int ht, wid;
  MAT kernel;
}  MY_KERNEL;

typedef struct {
  int x, y;
} POINT2D;

typedef struct {
  int x, y, z;
} POINT3D;

typedef struct {
  POINT3D *dList;
  int npoint;
  POINT2D xy[2];
} REGION_LIST;

typedef struct {
  int nrow, ncol;
  MAT_I data;
} IMAGEINT;

typedef struct {
  int nrow, ncol;
  MAT data;
} IMAGEFLOAT;

typedef struct {
  int   len;
  ARRAY fvector;
  ARRAY refineVec;
  POINT2D seedPoint;
  float threshold;
  float regThres;
  int   label;
  int   segWin, segWsize;
  IMAGEFLOAT resImg;
  float peakVal;
  int   wsize;
  int   bound_x, bound_y;
  int   refWin, refWsize;
  int   seed_row, seed_col;
  float lammda;
  int   histLen;
  float *probHist;
  float histUnit;

} REGION_LABEL;

typedef struct {
  int nrow, ncol, len;
  int wsize_x, wsize_y;
  MAT_VECT  data;
} IMAGEVECTOR;



typedef struct {
  char    name[256];
  int     id;
  int     scale;
  int     wid, ht;          /* TRUE kernel width and height x scale  **/
  ARRAY   kernel;          /* the matrix kernel read as a linear array **/
  int     size;             /* =(2wid+1)/scale  x (2*ht+1)/scale   **/
  int     *rlist, *clist;   /* the coordinate for the sparse filters**/
  int     bin_num;
  float   unit;             /* the length of each bin */
  ARRAY   mark;             /* bin_num-1 marks to split the response
                               into bin_num intervals*/
  ARRAY   hist;
 }   FILTER;

typedef struct {
  int nfilter;
  FILTER *fbank;
  int nlevel;
  POINT2D *winLevels;
  int longestBin;
  int totalBin;
  int clevel;
  int max_wid, max_ht;
  int *filterDim;
} FILTERBANK;


typedef struct {
  char  inputFile[MAXFILENAME];
  char  probModel[MAXFILENAME];
  char  segFile[MAXFILENAME];
  char  filterFile[MAXFILENAME];
  char  prefix[MAXFILENAME];
  char  histMark[MAXFILENAME];
  /* Relax factor between a labeled region and the background */
  float lammda;
  int   topWin;
  int   segWin;
  int   segWinSize;
  int   npoint;
  float boundWeight;
  POINT2D seedPoints[MAX_LABEL_IMAGE];
  int refinedWin;
  int  boundRefineWin, boundRefineNPoint;
  int  interactive;
  int  seed;
  REGION_LIST pixelOrderList;
  REGION_LIST alabelregion;
  int iterationAtMost;
  int exclude_size;
} CONTROL_INFO;


#define  Residue(x)  ( (x)>=0 ? (x)%Mat_Size : (x+Mat_Size) )
#define  sq(x)       ((x)*(x))
#define  B(i)        printf(" pass break %d \n", i);

#endif






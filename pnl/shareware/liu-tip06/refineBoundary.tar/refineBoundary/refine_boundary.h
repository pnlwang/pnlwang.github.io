#if !defined(REFINE_BOUNDARY_H_H)
#define REFINE_BOUNDARY_H_H
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "type-def.h"
#include "util.h"
#include "imageio.h"
#include "functions.h"
#if defined(REFINE_BOUNDARY_SOURCE_C_C)
extern POINT2D Neighbor_Table[];

#define EXTERN_FLAG
#else
#define EXTERN_FLAG extern
#endif

EXTERN_FLAG void Contract_Regions(IMAGEINT *animage, IMAGEINT *labelmask, 
				  CONTROL_INFO *controlInfo);
EXTERN_FLAG float CalcRMS_Prob(IMAGEINT *orgimage, IMAGEINT *initLabel,
			       REGION_LABEL *alabel, IMAGEINT *maskImg,
			       int col, int row, CONTROL_INFO *controlInfo);

EXTERN_FLAG 
float CalcRMS_Distance(IMAGEINT *orgimage, IMAGEINT *initLabel,
		       REGION_LABEL *alabel, IMAGEINT *maskImg,
		       int col, int row, 
		       CONTROL_INFO *controlInfo);
EXTERN_FLAG 
float CalcRMS_Distance_Random(IMAGEINT *orgimage, IMAGEINT *initLabel,
			      REGION_LABEL *alabel, IMAGEINT *maskImg,
			      int col, int row, CONTROL_INFO *controlInfo,
			      IMAGEINT *processedImg);

EXTERN_FLAG 
int RefineLabelPoint(IMAGEINT *orgimage, IMAGEINT *initLabel,
		     REGION_LABEL *alabel,IMAGEINT *maskImg,
		     CONTROL_INFO *controlInfo,
		     int col, int row,
		     int otherLabel);

EXTERN_FLAG 
int RefineLabelImage(IMAGEINT *orgimage, IMAGEINT *initLabel,
		     IMAGEINT *maskImg,
		     REGION_LABEL *alabel,
		     CONTROL_INFO *controlInfo);


EXTERN_FLAG void BuildProbModel(IMAGEINT *orgimage, IMAGEINT *initLabel,
				IMAGEINT *labelmask,
				REGION_LABEL *alabel,
				CONTROL_INFO *controlInfo);

EXTERN_FLAG int Save_Prob_Model(char *fName, 
				REGION_LABEL *alabel,
				CONTROL_INFO *controlInfo);
EXTERN_FLAG int Load_Prob_Model(char *fName, 
				REGION_LABEL *alabel,
				CONTROL_INFO *controlInfo);

EXTERN_FLAG void Print_Prob_Model(REGION_LABEL *alabel,
				  CONTROL_INFO *controlInfo);

EXTERN_FLAG void Free_Prob_Model(REGION_LABEL *alabel,
				 CONTROL_INFO *controlInfo);
#undef  EXTERN_FLAG
#endif

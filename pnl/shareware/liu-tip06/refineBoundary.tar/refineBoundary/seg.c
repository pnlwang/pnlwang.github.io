#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#include "type-def.h"
#include "util.h"
#include "kernel.h"
#include "imageio.h"
#include "smoothing.h"
#include "para-util.h"
#include "refine_boundary.h"

int main(int argc, char **argv)
{
  char paraFile[256];
  IMAGEINT obsImg;
  IMAGEINT initRes, maskImg;
  int windex, upindex;
  int wsize;
  char prefix[256];
  char fname[256];
  int i,k,j,k1,k2;
  CONTROL_INFO  para_setting;
  REGION_LABEL  *regionLabels;
  FILTERBANK  fbank;
  if (argc < 1) {
    printf("Please specify the parameter file: ");
    scanf("%s", paraFile);
  }
  else {
    strcpy(paraFile, argv[1]);
  }
  
  LoadParameter(paraFile, &para_setting);
  DisplayParameter(&para_setting);
  
  srand(para_setting.seed);

  fbank.nfilter = 0;
  obsImg.nrow = 0;
  initRes.nrow = 0;
  maskImg.nrow = 0;
  
  Read_An_Image_Int(para_setting.inputFile, &obsImg);
  Read_An_Image_Int(para_setting.segFile, &initRes);
  if ( (obsImg.nrow != initRes.nrow) || 
       (obsImg.ncol != initRes.ncol)) {
    printf("The size of input image <%d,%d> does not match ",
	   obsImg.ncol, obsImg.nrow);
    printf(" with the starting segmentation image <%d,%d>.\n",
	   initRes.ncol,initRes.nrow);
    Free_Image_Int(&obsImg);
    Free_Image_Int(&initRes);
    return -1;
  }
  
  Read_Filters(para_setting.filterFile, &fbank);
  
  if (para_setting.topWin >= fbank.nlevel)
    para_setting.topWin = fbank.nlevel-1;
  if (para_setting.segWin > para_setting.topWin) {
    para_setting.segWin = para_setting.topWin;
  }
  para_setting.segWinSize = fbank.winLevels[para_setting.segWin].x;
  printf("Segmentation boundary size: %d\n", para_setting.segWinSize);
  sprintf(fname,"%s_input.pgm", para_setting.prefix);
  Write_An_Image_Int(&obsImg, (int)1, fname);
  sprintf(fname,"%s_init.pgm", para_setting.prefix);
  Write_An_Image_Int(&initRes, (int)1, fname);
  /*
  i = 1;
  if (para_setting.histMark[0] != '\0') {
    i = Read_Filter_Marks(para_setting.histMark, &fbank);
  }
  if (i !=0 ) {
    Generate_Marks_From_Image(&fbank, &obsImg);
  }
  sprintf(fname,"%s_mark.dat", para_setting.prefix);
  */
  /*if (para_setting.histMark[0] != '\0' && i ==0) {
    i = strcmp(fname, para_setting.histMark);
  }
  */
  /* Save the marks when necessary */
  /*
  if (i !=0) 
    Save_Filter_Marks(fname,&fbank);
  */
  /* Check values here */
 
  
  /*
  Homogeous_Layer_Test_Before(&fbank,
			      &obsImg,
			      &para_setting);
  */
  para_setting.alabelregion.dList =
    (POINT3D *)malloc(sizeof(POINT3D)*para_setting.boundRefineNPoint);
  para_setting.alabelregion.npoint = para_setting.boundRefineNPoint;
  para_setting.pixelOrderList.dList =
    (POINT3D *)malloc(sizeof(POINT3D)*(para_setting.segWinSize*2+1)*
		      (para_setting.segWinSize*2+1)*4);
  k = 0;
  para_setting.pixelOrderList.dList[k].x = 0;
  para_setting.pixelOrderList.dList[k].y = 0;
  k++;
  for (i=1; i <= 2*para_setting.segWinSize; i++) {
    for (j=0-i; j <= i; j++) {
      para_setting.pixelOrderList.dList[k].x = j;
      para_setting.pixelOrderList.dList[k].y = i;
      k++;
    }
    for (j=i; j > (0-i); j--) {
      para_setting.pixelOrderList.dList[k].x = i;
      para_setting.pixelOrderList.dList[k].y = j;
      k++;
    }
    
    for (j=i; j >= (0-i); j--) {
      para_setting.pixelOrderList.dList[k].x = j;
      para_setting.pixelOrderList.dList[k].y = 0-i;
      k++;
    }
    for (j=0-i; j < i; j++) {
      para_setting.pixelOrderList.dList[k].x = 0-i;
      para_setting.pixelOrderList.dList[k].y = j;
      k++;
    }
    
  }
  para_setting.pixelOrderList.npoint = k;
  /*for (k=0; k < para_setting.pixelOrderList.npoint; k++) {
    printf("%d -> %d %d\n", k, para_setting.pixelOrderList.dList[k].x,
	   para_setting.pixelOrderList.dList[k].y);
  }
  */
  Contract_Regions(&initRes, &maskImg, &para_setting);
  sprintf(fname,"%s_init_core.pgm", para_setting.prefix);
  Write_An_Image_Int(&maskImg, (int)1, fname);
  sprintf(fname,"%s_init_Label.pgm", para_setting.prefix);
  Write_An_Image_Int(&initRes, (int)1, fname);
  regionLabels = (REGION_LABEL *)malloc(sizeof(REGION_LABEL)*
					(para_setting.npoint+1));
  i = 1;
  if (para_setting.probModel[0] != '\0') {
    i = Load_Prob_Model(para_setting.probModel, regionLabels,&para_setting);
    if (i ==0) {
      Print_Prob_Model(regionLabels,&para_setting);
    }
  }
  else {
    sprintf(para_setting.probModel,"%s_Prob.dat",para_setting.prefix);
  }
  if (i !=0) {
    BuildProbModel(&obsImg, &initRes, &maskImg, 
		   regionLabels, &para_setting);
    Save_Prob_Model(para_setting.probModel, regionLabels,&para_setting);
  }

  RefineLabelImage(&obsImg, &initRes, 
		   &maskImg,
		   regionLabels, &para_setting);
  
  sprintf(fname,"%s_Final_Label.pgm", para_setting.prefix);
  Write_An_Image_Int(&initRes, (int)(255/(para_setting.npoint+1)), fname);
  
  Free_Prob_Model(regionLabels,&para_setting);
  free(regionLabels);
  free(para_setting.pixelOrderList.dList);
  free(para_setting.alabelregion.dList);
  Free_Filter_Bank(&fbank);
  
  Free_Image_Int(&obsImg);
  Free_Image_Int(&initRes);
  Free_Image_Int(&maskImg);
  return 0;
}









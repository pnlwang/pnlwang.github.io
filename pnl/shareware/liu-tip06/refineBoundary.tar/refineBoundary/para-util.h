#if !defined(_PARA_UTIL_H_H)
#define _PARA_UTIL_H_H

#include  <stdio.h>
#include <math.h>
#include "type-def.h"

#if defined(PARA_UTIL_SOURCE_CODE)

#if !defined(MAXFILENAME)
#define MAXFILENAME 256
#endif

#define EXTERN_FLAG
#else
#define EXTERN_FLAG extern
#endif

EXTERN_FLAG  void SetDefaultParameter(CONTROL_INFO *controlInfo);
EXTERN_FLAG  void DisplayParameter(CONTROL_INFO *controlInfo);
EXTERN_FLAG  int LoadParameter(char *fName,CONTROL_INFO *controlInfo);
/*
EXTERN_FLAG  ;
*/
#undef  EXTERN_FLAG


#endif









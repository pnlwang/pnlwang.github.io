This C program implmentes the singing voice pitch detection algorithm presented in the following papers:

Li Y. and Wang D.L. (2005): Detecting pitch of singing voice in polyphonic audio, in Proceedings of ICASSP-05, pp. III.17-20.
Li Y. and Wang D.L. (2007): Separation of singing voice from music accompaniment for monaural recordings, IEEE Transactions on Audio, Speech, and Language Processing, vol. 15, pp. 1475-1487. (Note that singing voice detection is not included in this program.)

We distribute these programs freely, but please cite the paper if you have made any use of these programs.

To use this program:
1. Open the project file with Microsoft Visual Studio and build the project
2. Run the program with the following format: "program.exe <input_file> <pitch1> <pitch2>". The first command line argument is the input file name. Note that the input file has to be an ascii file (To create such a file from a .wav file, use the wavread() command in MATLAB and scale the result with pow2(15). If you don't have MATLAB installed, then simply extract data from the data field as 16-bit integers). The second and thir arguments are the names of pitch files. Predominant pitches are stored in the first file (<pitch1>).
 
Two samples input files are provided in the signals folder: IDroveAllNight_mix.txt and IDroveAllNight_vol.txt. The first one is a mixture of singing and accompaniment. The second one is singing voice only. if you run the program on these two files and plot the two pitch1 files, you will see a figure like result.tif.
 
If you have questions regarding compiling or running the program, please contact me. But for other questions, I can only provide minimal assistance since I graduated and have been working full time.

By Yipeng Li
Email: li.434@osu.edu
URL: http://www.cse.ohio-state.edu/~liyip

I was with
Prof. DeLiang Wang
Perception and Neurodynamics Laboratory
Department of Computer Science and Engineering
The Ohio State University
URL: http://www.cse.ohio-state.edu/~dwang


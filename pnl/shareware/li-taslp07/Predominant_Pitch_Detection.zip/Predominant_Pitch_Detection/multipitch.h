#if !defined(MULTIPITCH_H)
#define MULTIPITCH_H

#include <stdio.h>
#include "common.h"
#include "type-def.h"
#include "pitch-tracking.h"
#include "mem-util.h"
#include "file-util.h"

/* Input signal file name */
#define INPUT_FILE "signals\\IDroveAllNight_vol.txt" 

/* Output pitch files */
#define OUTPUT_FILE_1 "data\\pitch1_vol"
#define OUTPUT_FILE_2 "data\\pitch2_vol"

#endif // MULTIPITCH_H
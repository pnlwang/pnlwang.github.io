/********************************************************************/
/* This C program is used for performing predominant pitch for	    */
/* singing voice. It is used in article:
/* Yipeng Li and DeLiang Wang (2005): "Detecting pitch of singing   */
/* voice in polyphonic auido", in proceedings of ICASSP, pp. III 17 */ 
/* -20 
/* It is adopted from the following	article:						*/
/* Mingyang Wu, DeLiang Wang, and Guy J. Brown (2003): "A			*/
/* multi-pitch tracking algorithm for noisy speech," IEEE Transactions 
/* on Speech and Audio Processing, vol. 11, no. 3, pp. 229-241.	    */
/*																	*/
/* This C program runs under Microsoft visual C++					*/
/********************************************************************/

#include "multipitch.h"

int main (int argc, char **argv)
{
	// usage: program input pitch1 pitch2

	INT1D *track1, *track2, *track3, *track4;
	int *signal, NumSamples;

	// load signal
	// input signal is a sequence of integers, if the inputs are float, 
	// this can be changed easily.
	signal=readSignalAscii(argv[1],&NumSamples);
	// signal=readSignalAscii(INPUT_FILE, &NumSamples);

	// track pitch
	NEW(track1); NEW(track2); // init mem of two pitch tracks
	NEW(track3); NEW(track4);
	Track_Pitch(signal, NumSamples, // signal input
		track1, track2, track3, track4,// two pitch track output
		N_ROOT, P_C0, P_C2); // model parameters

	// The 2 pitch tracks are written into OUTPUT_FILE_1 and 2
	// ASCII format, readable by matlab
	// Outputs are integers, which correspond to sample delay of pitch periods.
	// If wants frequency output, please use Fs/d, where Fs is the sample frequency 
	// and d is the output.
	Save_Int1D_Ascii(track1->array, track1->row, argv[2]);
	Save_Int1D_Ascii(track2->array, track2->row, argv[3]);	

	// Save_Int1D_Ascii(track1->array, track1->row, OUTPUT_FILE_1);
	// Save_Int1D_Ascii(track2->array, track2->row, OUTPUT_FILE_2);	
}
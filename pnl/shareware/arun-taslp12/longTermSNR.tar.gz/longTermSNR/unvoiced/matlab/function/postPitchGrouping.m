function [pt] = postPitchGrouping(pitchContourIn,sRate)

malecf = round(sRate/(16000/120)); 
pRange = [floor(sRate/(16000/40)), ceil(sRate/(16000/210))]; 
avrpitch = round(sRate/(16000/125));
JP = ceil(sRate/(16000/10)); 
JP2 = ceil(sRate/(16000/10));

minContourSize = 4;
minContourSize_2 = 8;

curlen = size(pitchContourIn,2);
nFrame = curlen;

% correction
count = 1;
for k = 1:size(pitchContourIn,1)
    if sum(pitchContourIn(k,:))~=0
        pitchContourIn1(count,:)=pitchContourIn(k,:);
        count = count + 1; 
    end
end
pitchContourIn = pitchContourIn1;

% produce real contours
count = 1;
for k = 1:size(pitchContourIn,1)
    tmpPC = pitchContourIn(k,:);
    len1 = sum(tmpPC>0);
    t1 = find(tmpPC,1,'first');
    t2 = find(tmpPC,1,'last');
    len2 = t2-t1+1;
    if len1~=len2 % 0's in contour
        pos = find(abs(diff(sign([tmpPC,0])))==1);
        for k=1:length(pos)/2         
            tfs = pos(2*(k-1)+1)+1:pos(2*k);
            pitchContour0(count,:) = zeros(1,size(pitchContourIn,2));
            pitchContour0(count,tfs) = tmpPC(tfs);            
            count = count + 1;
        end
    else
        pitchContour0(count,:) = tmpPC;
        count = count + 1;
    end
end

nContour = size(pitchContour0,1);
% rule out wrong contours
count=1;
pitchMaskLen = zeros(1,nContour);
pitchContour(1,:)= zeros(1,nFrame);
for k = 1:size(pitchContour0,1)
    contour = pitchContour0(k,:);
    ind = (contour>0);
    pitchMaskLen(k) = sum(ind);
    diffContour = diff(contour((contour>0)));
    maxDiff = max(max(abs(diffContour)));
    zeroRatio = sum(diffContour==0)/sum(contour>0);    
    wrongLen = sum((contour(ind)>pRange(2)))+sum((contour(ind)<pRange(1)));
    if (sum(contour>0)>=minContourSize_2 && (wrongLen/sum(contour>0) < 0.5)) || ...
            ((sum(contour>0)>=minContourSize) && (maxDiff <= JP) && (wrongLen/sum(contour>0) < 0.5)) % some robustness
        contour(contour>pRange(2)) = 0;
        contour(contour<pRange(1)) = 0;
        pitchContour(count,:) = contour;
        pInd(count) = k; % valid contour indices
        count = count+1;
    end
end
    

% create index for mask
nonoverlapping = find(sum(sign(pitchContour))==1);
maskInd = zeros(1,nFrame);
for k = 1:length(nonoverlapping)
    for n = 1:size(pitchContour,1)
        if pitchContour(n,nonoverlapping(k)) > 0
            maskInd(nonoverlapping(k)) = pInd(n);
        end
    end
end


% refining overlapping contours
test=sum(pitchContour>0);
ind=find(test>1);
while numel(ind)>0 && size(pitchContour,1)>1
    ind1=find(pitchContour(:,ind(1))>0); % index of overlapping frames
    pc1=pitchContour(ind1(1),:);
    pc2=pitchContour(ind1(2),:);
    pc_sign=sign(pc1)+sign(pc2);
    overlapping = find(pc_sign==2);
    longlen = max(sum(pc1>0),sum(pc2>0));
    shortlen = min(sum(pc1>0),sum(pc2>0));
    if longlen>shortlen*1.5
        mjudge = (sum(pc1>0) > sum(pc2>0));
    else
        mjudge = abs(mean(pc1(pc1>0))-malecf) <= abs(mean(pc2(pc2>0))-malecf);
    end
    fjudge = min(pc1(pc1>0)) < min(pc2(pc2>0));
    
    judge = fjudge || mjudge;
    
    if judge
        pitchContour(ind1(2),overlapping)=0;        
        curpt = pitchContour(ind1(1),:)+pitchContour(ind1(2),:);
        maxjump = max(abs(diff(curpt(pc_sign>0))));
        if maxjump >= JP (length(pitchContour(ind1(2),pitchContour(ind1(2),:) > 0)) < minContourSize_2)
            pitchContour(ind1(2),:) = 0;
        end
    else
        pitchContour(ind1(1),overlapping)=0;
        
        curpt = pitchContour(ind1(1),:)+pitchContour(ind1(2),:);
        maxjump = max(abs(diff(curpt(pc_sign>0))));
        if maxjump >= JP && (length(pitchContour(ind1(1),pitchContour(ind1(1),:) > 0)) < minContourSize_2)
            pitchContour(ind1(1),:) = 0;
        end        
    end   
        
    test=sum(sign(pitchContour));
    ind=find(test>1);
end
if size(pitchContour,1)>1
    pc = sum(pitchContour);
else
    pc = pitchContour;
end
pc = pc(:,1:end); % remove the last frame for consistency
pt = reshape(pc,1,length(pc));

ptorg = pt;

if sum(pt) == 0
    pt = pt > 0;
    return;
end

% Reorder contours
k = 1;
i = 1;
while i <= length(pt)
    if pt(i)~=0
        curCT = find(pitchContour(:,i) ~= 0);
        reordered(k) = curCT;
        i = find(pitchContour(curCT,:),1,'last');
        k = k+1;
    end
    i = i+1;
end
pCT = pitchContour(reordered,:);


for i = 1:size(pCT,1)-1
    curContour = pCT(i,:);
    st = find(curContour,1,'first');
    ed = find(curContour,1,'last');
    unrel = ((abs(diff(curContour(st:ed)))) >= JP2);
    
    if isempty(st) || isempty(unrel)
        continue;
    end
    if length(unrel) < minContourSize_2
        if sum(unrel)/length(unrel) >= 0.2 || sum(unrel) >= 2
            pCT(i,:) = 0;
            continue;
        end
    end

    nxtst = find(pCT(i+1,:),1,'first');
    if nxtst - ed <= 5 && abs(pCT(i,ed)-pCT(i+1,nxtst)) >= (nxtst-ed)*6
        judge = length(find(pCT(i,:)>0)) > length(find(pCT(i+1,:)>0));
        
        if (min(length(find(pCT(i,:)>0)),length(find(pCT(i+1,:)>0))) >= minContourSize_2);
            continue;
        else
            if judge
                pCT(i+1,:) = 0;
            else
                pCT(i,:) = 0;
            end
        end
    end
        
end
pt = sum(pCT,1);


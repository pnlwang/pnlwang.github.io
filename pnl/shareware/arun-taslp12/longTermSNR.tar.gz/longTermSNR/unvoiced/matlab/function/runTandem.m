function [successFlag allMasks pcN params] = runTandem(mixture, params)
%function [allMasks params] = runTandem(mixture, params)

% ensure paralle funning of this function
prefix = [params.workFolder,'/',datestr(now,30),'.tandem'];
while (size(dir([prefix,'*']))>0)
    pause(1);
    prefix = [params.workFolder,'/',datestr(now,30),'.tandem'];
end
params.prefix = prefix;

% write a temporary file
if params.Srate~=20000 % Newer versions of tandem require the sampling rate to be 20 kHz
    mixture = resample(mixture,20000,params.Srate);
end
params.mixFN = [prefix,'.mixture'];
dlmwrite(params.mixFN, mixture);
params.Srate_tandem = 20000;


% call the tandem algorithm and output response and envelope cross-channel
% correlations
params.tandemFN = prefix;
params.crossFN = [prefix,'.cross'];
params.evCrossFN = [prefix,'.evCross'];
params.engFN = [prefix,'.eng'];

if params.nChan == 128
    cmd = sprintf('!./tandem128 %s %s %s %s %s', params.mixFN,...
        params.tandemFN, params.crossFN, params.evCrossFN, params.engFN);
    eval(cmd);
    if ~exist(sprintf('%s.%d.pitch.dat',params.tandemFN,params.nChan),'file')
        allMasks=[];
        pcN=[];
        successFlag=0;
        return;
    end
    
    % load results
    msk = load([params.tandemFN,'.128.simul.dat'])>.5;
    pc = dlmread([params.tandemFN,'.128.pitch.dat']);
    pc = pc(:,1:end-1);
    nCon = pc(1,1); nFrm = pc(1,2);
    % convert to cell structure
    clear allMasks;
    count = 0;
    for k=2:nCon+1
        p = pc(k,:);
        if sum(p)
            count = count + 1;
            pcN(count,:) = p;
            allMasks{count}.pitch = p;
            allMasks{count}.msk = msk((k-2)*nFrm+1:(k-1)*nFrm,:)';
        end
    end
else
    cmd = sprintf('!./tandem64 %s %s %s %s %s', params.mixFN,...
        params.tandemFN, params.crossFN, params.evCrossFN, params.engFN);
    eval(cmd);
    
    if ~exist(sprintf('%s.%d.pitch.dat',params.tandemFN,params.nChan),'file')
        allMasks=[];
        pcN=[];
        successFlag=0;
        return;
    end
    
    % load results
    msk = load([params.tandemFN,'.64.simul.dat'])>.5;
    pc = dlmread([params.tandemFN,'.64.pitch.dat']);
    pc = pc(:,1:end-1);
    nCon = pc(1,1); nFrm = pc(1,2);
    % convert to cell structure
    clear allMasks;
    count = 0;
    for k=2:nCon+1
        p = pc(k,:);
        if sum(p)
            count = count + 1;
            pcN(count,:) = p;
            allMasks{count}.pitch = p;
            allMasks{count}.msk = msk((k-2)*nFrm+1:(k-1)*nFrm,:)';
        end
    end
end

successFlag=1;

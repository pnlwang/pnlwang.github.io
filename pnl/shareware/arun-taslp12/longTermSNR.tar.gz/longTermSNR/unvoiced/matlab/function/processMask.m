function [ibm,pitch] = processMask(allMasks,pcN,sRate) 
%[ibm,pitch] = processMask(maskFN,pitchFN,nChan)

% if nargin < 3
%     nChan = 128;
% end

% msk = load(maskFN);
% pc = dlmread(pitchFN);
% nCon = pc(1,1); nFrm = pc(1,2);   
% 
% if nCon == 0 %If tandem detects no pitch contours
%     ibm = zeros(nChan,nFrm); %all zero mask
%     pitch = zeros(nFrm,1) > 0; %all zero pitch contour
%     return;
% end
% 
% pc = pc(:,1:end-1);
% % verification
% frm1 = 0;
% for k=2:nCon+1
%     p = pc(k,:);
%     frm1 = frm1 + sum(p>0);
% end
% if frm1 == size(msk,1)-1
%     msk = msk(:,2:end);
%     maskSizeChanged=1;
% else
%     maskSizeChanged=0;
% end
% if frm1 ~= size(msk,1)
%     error('Dimensions of pitch and mask do not match!');
%     %break;
% end
% 
% % conversion
% count = 0;
% msk_st = 1;        
% for k=2:nCon+1
%     p = pc(k,:);
%     if sum(p)
%         count = count + 1;
%         pcN(count,:) = p;postPitchGrouping
%         allMasks{count}.pitch = p;
%         allMasks{count}.msk = zeros(nChan,nFrm);
%         st = find(p,1,'first');
%         ed = find(p,1,'last');
%         dummy = (p(st:ed)==0);                
%         msk_ed = msk_st+(ed-st)-sum(dummy);
%         idx = st:ed;
%         idx = idx(~dummy);
%         allMasks{count}.msk(:,idx) = msk(msk_st:msk_ed,:)';
%         msk_st = msk_ed+1;
%     end
% end    



% Method 2 - based on pitch continuity, plausible pitch range, overlapping, etc
tfsnr = zeros(size(allMasks{1}.msk));
pt = postPitchGrouping(pcN,sRate);

ind = find(pt>0);
for frInd=1:length(ind)
    fr = ind(frInd);
    pVal = pt(ind(frInd));
    
    contourInd = find(pcN(:,fr) == pVal,1,'first');
    tfsnr(:,fr) = (allMasks{contourInd}.msk(:,fr) + 1)/2;
end

pitch = pt > 0;
ibm = tfsnr > 0.5;
% if maskSizeChanged
%     ibm = [ibm(:,1),ibm];
% end
end

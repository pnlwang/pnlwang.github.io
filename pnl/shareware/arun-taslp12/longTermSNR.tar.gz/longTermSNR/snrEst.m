function [masks, snr] = snrEst(sig,params)
%Function to estimate the IBM and the SNRs
%Input
%   sig -   The signal. Can be the filename (in MSWAV format), or the actual
%           signal itself. The signal is assumed to be sampled at 16 KHz.
%   params - A structure with multiple fields
%       params.ebm          - The estimated mask or the filename containing the
%                               mask. If this parameter is sent, the mask is not estimated.
%       params.ebm_ke       - The mask estimated using CASA strategy (Ke's 2011
%                               paper). Could be the filename or the mask itself.
%       params.broadband    - This field should exist for broadband SNR estimation
%       params.subband      - This field should exist for subband SNR estimation
%       params.tmpDir       - The directory to store temporary files. If
%                               not passed, the current directory will be
%                               used instead. Ideal to set it somewhere on
%                               your /scratch directory.
%       params.numChan      - Number of frequency channels, defaults to 128. You can also use 64.

%Output
%     masks - The estimated masks. Contains c128 and c64 fields for 128
%               channel and 64 channel estimated IBMs, respectively.
%     snr - The estimated SNRs. May contain the following fields
%         snr.filtered    - The filtered SNR
%         snr.broadband   - The broadband SNR
%         snr.subband     - The subband SNRs
%

%% Set all the necessary parameters
if nargin < 2
    params = struct;
end
if isfield(params,'ebm') %The estimated binary mask
    ebm = params.ebm;
end
if isfield(params,'ebm_ke') %Mask estimated by Ke's algo, or any CASA based mask
    ebm_ke = params.ebm_ke;
end
if isfield(params,'tmpDir') %set temp working directory here
    tmpDir = params.tmpDir;
else
    tmpDir = pwd;
end
if isfield(params,'numChan') %Number of frequency channels
    numChan = params.numChan;
else
    numChan = 128;
end

%Set an initial dummy output
snr.readme = 'Estimated SNR values';
masks.readme = 'Estiamted IBMs';

%Necessary libraries
warning off all;
addpath(path,'./functions/');
addpath(path,'./Noise_Tracker_V1/');
addpath(path,'./Noise_Tracker_V1/TabGenGam/');
addpath('./unvoiced/');

%Parameters
wavnorm = 3.276797651191444e+004; %To convert mswav files to integer format
fs = 16000; %Sampling rate
numChan_subBand = 64; %Number of subbands for subband SNR estimation
fRange = [50 8000]; %The frequency range
winLength = 20*fs/1000; %20 msec window

%% Hendricks parameters
if ~exist('ebm','var') %Only if the estimated masks is not sent as a parameter
    load 'Hendricks_tab_gamma_1_nu_0.6.mat'; %Paramteres of clean speech DFT coefficient estimator
    options.fs = 16000; %Sampling rate, same as above
    options.nfft = 512; %FFT size
    options.fr_size = 20*options.fs/1000; %Window length
    options.D = options.fr_size/2; %Overlap
    options.alpha = 0.98; %Forgetting factor for DD SNR estimator
    LC_ratio_ke_hendricks = 10^(8/10); %The LC to create speech enhancement based mask
    
    % Normalized Gammatone filter mapping for snr estimation
    filterOrder = 4;    % filter order
    gL = options.nfft;           % To match Hendrix PSD estimator
    
    phase(1:numChan) = zeros(numChan,1);        % initial phases
    erb_b = hz2erb(fRange);       % upper and lower bound of ERB
    erb = [erb_b(1):diff(erb_b)/(numChan-1):erb_b(2)];     % ERB segment
    cf = erb2hz(erb);       % center frequency array indexed by channel
    b = 1.019*24.7*(4.37*cf/1000+1);       % rate of decay or bandwidth
    
    % Generating gammatone impulse responses with middle-ear gain normalization
    gt = zeros(numChan,gL);  % Initialization
    tmp_t = [1:gL]/fs;
    for i = 1:numChan
        gain = 10^((loudness(cf(i))-60)/20)/3*(2*pi*b(i)/fs).^4;    % loudness-based gain adjustments
        gt(i,:) = gain*fs^3*tmp_t.^(filterOrder-1).*exp(-2*pi*b(i)*tmp_t).*cos(2*pi*cf(i)*tmp_t+phase(i));
    end
    
    % Gammatone response normalization
    f=cf(3):cf(end-3); % the approximate plateu region
    gtf = zeros(numChan,length(f));
    for c=1:numChan
        gtf(c,:) = (1/3*(2*pi)^4)*factorial(filterOrder-1)*1/2*(b(c)./sqrt((2*pi*(f-cf(c))).^2+(2*pi*b(c))^2)).^filterOrder;
        gtf(c,:) = gtf(c,:).^2;
    end
    factor = sqrt(max(sum(gtf)));
    gt = gt/factor;
    
    pow_gt = abs((fft(gt'))').^2; %Gammatone response power in each bin.
    clear filterOrder gL phase erb erb_b cf f b tmp_t i gain gt gtf c factor;
end

%% IBM Estimation
if ischar(sig)
    sig = round(wavread(sig)*wavnorm);
end

if exist('ebm','var')
    if ischar(ebm)
        ebm = load(ebm);
    end
else
    if ~exist('ebm_ke','var')
	curDir=pwd;
	keWorkingDirectory='unvoiced/matlab/run';
        nFrames = floor(length(sig)/(winLength/2));
        
	cd(keWorkingDirectory);
	ebm_ke = unvoiced(sig,[75,400],'thresholding',numChan,16000,tmpDir);
	if ~numel(ebm_ke) %Something went wrong while estimating ebm_ke
	     cd(curDir);
	     snr.filtered=NaN;snr.broadband=NaN;snr.subband=NaN;
	     return;
	end
        cd(curDir);
    else
        if ischar(ebm_ke)
            ebm_ke = load(ebm_ke)>0;
        end
    end

    while size(ebm_ke,2) > nFrames
	ebm_ke = ebm_ke(:,1:end-1); %Remove the last frame first
        if size(ebm_ke,2) > nFrames
    	    ebm_ke = ebm_ke(:,2:end); %Remove the first frame now
        end
    end
    
    %Hendricks estimates
    [hendricks.dft.snr,noisetmp.psd,cleantmp.psd] = ...
        hendricks_snr_estimator_power(sig,options,g_dft,g_mag,g_mag2);
    
    hebm = pow_gt*cleantmp.psd >= LC_ratio_ke_hendricks*pow_gt*noisetmp.psd;
    raw_segments = segmentation(hebm',0);
    segments = refineSegmentation(raw_segments,3,3,0,0,0);
    hebm = (poolsegments(segments))'; clear raw_segments segments;
    
    %Expand if needed,
    if size(hebm,2) < size(ebm_ke,2)
        hebm = [hebm(:,1),hebm];
    end
    
    % The final estimated mask
    ebm = (ebm_ke + hebm) > 0;
end

if numChan==128
    masks.c128 = ebm; %Assumes numChan is 128.
else
    masks.c64 = ebm;
end

%% Broadband and filtered SNR
if isfield(params,'broadband')
    engy = cochleagram(gammatoneSNR(sig,numChan,fRange,fs),winLength);
    
    target = sum(sum(engy .* ebm));
    noise = sum(sum(engy)) - target;
    snr.filtered = 10*log10(target) - 10*log10(noise);
    
    ccgmEn = sum(sum(engy));
    diffEn = 2*sum(sig.^2) - ccgmEn;
    k=10^(snr.filtered/10);
    cleanEn = (k/(1+k))*ccgmEn;
    snr.broadband = 10*log10(cleanEn/(ccgmEn-cleanEn+max(0,diffEn)));
end

%% Channel SNRs, across 64 channels
if isfield(params,'subband')
    mix_cgm = cochleagram(gammatone(sig,numChan_subBand,fRange,fs),winLength); %Note that normalized gammatone is not used anymore, to match typical CASA processing (this will not have any affect on subband SNR)
    if numChan == 128
        ebm_64 = (ebm(1:2:end,:)+ebm(2:2:end,:)+[ebm(3:2:end,:);ebm(end,:)])>1.9; %Sub-sample the mask to 64 channels in a slightly better way
    else
        ebm_64 = ebm;
    end
    target_engy = sum(mix_cgm .* ebm_64,2);
    noise_engy = sum(mix_cgm,2) - target_engy;
    snr.subband = 10*log10(target_engy+realmin) - 10*log10(noise_engy+realmin);
    % Limit SNR estimates to the range [-20dB, 30dB]
    snr.subband(snr.subband<-20)=-20;
    snr.subband(snr.subband>30)=30;
    clear target_engy noise_engy ibm;
    
    masks.c64 = ebm_64;
end

%% Clear all variables
clear pow_gt sig ebm clgm evClgm pitchMask VMask pitch ebm_ke;
clear hendricks UMask raw_segments segments hebm;
clear engy target noise ccgmEn cleanEn mix_cgm ebm_64;
end

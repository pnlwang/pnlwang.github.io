function [segments, other_segments] = refineSegmentation(raw_segments,f,t,low_f,high_f,echo)

if nargin < 2
    f = 2;
    t = 2;
    low_f = 0;
    high_f = 0;
    echo = 1;
else if nargin < 4
        low_f = 0;
        high_f = 0;
        echo = 1;
    else if nargin < 6
            echo = 1;
        end
    end
end
    
segments{1} = zeros(size(raw_segments{1}));
other_segments{1} = zeros(size(raw_segments{1}));

if echo
    fprintf('refining segments...');
end

iSeg = 1; nSeg = 1;
for k = 1:length(raw_segments)
    dummy_seg = raw_segments{k};
    fpos = find(sum(dummy_seg) > 0);
    tpos = find(sum(dummy_seg, 2) > 0);
    f_len = length(fpos);
    time_len = length(tpos);
    
    if f_len > f && time_len > t && min(fpos)>low_f && max(fpos)>high_f
        segments{iSeg} = raw_segments{k};
        iSeg = iSeg + 1;
    else
        other_segments{nSeg} = raw_segments{k};
        nSeg = nSeg + 1;
    end    
end
if echo
    fprintf('%d retained.\n', iSeg - 1);
end

function segments = segmentation(mask, echo)

if nargin < 2
    echo = 0;
end

if echo
    fprintf('extracting segments...');
end

iSeg = 1;  % segment counter
D = size(mask,3);
[nFrame nChan]= size(mask);
segments{1} = zeros(nFrame,nChan);

for k = 1:D
    [labeledMask, N] = bwlabel(mask(:,:,k),4);
    for m = 1:N
        segments{iSeg} = (1-sign(abs(labeledMask-m)))*iSeg;
        iSeg = iSeg + 1;
    end
end
    
if echo
    fprintf('%d segments generated.\n', iSeg-1);  
end

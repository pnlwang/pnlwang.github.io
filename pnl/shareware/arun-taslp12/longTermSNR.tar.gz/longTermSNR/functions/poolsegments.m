function mask = poolSegments(segments)

numSeg = length(segments);
mask = zeros(size(segments{1}));
for k = 1:numSeg
    mask = mask + segments{k};
end
mask = sign(mask);
    
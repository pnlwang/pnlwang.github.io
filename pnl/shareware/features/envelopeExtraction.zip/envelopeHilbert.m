function [ev] = envelopeHilbert(input)

ev = abs(hilbert(input));
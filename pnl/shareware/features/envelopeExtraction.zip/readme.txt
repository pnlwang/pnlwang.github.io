This matlab program is a software implementation of amplitude modulation described in Section 3.2.3 of the following book chapter:

	D.L. Wang, "Feature-based speech segregation," in Computational Auditory Scene
	Analysis: Principles, Algorithms, and Applications, edited by D.L. Wang and G.J. Brown. New
	York: IEEE Press/Wiley, 2006.


There are two matlab programs: 
	
	"envelopeHilbert.m" extracts envelope directly using the Hilbert Transform function provided in Matlab.
	"envelopeFFT.m" extracts envelope using the FFT implementation of the Hilbert Transform function described in the chapter.

To use either program, type in the matlab environment:
	
	y = envelopeHilbert(x), or
	y = envelopeFFT(x)

	x is the input data.
	y is the extracted envelope of the input data.

We have also included some sample files:

	"input.dat": the waveform shown in Figure 3.3 of the book chapter, which is the response of a gammatone filter to a clean utterance. The sampling frequency is 20 kHz. The center frequency of the filter is 2.6 kHz.

	"output.dat": the extracted envelope.

The programs are written by Dr. Guoning Hu. They are freely distributed, but please cite the sources if you have made any use of the programs.

September 2006
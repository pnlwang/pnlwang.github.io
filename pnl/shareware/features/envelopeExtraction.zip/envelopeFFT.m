function [ev] = envelopeFFT(input)

% The input has to be 1-dimensional

HX = fft(input);

numSamples = length(input);
HEV = zeros(size(input, 1), size(input, 2));

if mod(numSamples, 2)==0
    halfSamples = numSamples/2;
    HEV(2:halfSamples) = HX(2:halfSamples)*2;
    HEV(1)= HX(1);
    HEV(halfSamples+1) = HX(halfSamples+1);
else
    halfSamples = round(numSamples/2);
    HEV(2:halfSamples) = HX(2:halfSamples)*2;
    HEV(1)= HX(1);
end

ev = abs(ifft(HEV));
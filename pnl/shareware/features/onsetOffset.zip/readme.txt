This matlab program, 'onsetOffsetDetection.m' is a software implementation of onset and offset detection described in Section 3.2.2 of the following book chapter:

	D.L. Wang, "Feature-based speech segregation," in Computational Auditory Scene
	Analysis: Principles, Algorithms, and Applications, edited by D.L. Wang and G.J. Brown. New
	York: IEEE Press/Wiley, 2006.


To use this program, type in the matlab environment:
	
	[onsetPos, offsetPos] = onsetOffsetDetection(x, scale, onsetTheta, offsetTheta)

	x: input data.
	scale: the standard deviation of the Guassian smoothing function.
	onsetTheta and offsetTheta: the thresholds for onset and offset detection, respectively.
	onsetPos and offsetPos: the positions (counted by samples) where onsets and offsets are detected.

We have also included some sample files:

	"input.dat": the intensity in dB of the response of a gammatone filter to a mixture of speech and crowd noise. The sampling frequency is 20 kHz. The center frequency of the filter is 500 Hz.

	"output.dat": the positions where onsets and offsets are detected with the following parameter values:
		scale = 16;
		onsetTheta = 0.05;
		offsetTheta = -0.05;

The programs are written by Dr. Guoning Hu. They are freely distributed, but please cite the sources if you have made any use of the programs.

September 2006
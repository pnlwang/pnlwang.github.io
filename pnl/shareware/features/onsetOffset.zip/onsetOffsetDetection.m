function [onsetPos, offsetPos] = onsetOffsetDetection(x, scale, onsetTheta, offsetTheta)

h=[-scale*4:scale*4];
g=-h.*exp(-h.*h/2/scale/scale)/sqrt(2*pi)/scale/scale/scale;
x1=conv(x, g);
x1=x1(scale*4+1:length(x)+scale*4);

[onsetPos]=find(x1(2:length(x1)-1)>x1(1:length(x1)-2) & x1(2:length(x1)-1)>x1(3:length(x1)) & x1(2:length(x1)-1)>onsetTheta);

[offsetPos]=find(x1(2:length(x1)-1)<x1(1:length(x1)-2) & x1(2:length(x1)-1)<x1(3:length(x1)) & x1(2:length(x1)-1)<offsetTheta);

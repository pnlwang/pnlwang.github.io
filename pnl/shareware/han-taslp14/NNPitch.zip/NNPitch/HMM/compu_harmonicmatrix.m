function [mat wmat] = compu_harmonicmatrix(h)

    freqscale = load('~/Kun/pitchtracking/utilities/pitch_candidates_freqz.txt');

    delta = freqscale(end)-freqscale(end-1);
    
    mat = zeros(length(freqscale), length(freqscale));
    
    for i = 1:length(freqscale)
        cur = freqscale(i);
        n = 2;
        mat(i, i) = h;        
        while cur*n < freqscale(end) + delta
            curhm = cur * n;
            absdiff = abs(curhm-freqscale);
            [mdiff mind] = min(absdiff);
            mat(mind, i) = h^n;
            n = n+1;
        end
    end
    w = sum(mat, 1);
    wmat = mat./repmat(w, length(freqscale), 1);    
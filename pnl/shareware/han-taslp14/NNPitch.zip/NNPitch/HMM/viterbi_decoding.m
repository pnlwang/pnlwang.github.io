function [V, PP, path] = viterbi_decoding(transProb, lklhood)

    transMat = transProb;    
    numF0 = size(transProb,1);
    
%     temp = sum(lklhood, 2);
%     idx = temp~=0;
%     lklhood(idx,:) = lklhood(idx,:)./repmat(temp(idx), 1, numF0);
%     lklhood(~idx,:) = 1/numF0;    
    
    % normalize, but not necessary
    temp = sum(transProb, 2);
    idx = temp~=0;
    transProb(idx,:) = transProb(idx,:)./repmat(temp(idx), 1, numF0);
    transProb(~idx,:) = 1/numF0;    
    transMat = transProb;
    
    loglklProb = log(lklhood');
    
    numP = 68;
    temp = transMat(1,1:numP);
    
    V = zeros(numP, size(lklhood, 1));  % posterior prob
    P = zeros(numP, size(lklhood, 1));  % path
    
    V(:,1) = log(temp') + loglklProb(:,1);

    for i = 2:size(loglklProb, 2)
        [temp, idx] = max(repmat(V(:,i-1), 1, numP) + log(transMat(1:numP, 1:numP)), [], 1);
        V(:,i) = temp' + loglklProb(:,i);
        P(:,i) = idx';
    end        
    
    % trace back to get the path
    path = [];
    PP = zeros(numP, size(lklhood, 1));
    [~, idx] = max(V(:,numP));
    for i = size(loglklProb, 2):-1:1
        path = [idx, path];
        PP(idx, i) = 1;
        idx = P(idx, i);        
    end    
    
end
function compute_transmat(speakers, lists)
% Collect statistics of the HMM model used to model the pitch trajectory of
% speech
%
% Author: Zhiyao Duan
% Created: 3/20/2013
%

% clc; clear; close all;
% minF0_midi = floor(hz2midi(65));
% maxF0_midi = ceil(hz2midi(370));
% numF0 = (maxF0_midi-minF0_midi)/0.5 + 1;    % number of F0 bins plus 1
% 
% transCount = zeros(numF0, numF0);

%% Do on each wav file

addpath('~/Kun/pitchtracking');
modeldir = sprintf('~/Kun/pitchtracking/Models'); 
   
% Noise and SNR is not important here
noises = {'NoiseX_babble0to2min'};
snrdb = -5;
if length(noises) == 1
        nsname = noises{1};
elseif length(noises) == 3
        nsname = 'BabFacHfc';
end
    
if isstr(speakers)
        gender = speakers;
        speakers = {gender};
elseif iscell(speakers) && length(speakers)==2
        gender = 'FemaleMale';
end

modelinfo = sprintf('TransMat_%s_List%dList%d',gender,lists(1),lists(end));
ModelFN = sprintf('%s/HMM_%s.mat',modeldir,modelinfo);
    
numF0 = 68;
Alltrans = zeros(numF0,numF0);

    for spki = 1:length(speakers)
        gender = speakers{spki};
        for nsi = 1:length(noises)
            noise = noises{nsi};    
                for list = lists
                    [noisex clx ranges] = collect_wav_ns(gender, list, noise, snrdb);                    
                    [Pt frranges ptfreq] = comp_gtpitch(clx, ranges);                    
                    transCount = count_tranmat(Pt, frranges);
                    Alltrans = Alltrans + transCount;
                end
        end
    end

transCount = Alltrans;
% prior probability
initP = sum(transCount, 2);
initP(initP~=0) = initP(initP~=0)/sum(initP);
figure; plot(initP); title('Initial state probability');

% transition matrix
temp = sum(transCount,2);
idx = temp~=0;
transMat(idx,:) = transCount(idx,:)./repmat(temp(idx), 1, numF0);
transMat(~idx,:) = 1/numF0;
figure; imagesc(transMat); title('Transition matrix');
priorProb = initP;
transProb = transMat;

save(ModelFN, 'priorProb', 'transProb');
end



function transCount = count_tranmat(Pt, frranges)
    len = length(frranges);
    numStat = size(Pt, 2);
    transCount = zeros(numStat, numStat);
    for i = 1:len
        curfr = frranges{i};
        curpt = Pt(curfr,:);
        
        for fr=1:length(curfr)-1
            in = find(curpt(fr,:)==1);
            out = find(curpt(fr+1,:)==1);
            transCount(in, out) = transCount(in, out) + 1;
        end
        
    end
end

% 
% for fnum=1:length(sFiles)            
%     sfile = sFiles(fnum).name;
%      %% training data are the first half
%     idx = strfind(sfile, '_');
%     if str2double(sfile(idx(1)+1 : idx(2)-1)) > 36
%         continue;
%     end
%     fprintf('Process file %d...\n', fnum);
% 
%     %% load pitch file of the clean speech
%     f0S = dlmread(strcat(sFolder, sfile));
%     f0S = f0S(:,1);
%     
%     %% convert Hz to frequency bins
%     idx = f0S~=0;
%     f0S_bin = zeros(size(f0S));
%     f0S_bin(idx) = floor((hz2midi(f0S(idx)) - minF0_midi)/0.5) + 2;     % the real freqs start from 2
%     f0S_bin(~idx) = 1;                                                  % 1 is reserved for no F0
%     for i = 1:length(f0S_bin)-1
%         in = f0S_bin(i);
%         out = f0S_bin(i+1);
%         transCount(in, out) = transCount(in, out) + 1;
%     end
% end
% 
% % prior probability
% initP = sum(transCount, 2);
% initP(initP~=0) = initP(initP~=0)/sum(initP);
% figure; plot(initP); title('Initial state probability');
% 
% % transition matrix
% temp = sum(transCount,2);
% idx = temp~=0;
% transMat(idx,:) = transCount(idx,:)./repmat(temp(idx), 1, numF0);
% transMat(~idx,:) = 1/numF0;
% figure; imagesc(transMat); title('Transition matrix');
% 
% save 'hmmpara.mat' initP transMat;
% 
% 
% 

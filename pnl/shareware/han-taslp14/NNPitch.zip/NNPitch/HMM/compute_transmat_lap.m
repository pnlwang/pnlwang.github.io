function compute_transmat_lap(speakers, lists)

    freqscale = load('~/Kun/pitchtracking/utilities/pitch_candidates_freqz.txt');

    addpath('~/Kun/pitchtracking');
    modeldir = sprintf('~/Kun/pitchtracking/Models'); 

    if nargin > 1
        %% Learn Laplace dist from data
        %Noise and SNR is not important here
        noises = {'NoiseX_babble0to2min'};
        snrdb = -5;
        if length(noises) == 1
                nsname = noises{1};
        elseif length(noises) == 3
                nsname = 'BabFacHfc';
        end
        if isstr(speakers)
                gender = speakers;
                speakers = {gender};
        elseif iscell(speakers) && length(speakers)==2
                gender = 'FemaleMale';
        end

        modelinfo = sprintf('TransMatLp_%s_List%dList%d',gender,lists(1),lists(end));
        ModelFN = sprintf('%s/HMM_%s.mat',modeldir,modelinfo);
        %%

        numF0 = length(freqscale)+1;
        Alltrans = zeros(numF0,numF0);

        AVU = zeros(1, 4); % AVU = [u2v v2u u2u v2v]
        AVV = [];   % AVV = [diff_fr1 diff_fr2 ....]

            for spki = 1:length(speakers)
                gender = speakers{spki};
                for nsi = 1:length(noises)
                    noise = noises{nsi};    
                        for list = lists
                            [noisex clx ranges] = collect_wav_ns(gender, list, noise, snrdb);                    
                            [Pt frranges ptfreq] = comp_gtpitch(clx, ranges);                    
                            [VU VV] = statdiff_tranmat(ptfreq, frranges);
                            AVU = AVU + VU;
                            AVV = [AVV VV];
                        end
                end
            end    

        mu = mean(AVV);
        b = mean(abs(AVV - mu));
        uCount = AVU(1) + AVU(3);
        vCount = AVU(2) + AVU(4);
        prior = [uCount/(uCount+vCount) vCount/(uCount+vCount)];
        AVU = [AVU(1)/(AVU(1)+AVU(3)) AVU(2)/(AVU(2)+AVU(4)) AVU(3)/(AVU(1)+AVU(3))  AVU(4)/(AVU(2)+AVU(4))];

    elseif nargin == 1
        para = speaker;
        mu = para.mu;
        b = para.b;
        para.v2v = 1 - para.v2u;
        para.u2v = 1 - para.u2u;
        AVU = [para.u2v para.v2u para.u2u para.v2v];
    end
        
    for s1 = 1:length(freqscale)
        for s2 = 1:length(freqscale)
            df0 = freqscale(s2) - freqscale(s1);
            Alltrans(s1+1, s2+1) = laplace_pdf(df0, mu, b);
        end
    end
       
    tmptrans = Alltrans(2:end, 2:end);
    Z = repmat(sum(tmptrans, 2), 1, size(tmptrans, 2));
    tmptrans = tmptrans ./ Z * AVU(4);
    
    transCount = zeros(numF0,numF0);
    transCount(1,1) = AVU(3);
    transCount(1,2:end) = repmat(AVU(1)/length(freqscale), 1, length(freqscale));
    transCount(2:end,1) = repmat(AVU(2), length(freqscale), 1);
    transCount(2:end, 2:end) = tmptrans;
    
    % prior probability
    initP(1) = prior(1);
    initP(2:numF0) = prior(2)/(numF0-1);
    figure; plot(initP); title('Initial state probability');

    % transition matrix
    temp = sum(transCount,2);
    idx = temp~=0;
    transMat(idx,:) = transCount(idx,:)./repmat(temp(idx), 1, numF0);
    transMat(~idx,:) = 1/numF0;
    figure; imagesc(transMat); title('Transition matrix');
    priorProb = initP;
    transProb = transMat;

    save(ModelFN, 'priorProb', 'transProb');
end    

function [VU VV] = statdiff_tranmat(Pt, frranges)
    len = length(frranges);
    numStat = size(Pt, 2);
    transCount = zeros(numStat, numStat);
    
    u2v = 0; v2u = 0; u2u = 0; v2v = 0;
    df0 = [];
    
    for i = 1:len
        curfr = frranges{i};
        curpt = Pt(:,curfr);
        
        for fr = 1:length(curfr)-1
            if curpt(fr) == 0 && curpt(fr+1) ~= 0
                u2v = u2v + 1;
            elseif curpt(fr) == 0 && curpt(fr+1) == 0
                u2u = u2u + 1;
            elseif curpt(fr) ~= 0 && curpt(fr+1) == 0
                v2u = v2u + 1;
            else
                tmp = curpt(fr+1) - curpt(fr);
                v2v = v2v + 1;
                df0 = [df0 tmp];
            end            
        end        
    end
    VU = [u2v v2u u2u v2v];
    VV = df0;
end

function f = laplace_pdf(x, mu, b)    
    f = exp(-abs(x - mu)/b)/b*0.5;
end


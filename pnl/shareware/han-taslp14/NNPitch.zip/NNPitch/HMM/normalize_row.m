function mx = normalize_row(mx, alpha)
% Normalize each row s.t. sum(mx, 1) = alpha for each row

    ss = sum(mx,2);
    tmp = repmat(alpha./ss, 1, size(mx,2));
    mx = mx.*tmp;

end
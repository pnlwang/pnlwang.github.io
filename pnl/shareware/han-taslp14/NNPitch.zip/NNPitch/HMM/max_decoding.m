function PP = max_decoding(lklhood, thval)

    % normalize
    numF0 = size(lklhood, 2);
    temp = sum(lklhood, 2);
    idx = temp~=0;
    lklhood(idx,:) = lklhood(idx,:)./repmat(temp(idx), 1, numF0);
    lklhood(~idx,:) = 1/numF0;    
    lklprob = lklhood;
    
    PP = zeros(numF0, size(lklprob,1));
    for i = 1:size(lklprob, 1)
        if lklprob(i,1) > thval
            idx = 1;
        else
            [dummy idx] = max(lklprob(i,2:end));
        end
        PP(idx, i) = 1;
        
    end
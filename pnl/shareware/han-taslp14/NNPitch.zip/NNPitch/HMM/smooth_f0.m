function f0 = smooth_f0(f0)
    buff = []; st = 1; ed = 1;
    for i = 1:length(f0)
        if f0(i) ~= 0
            buff = [buff f0(i)];            
        else
            ed = i;
            if ~isempty(buff)
                f0(st:ed-1) = smooth(buff, 3);
            end
            st = ed+1;
            buff = [];
        end
    end
end

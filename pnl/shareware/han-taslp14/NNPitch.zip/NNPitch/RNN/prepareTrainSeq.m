function [train_seq, target_seq] = prepareTrainSeq(train_cell, target_cell, seq_len)

dim_data = size(train_cell{1}, 2);
dim_target = size(target_cell{1}, 2);

m = 0;
for i = 1:length(train_cell)
     m = m + ceil(size(train_cell{i},1)/seq_len);
end

train_seq = zeros(m, dim_data, seq_len, 'single');
target_seq = zeros(m, dim_target, seq_len, 'single');

s_t = 1;
for i = 1:length(train_cell)
    data = train_cell{i};    
    target = target_cell{i};
    data_sliced = sliceUtterance(data, seq_len);
    target_sliced = sliceUtterance(target, seq_len);
    
    e_t = s_t + size(data_sliced, 1) - 1;
    fill_range = s_t : e_t;
    train_seq(fill_range, :, :) = data_sliced;
    target_seq(fill_range, :, :) = target_sliced;    
    s_t = e_t + 1;
end

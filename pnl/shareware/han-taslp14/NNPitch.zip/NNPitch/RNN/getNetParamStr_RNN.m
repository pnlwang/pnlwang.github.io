function str = getNetParamStr_RNN(opts)

str = '';

for i = 1:length(opts.net_struct)
    str = [str,num2str(opts.net_struct(i)),'.'];
end

for i = 1:length(opts.isRecurrent)
    str = [str,num2str(opts.isRecurrent(i)),''];
end
str = [str, '.'];

str = [str, opts.unit_type_hidden];
str = [str,'.',opts.learner];
if opts.isDropout
    str = [str,'.dropout'];
else
    str = [str,'.no_dropout'];
end
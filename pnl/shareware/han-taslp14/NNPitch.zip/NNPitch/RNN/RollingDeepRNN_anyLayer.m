function net = RollingDeepRNN_anyLayer(theta, opts)

net_struct = opts.net_struct;
num_net_layers = length(net_struct) - 1;
net = repmat(struct, num_net_layers, 1);

pos = 1;
for ll = 1:num_net_layers
    nvis = net_struct(ll);
    nhid = net_struct(ll+1);
    net(ll).W = reshape(theta(pos:pos+nvis*nhid-1), nhid, nvis);
    pos = pos + nvis*nhid;
    net(ll).b = theta(pos:pos+nhid-1);
    pos = pos + nhid;
    
    if opts.isRecurrent(ll+1)
        net(ll).W_recurrent = reshape(theta(pos:pos+nhid*nhid-1), nhid, nhid);
        pos = pos + nhid*nhid;
    end
end

assert(isempty(theta(pos:end)));

function theta = unRollingDeepRNN(net)

% theta = [net.W_hv(:); net.W_hh(:); net.W_oh(:); net.b_h; net.b_o; net.h0];
theta = [];
for ll = 1:length(net)
    theta = [theta; net(ll).W(:); net(ll).b(:)];
%     if ll == 1
    if ~isempty(net(ll).W_recurrent)
        theta = [theta; net(ll).W_recurrent(:)];
    end
end

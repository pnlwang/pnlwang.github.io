function out = predRNN(data,net,nnType)

data = data';
[nIn,~] = size(data); % dxm

raw = reshape(data,1,nIn,[]);
switch nnType
    case 'h2h'
        recons = forwardRNN(raw,net);
    case 'o2h' % h2h+o2h
        recons = forwardRNN_o2h(raw,net);
    case 'o2o' % h2h+o2o
        recons = forwardRNN_o2o(raw,net);
end

out = squeeze(recons)';

function J = makeJacobian(G, W, unit_type, isGPU)

% if units at the same layer interacts, use this function, otherwise just
% do hardmard product

% if nargin < 3; unit_type = 'softmax'; end

unit_type = 'softmax';

num_units = size(W, 2);
num_sample = size(G, 2);

if isGPU
    J = gpuArray.zeros(num_units, num_units, num_sample, 'single');
else
    J = zeros(num_units, num_units, num_sample, 'single');
end

if strcmp(unit_type, 'softmax')    
    for tt = 1 : num_sample
        g = G(:, tt);
%         assert(length(g) == num_units)
        dg = g.*(1-g);
        fill = -g*g';
        if isGPU
            fill(logical(gpuArray.eye(num_units))) = dg;
        else
            fill(logical(eye(num_units))) = dg;
        end
        J(:,:,tt) = fill;
    end
end
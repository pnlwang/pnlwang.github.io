function output = predictPhonePosterior_RNN(net, dev_set, opts)

output = repmat(struct, length(dev_set), 1);
for i = 1:length(dev_set)
    output(i).uid = dev_set(i).uid;
    output(i).posteriors = (predDeepRNN_anyLayer(dev_set(i).data', net, opts))';
    
%     data = dev_set(i).data;
%     cut = size(data, 1);
%     data = [data; data];    
%     output(i).posteriors = (predDeepRNN_anyLayer(data', net, opts))';
%     output(i).posteriors = output(i).posteriors(cut+1:end,:);
end

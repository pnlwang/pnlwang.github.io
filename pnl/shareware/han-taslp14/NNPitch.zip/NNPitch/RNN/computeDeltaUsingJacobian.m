function new_d = computeDeltaUsingJacobian(D_up, G, W, isGPU)

J = makeJacobian(G, W, 'softmax', isGPU);

num_units = size(W, 2);
num_samples = size(J, 3);

if isGPU
    new_d = gpuArray.zeros(num_samples, num_units, 'single');
else
    new_d = zeros(num_samples, num_units, 'single');
end

tmp = (D_up * W)';
for m = 1: num_samples
    new_d(m,:) = J(:,:,m) * tmp(:,m);
end

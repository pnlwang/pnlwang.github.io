function model = RNN_train(train_cell, target_cell, devdata_cell, devlabel_cell, para)

%clear all;
% try
%     gpuDevice(1)    
% catch
%     disp('GPU 1 fail, Requesting GPU2, ...')
%     gpuDevice(2)
% end
addpath(genpath('./RNN/'));
%%
disp('...Loading data...')
%%
disp('...Slicing data into sequences...')
T = para.T; % fixed BPTT length
% you need to supply your train_cell and target cell, each cell entry is a sequence
[train_seq, target_seq] = prepareTrainSeq(train_cell, target_cell, T);
%target_seq = target_seq + 1;
clear train_cell target_cell

%%
max_id = para.outdim; % if do classification, this is the number of classes
dim_input = size(train_seq, 2);

%opts.net_struct = [dim_input, 256 , max_id];
opts.net_struct = [dim_input, para.hidstruct , max_id];
%opts.isRecurrent = [0, 1, 0]; % 1 means the layer is recurrent. No recurrence on input
opts.isRecurrent = [0, para.hidrecurr, 0];

opts.isGradClip = 1;
opts.spectral_rad = 1.1;
opts.isSpecNorm = 0;
opts.grad_clip_thr = 30;

opts.learner = 'ada_sgd'; % 'ada_sgd' or 'sgd'
%opts.learner = 'sgd';
if ~isfield(para,'sgd_max_epoch')
    opts.sgd_max_epoch = 40;
else
    opts.sgd_max_epoch = para.sgd_max_epoch;
end
%opts.sgd_max_epoch = 30;
opts.sgd_batch_size = 256; % batch size for SGD
if ~isfield(para,'ada_sgd_scale')
    opts.ada_sgd_scale = 0.008; % scaling factor for ada_grad
else
    opts.ada_sgd_scale = para.ada_sgd_scale;
end
%opts.ada_sgd_scale = 0.005; % scaling factor for ada_grad
% opts.ada_sgd_scale = 0.0015; % scaling factor for ada_grad
%opts.ada_sgd_scale = 0.00015;
opts.sgd_learn_rate = linspace(0.01, 0.001, opts.sgd_max_epoch); % linearly decreasing lrate for plain sgd

opts.initial_momentum = 0.5;
opts.final_momentum = 0.9;
opts.change_momentum_point = 5;

if ~isfield(para,'cost_function')
    opts.cost_function = 'softmax_xentropy'; % if want to do classification
else
    opts.cost_function = para.cost_function;
end
if ~isfield(para,'unit_type_output')
    opts.unit_type_output = 'softmax';
else
    opts.unit_type_output = para.unit_type_output;
end
if ~isfield(para,'unit_type_hidden')
    opts.unit_type_hidden = 'sigm';
else
    opts.unit_type_hidden = para.unit_type_output;
end

if ~isfield(para,'isDropout')
    opts.isDropout = 0; %
else
    opts.isDropout = para.isDropout; %
end

if ~isfield(para,'task')
    opts.task = 'classification'; %
else
    opts.task = para.task; %
end

opts.drop_ratio = 0.2;

opts.isGPU = 1;

%% //////////////////
opts %#ok<NOPTS>
opts.cv_interval = 1;
tic
model = trainDeepRNN(train_seq, target_seq, devdata_cell, devlabel_cell, opts);
toc

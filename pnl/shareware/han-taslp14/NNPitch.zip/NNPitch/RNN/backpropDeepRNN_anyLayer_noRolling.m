function [cost, net_gradients] = backpropDeepRNN_anyLayer_noRolling(net, input_seq, label_seq, opts)
net_struct = opts.net_struct;
unit_type_output = opts.unit_type_output;
unit_type_hidden = opts.unit_type_hidden;

num_net_layers = length(net_struct) - 1;
num_data_layers = num_net_layers + 1;

fprop_all = forwardDeepRNN_anyLayer(input_seq, net, opts);

[~, ~, T] = size(input_seq);
isRecurrent = opts.isRecurrent;
assert(length(isRecurrent) == num_data_layers);
assert(isRecurrent(1) == 0, 'Input layer must be non-recurrent!'); % input layer always non-recurrent
%% BPTT
net_gradients = zeroInitDeepRNN_anyLayer(opts, 0);

D_all = cell(T, num_data_layers); % D_all{:,1} is always empty
D_all(:) = {0}; % fast way to initialize a cell matrix

cost = 0;
for t = T: -1 :1
    out_t = fprop_all{t}{num_data_layers}';
    switch opts.cost_function
        case 'mse'
            e_t = out_t - label_seq(:,:,t);
            cost = cost + 0.5*sum(sum(e_t.^2));
            D_all{t,end} = D_all{t,end} + e_t .* compute_unit_gradient(out_t, unit_type_output);            
        case 'softmax_xentropy'            
            assert(strcmp(unit_type_output, 'softmax'));
            cost = cost - sum(sum(label_seq(:,:,t) .* log(out_t)));
            D_all{t,end} = D_all{t,end} - (label_seq(:,:,t) - out_t);
    end        
    
    D_o_t = D_all{t,end};
    if isRecurrent(end)
        if t >= 2
            net_gradients(end).W_recurrent = net_gradients(end).W_recurrent + D_all{t,end}'* fprop_all{t-1}{num_data_layers}';         
            
            if strcmp(opts.unit_type_output, 'softmax')
                D_all{t-1,end} = computeDeltaUsingJacobian(D_o_t, fprop_all{t-1}{num_data_layers}, net(end).W_recurrent, opts.isGPU);
            else
                D_all{t-1,end} = D_o_t * net(end).W_recurrent .* compute_unit_gradient(fprop_all{t-1}{num_data_layers}, unit_type_output)';         
            end
        end
    end
        
    % remember, recurrent layer has two incoming deltas, 
    % one from above and one from t+1, except when t=1 or t=end    
    for ll = num_net_layers: -1: 1
        net_gradients(ll).W = net_gradients(ll).W + (fprop_all{t}{ll}*D_all{t,ll+1})';
        net_gradients(ll).b = net_gradients(ll).b + sum(D_all{t,ll+1})';

        D_k = ((D_all{t,ll+1}*net(ll).W)'.*compute_unit_gradient(fprop_all{t}{ll},unit_type_hidden))';
        D_all{t,ll} = D_all{t,ll} + D_k;
        
        % ll=1 is safe, as isRecurrent(1) is alwayes False
        if isRecurrent(ll)
            if t >= 2
                net_gradients(ll-1).W_recurrent = net_gradients(ll-1).W_recurrent + D_all{t,ll}'* fprop_all{t-1}{ll}';
                D_all{t-1,ll} = D_all{t,ll} * net(ll-1).W_recurrent .* compute_unit_gradient(fprop_all{t-1}{ll}, unit_type_hidden)';            
            end
        end
    end
    
end

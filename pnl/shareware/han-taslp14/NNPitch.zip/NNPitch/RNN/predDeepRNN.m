function out = predDeepRNN(data, net, opts, nnType)

if length(size(data)) == 2
    data = reshape(data,1,size(data,1),size(data,2));
end
assert(length(size(data)) == 3) % nbatch x dim x T

switch nnType
    case 'h2h'
        fprop_all = forwardDeepRNN(data, net, opts);
    case 'o2o' % h2h+o2o
end

out = getOutput(fprop_all);

end

function out = getOutput(stack)
    T = numel(stack);
    for t = 1:T
        out(:,t) = stack{t}{end};
    end
end
function out = sliceUtterance(seq, T)

% seq: mxd
[m, d] = size(seq);
batch = genBatchID(m, T);

num_batch = size(batch,2);
out = zeros(num_batch, d, T, 'single');

for i = 1:num_batch
    range = batch(1,i) : batch(2,i);
    if length(range) == T
        out(i,:,:) = seq(range,:)';
    else
%         % automatic zero padding
%         out(i,:,1:length(range)) = seq(range,:)';

        fill = seq(range,:);
        fill = repmat(fill,ceil(T/length(range)),1);
        fill = fill(1:T,:);
        out(i,:,:) = fill';
    end
end

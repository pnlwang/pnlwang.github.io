function net = zeroInitDeepRNN_anyLayer(opts, epsilon)

if nargin < 2; epsilon = 0; end;

net_struct = opts.net_struct;
num_net_layer = length(net_struct) - 1;
isGPU = opts.isGPU;
net = repmat(struct,num_net_layer,1);

for i = 1:num_net_layer
    if isGPU
        net(i).W = gpuArray.zeros(net_struct(i+1),net_struct(i),'single');
        net(i).b = gpuArray.zeros(net_struct(i+1),1,'single');        
    else
        net(i).W = zeros(net_struct(i+1),net_struct(i),'single');
        net(i).b = zeros(net_struct(i+1),1,'single');
    end
    
    if opts.isRecurrent(i+1)
        net(i).W_recurrent = zeros(net_struct(i+1),net_struct(i+1),'single');
        if isGPU
            net(i).W_recurrent = gpuArray(net(i).W_recurrent);
        end
    end
    
    % this is for initializing net_grad_ssqr in ada_sgd
    if epsilon ~=0
        net(i).W = net(i).W + epsilon;
        net(i).b = net(i).b + epsilon;
    end
end

function net_grad = clipGradient_fullvec(net_grad, opts)

threshold = opts.grad_clip_thr;
grad_vec = unRollingDeepRNN(net_grad);
norm_g = norm(grad_vec, 'fro');
if norm_g > threshold
    grad_vec = threshold * grad_vec / norm_g;
%     net_grad = RollingDeepRNN(grad_vec, opts);
    net_grad = RollingDeepRNN_anyLayer(grad_vec, opts);
end

% for ll = 1:length(net_grad)
%     norm_w = norm(net_grad(ll).W,'fro');
%     if norm_w > threshold
%         net_grad(ll).W = threshold * net_grad(ll).W / norm_w;
%     end
%     
%     norm_b = norm(net_grad(ll).b,'fro');
%     if norm_b > threshold
%         net_grad(ll).b = threshold * net_grad(ll).b / norm_b;
%     end
%     
%     if ~isempty(net_grad(ll).W_recurrent)
%        norm_wrec = norm(net_grad(ll).W_recurrent,'fro');
%         if norm_wrec > threshold
%             net_grad(ll).W_recurrent = threshold * net_grad(ll).W_recurrent / norm_wrec;
%         end 
%     end
%     
% end
function model = trainDeepRNN(train_seq, label_seq, devfea_seq, devlabel_seq, opts)
isGPU = opts.isGPU;

net_iterative = initializeDeepRNN_anyLayer(opts);
num_net_layer = length(net_iterative);
%% stochastic gradient descent
[num_seqs, ~, seq_len] = size(train_seq);
batch_id = genBatchID(num_seqs, opts.sgd_batch_size);
num_batch = size(batch_id, 2);

fprintf('\nNum of Training Sequences:%d; Sequence Length:%d\n',num_seqs, seq_len);

net_weights_inc = zeroInitDeepRNN_anyLayer(opts, 0);
%net_grad_ssqr = zeroInitDeepRNN_anyLayer(opts, eps);
net_grad_ssqr = zeroInitDeepRNN_anyLayer(opts, 0);
net_ada_eta = zeroInitDeepRNN_anyLayer(opts, 1e-6);

max_id = opts.net_struct(end);
best_perf = 0;
cv_rec = repmat(struct,opts.sgd_max_epoch,1);
for epoch = 1:opts.sgd_max_epoch
    seq = randperm(num_seqs); % randomize access if data in mem
    cost_sum = 0;
    for bid = 1:num_batch-1
        perm_idx = seq(batch_id(1,bid):batch_id(2,bid));
        
        if isGPU
            batch_data = gpuArray(train_seq(perm_idx,:,:));            
            %///// for softmax classification
            if strcmp(opts.task, 'classification')
                filled_labels = make_labels_seq(label_seq(perm_idx,:,:), max_id);
                batch_label = gpuArray(filled_labels);
            else
                batch_label = gpuArray(label_seq(perm_idx,:,:));
            end
            
            %///// for regression, or MSE loss
            %             batch_labels = gpuArray(label_seq(perm_idx,:,:));
        else
            batch_data = train_seq(perm_idx, :, :);
            %///// for softmax classification
            if strcmp(opts.task, 'classification')        
                batch_label = make_labels_seq(label_seq(perm_idx,:,:), max_id);
            else
                batch_label = (label_seq(perm_idx,:,:));
            end
            
            %///// for regression, or MSE loss
            %             batch_label = (label_seq(perm_idx,:,:));
        end
        
        if epoch>opts.change_momentum_point;
            momentum=opts.final_momentum;
        else
            momentum=opts.initial_momentum;
        end
        
        %backprop: core code
        [cost, net_grad] = backpropDeepRNN_anyLayer_noRolling(net_iterative, batch_data, batch_label, opts);
        
        % try both, they are different
        if opts.isGradClip
             net_grad = clipGradient_fullvec(net_grad, opts);
%             net_grad = clipGradient(net_grad, opts);
        end
        
        for ll = 1 : num_net_layer
            switch opts.learner
                case 'sgd'
                    net_weights_inc(ll).W = momentum*net_weights_inc(ll).W + opts.sgd_learn_rate(epoch)*net_grad(ll).W;
                    net_weights_inc(ll).b = momentum*net_weights_inc(ll).b + opts.sgd_learn_rate(epoch)*net_grad(ll).b;
                    if ~isempty(net_iterative(ll).W_recurrent)
                        net_weights_inc(ll).W_recurrent = momentum*net_weights_inc(ll).W_recurrent ...,
                            + opts.sgd_learn_rate(epoch)*net_grad(ll).W_recurrent;
                    end
                case 'ada_sgd'
                    net_grad_ssqr(ll).W = net_grad_ssqr(ll).W + (net_grad(ll).W).^2;
                    net_grad_ssqr(ll).b = net_grad_ssqr(ll).b + (net_grad(ll).b).^2;
                    
                    net_ada_eta(ll).W = opts.ada_sgd_scale./sqrt(net_grad_ssqr(ll).W);
                    net_ada_eta(ll).b = opts.ada_sgd_scale./sqrt(net_grad_ssqr(ll).b);
                    
                    net_weights_inc(ll).W = momentum*net_weights_inc(ll).W + net_ada_eta(ll).W.*net_grad(ll).W;
                    net_weights_inc(ll).b = momentum*net_weights_inc(ll).b + net_ada_eta(ll).b.*net_grad(ll).b;
                    
                    if ~isempty(net_iterative(ll).W_recurrent)
                        net_grad_ssqr(ll).W_recurrent = net_grad_ssqr(ll).W_recurrent + (net_grad(ll).W_recurrent).^2;
                        net_ada_eta(ll).W_recurrent = opts.ada_sgd_scale./sqrt(net_grad_ssqr(ll).W_recurrent);
                        net_weights_inc(ll).W_recurrent = momentum*net_weights_inc(ll).W_recurrent +...,
                            net_ada_eta(ll).W_recurrent.*net_grad(ll).W_recurrent;
                    end
            end
            
            net_iterative(ll).W = net_iterative(ll).W - net_weights_inc(ll).W;
            net_iterative(ll).b = net_iterative(ll).b - net_weights_inc(ll).b;
            if ~isempty(net_iterative(ll).W_recurrent)
                net_iterative(ll).W_recurrent = net_iterative(ll).W_recurrent - net_weights_inc(ll).W_recurrent;
            end
        end
        
        cost_sum = cost_sum + cost;
    end
    
    fprintf('Objective cost at epoch %d: %g ', epoch, cost_sum);
    
    %disp('cross validation...')
    %[perf, perf_str] = YOUR_CV_FUNCTION(net_iterative, dev_set, opts);
    % To get prediction for a test sequence, do the following 
    % prediction = gather((predDeepRNN_anyLayer(test_data, net, opts)));
    [mse(epoch) xentropy(epoch) msept(epoch) xentropypt(epoch)] = batchPredDeepRNN(devfea_seq, devlabel_seq, net_iterative, opts);
    perf_str = 'MSE';
    net{epoch} = net_iterative;
    fprintf(' / CV Metric %s on dev_set at epoch %d: %g \n', perf_str, epoch, mse(epoch));    
    
end

perf = mse;
model.net = net;
model.perf = perf;
model.perf_str = 'MSE';
model.opt = opts;
model.mse = mse;
model.xentropy = xentropy;
model.msept = msept;
model.xentropypt = xentropypt;


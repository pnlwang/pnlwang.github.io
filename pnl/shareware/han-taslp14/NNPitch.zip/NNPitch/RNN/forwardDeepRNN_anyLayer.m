function fprop_all = forwardDeepRNN_anyLayer(seq, net, opts)
[m, ~, T] = size(seq);
num_data_layers = length(opts.isRecurrent);

fprop_all = cell(T, 1);
% assuming we start with all zero hidden state !! fix this
states_t0 = cell(num_data_layers,1);
for i = 2 : num_data_layers
    states_t0{i} = zeros(opts.net_struct(i), m, 'single');    
end

fprop_all{1} = fprop_t(seq(:,:,1)', states_t0, net, opts);
for t = 2 : T
    input = squeeze(seq(:,:,t))';
    fprop_all{t} = fprop_t(input, fprop_all{t-1}, net, opts);
end

end

%fprop at the current time step
function fprop = fprop_t(input, prev_fprop, net, opts)

if opts.isDropout
    drop_ratio = opts.drop_ratio;
    drop_scale = 1/(1-drop_ratio);
else
    drop_scale = 1;
end

net_struct = opts.net_struct;
num_net_layers = length(net_struct) - 1;
num_data_layers = num_net_layers + 1;
isRecurrent = opts.isRecurrent;

fprop = cell(num_data_layers,1);
fprop{1} = input;
for k = 2 : num_data_layers
%     ll = k-1;
    if isRecurrent(k)
%         t_z = bsxfun(@plus, net(k-1).W*fprop{k-1} + net(k-1).W_recurrent*prev_fprop{k}, net(k-1).b);
        t_z = bsxfun(@plus, drop_scale*net(k-1).W*fprop{k-1} + drop_scale*net(k-1).W_recurrent*prev_fprop{k}, net(k-1).b);
    else
%         t_z = bsxfun(@plus, net(k-1).W*fprop{k-1}, net(k-1).b);
        t_z = bsxfun(@plus, drop_scale*net(k-1).W*fprop{k-1}, net(k-1).b);
    end

    if k < num_data_layers
        fprop{k} = compute_unit_activation(t_z, opts.unit_type_hidden);
    else
        fprop{k} = compute_unit_activation(t_z, opts.unit_type_output);
    end
        
    % dropout
    if opts.isDropout && (k < num_data_layers); % never dropout outputs    
%     if 0
        if opts.isGPU
            drop_mask = gpuArray.rand(size(fprop{k}),'single') < (1-drop_ratio); %faster than rand on CPU
        else
            drop_mask = rand(size(fprop{k}),'single') < (1-drop_ratio);
        end
        fprop{k} = fprop{k}.*drop_mask; 
    end
    
    
end
end

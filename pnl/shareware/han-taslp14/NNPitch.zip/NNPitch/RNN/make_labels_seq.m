function filled = make_labels_seq(idx_seq, max_val)

[m, ~, T] = size(idx_seq);
filled = zeros(m, max_val, T, 'single');
for t = 1:T
    try
    filled(:,:,t) = make_labels(idx_seq(:,:,t), max_val);
    catch
        ttt=0;
    end
end

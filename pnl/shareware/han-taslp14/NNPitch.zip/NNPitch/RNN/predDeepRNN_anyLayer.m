function out = predDeepRNN_anyLayer(data, net, opts)

if length(size(data)) == 2
    data = reshape(data,1,size(data,1),size(data,2));
end
assert(length(size(data)) == 3) % nbatch x dim x length

% fprop_all = forwardDeepRNN_anyLayer(data, net, opts);
fprop_all = forwardDeepRNN_dropscale(data, net, opts);
out = getOutput(fprop_all);

end

function out = getOutput(stack)
    T = numel(stack);
    for t = 1:T
        out(:,t) = stack{t}{end};
    end
end
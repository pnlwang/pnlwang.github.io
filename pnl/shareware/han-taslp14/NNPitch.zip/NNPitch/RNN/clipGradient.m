function net_grad = clipGradient(net_grad, opts)

threshold = opts.grad_clip_thr;
for ll = 1:length(net_grad)
    norm_w = norm(net_grad(ll).W,'fro');
    if norm_w > threshold
        net_grad(ll).W = threshold * net_grad(ll).W / norm_w;
    end
    
    norm_b = norm(net_grad(ll).b,'fro');
    if norm_b > threshold
        net_grad(ll).b = threshold * net_grad(ll).b / norm_b;
    end
    
    if ~isempty(net_grad(ll).W_recurrent)
       norm_wrec = norm(net_grad(ll).W_recurrent,'fro');
        if norm_wrec > threshold
            net_grad(ll).W_recurrent = threshold * net_grad(ll).W_recurrent / norm_wrec;
        end 
    end
    
end

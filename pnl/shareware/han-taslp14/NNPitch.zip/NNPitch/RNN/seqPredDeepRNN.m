function [Allpred] = seqPredDeepRNN(data_seq, net, opts)

    Allpred = [];
    for i = 1:length(data_seq)
        pred = gather(predDeepRNN_anyLayer((data_seq{i}'), net, opts));
        Allpred = [Allpred; pred'];
    end

end
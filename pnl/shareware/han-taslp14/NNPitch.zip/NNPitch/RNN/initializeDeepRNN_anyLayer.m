function net = initializeDeepRNN_anyLayer(opts)

net_struct = opts.net_struct;
num_net_layers = numel(net_struct)-1;
net = repmat(struct, num_net_layers, 1);

for ll = 1:num_net_layers
    % or simply use 0.001*N(0,1) ?
%     net(ll).W = initRandW(net_struct(ll+1), net_struct(ll));       
    net(ll).W = 0.001*randn(net_struct(ll+1), net_struct(ll));
    net(ll).W = single(net(ll).W);
    nhid = net_struct(ll+1);
        
    if opts.isRecurrent(ll+1) 
%        net(ll).W_recurrent = initializeRandWSparse(nhid,nhid, opts.isSpecNorm, opts.spectral_rad);
         net(ll).W_recurrent = 0.001*randn(nhid,nhid,'single');
    end
    
    net(ll).b = zeros(net_struct(ll+1), 1, 'single');
end
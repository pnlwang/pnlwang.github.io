function [perf perf2 perf3 perf4] = batchPredDeepRNN(data_seq, label_seq, net, opts)

    for i = 1:length(data_seq)
        pred = gather(predDeepRNN_anyLayer((data_seq{i}'), net, opts));
        if strcmp(opts.task, 'classification')
            desired = (make_labels(label_seq{i}, size(pred,1)))';
        else
            desired = (label_seq{i})';
        end
        mse(i) = mean(mean((pred-desired).^2));
        xentropy(i) = -mean((mean(desired.*log(pred)+(1-desired).*log(1-pred))));
        
        fr = find(desired(1,:)==0);
        msept(i) = mean(mean((pred(:,fr)-desired(:,fr)).^2));
        xentropypt(i) = -mean((mean(desired(:,fr).*log(pred(:,fr))+(1-desired(:,fr)).*log(1-pred(:,fr)))));
                
    end

    perf = [mean(mse)];
    perf2 = [mean(xentropy)];
    perf3 = [mean(msept)];
    perf4 = [mean(xentropypt)];
    %subplot(2,1,1);imagesc(desired);subplot(2,1,2);imagesc(pred);
end
function [F0 gt_lag] = comp_pt_praat(x, fs, pda)

    addpath('~/Kun/tools/voicebox_icl/');
    addpath('~/Kun/tools/cochleagram_toolbox/');
    
    if ~exist('fs')
        fs = 16000;
    end
    
    shift = 0.01 * fs;
    nFrame = fix((length(x)-shift)/(shift));

    if ~exist('pda') | pda == 1
        [f0,junk,times] = praat_pd(x, fs, 0, 0.01, 80, 500);                           
    elseif pda == 2
        [fx, tx, pv, fv] = fxpefac(x, fs, 0.01);
        unvoiced = pv<0.5;
        f0e = fx;
        f0e(unvoiced) = 0;
        f0 = f0e;
        times = tx;
    end
    
    
    T = nFrame;    
    times_coch = [.5,1:T-1]*.01;
    
    gt_lag = zeros(1,T);    
    F0 = zeros(1,T);
    for t = 1:T    
        [val,index] = min(abs(times_coch(t)-times));        
        if f0(index)>0        
            gt_lag(t) = fs/f0(index);
            F0(t) = f0(index);
        end        
    end
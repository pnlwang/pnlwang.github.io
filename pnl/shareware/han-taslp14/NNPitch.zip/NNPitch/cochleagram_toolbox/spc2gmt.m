function [conv_mat] = spc2gmt(options)

%Parameters

if ~isfield(options,'fs')
    options.fs = 16000;
end
fs = options.fs; %Sampling rate

if ~isfield(options,'numChan')
    options.numChan = 64; %Number of channels
end
numChan = options.numChan;

fRange = [50 fs/2]; %The frequency range
winLength = 20*fs/1000; %20 msec window
options.fr_size = winLength;
options.D = options.fr_size/2; %Overlap

if ~isfield(options,'NFFT')
    options.NFFT = winLength; %FFT size
end
options.nfft = options.NFFT;


    % Normalized Gammatone filter mapping for snr estimation
    filterOrder = 4;    % filter order
    gL = options.nfft;           % To match Hendrix PSD estimator
    
    phase(1:numChan) = zeros(numChan,1);        % initial phases
    erb_b = hz2erb(fRange);       % upper and lower bound of ERB
    erb = [erb_b(1):diff(erb_b)/(numChan-1):erb_b(2)];     % ERB segment
    cf = erb2hz(erb);       % center frequency array indexed by channel
    b = 1.019*24.7*(4.37*cf/1000+1);       % rate of decay or bandwidth
         
    % Generating gammatone impulse responses with middle-ear gain normalization
    gt = zeros(numChan,gL);  % Initialization
    tmp_t = [1:gL]/fs;
    for i = 1:numChan
        gain = 10^((loudness(cf(i))-60)/20)/3*(2*pi*b(i)/fs).^4;    % loudness-based gain adjustments
        gt(i,:) = gain*fs^3*tmp_t.^(filterOrder-1).*exp(-2*pi*b(i)*tmp_t).*cos(2*pi*cf(i)*tmp_t+phase(i));
    end
    
%     % Gammatone response normalization
%     f=cf(3):cf(end-3); % the approximate plateu region
%     gtf = zeros(numChan,length(f));
%     for c=1:numChan
%         gtf(c,:) = (1/3*(2*pi)^4)*factorial(filterOrder-1)*1/2*(b(c)./sqrt((2*pi*(f-cf(c))).^2+(2*pi*b(c))^2)).^filterOrder;
%         gtf(c,:) = gtf(c,:).^2;
%     end
%     factor = sqrt(max(sum(gtf)));
%     gt = gt/factor;
    
    pow_gt = abs((fft(gt'))').^2; %Gammatone response power in each bin.
    clear filterOrder gL phase erb erb_b cf f b tmp_t i gain gt gtf c factor
 
    %gmt = pow_gt*psd;
    conv_mat = pow_gt(:,:);
    
end

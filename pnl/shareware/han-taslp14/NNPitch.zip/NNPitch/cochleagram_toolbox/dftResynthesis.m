function enSig = dftResynthesis(sig,ibm,fs,winlen,hop,win)
% IBM corresponds to energy, not amplitude

nfreqs = size(ibm,1);

if ~exist('fs','var')
    fs = 16000;
end
if ~exist('winlen','var')
    winlen = fs*20/1000;
%     winlen = fs*25/1000;
end
if ~exist('hop','var')
    hop = fs*10/1000;
end
if ~exist('win','var')
    win=ones(winlen,1);
end

[awin,swin] = normalize_analysissynthesis_windows(hop,win);
% awin = ones(winlen,1);
% swin = awin;

sigFFT = analysis_fb(sig,nfreqs,awin,hop,fs);
enFFT = sigFFT .* sqrt(ibm);
enSig = synthesis_fb(enFFT,swin,hop);
end

function [S, F, T] = analysis_fb(x, M, win, D, fs)
% [S, F, T] = analysis_fb(x, M, win, D, fs)
% Compute analysis filterbank using FFT
% Inputs
%   x                  Input signal
%   M                  FFT size gives number of bands = M/2+1
%   D                  Decimation
%   win                Window
%   fs                 Sample rate
%
% Outputs
%   S                  Spectrogram (filterbank bands in rows)
%   F                  Center frequencies
%   T                  Time points
%
if nargin < 5, fs = 2; end
noverlap = length(win) - D;
nfft = (M-1)*2 ;
[S, F, T] = spectrogram(x, win, noverlap, nfft, fs);
% S(2:2:end,:) = -S(2:2:end,:); % Sign reversal used for aligning phase in channels
end

function xsyn = synthesis_fb(S, synwin, D) 
% xsyn = synthesis_fb(S, synwin, D) 
% Synthesis by overlap-add
% Inputs
%   S        Filterbank bands, in each row
%   synwin   Synthesis window
%   D        Decimation factor
N = length(synwin);
synwin = synwin(:); % Compensate for 1/N in IFFT
% Perform synthesis
% S(2:2:end,:) = -S(2:2:end,:); % Sign reversal used for aligning phase in channels
S=[S ; conj(flipud(S(2:end-1,:)))];
SfTmp = real(ifft(S));
iS=SfTmp(1:length(synwin),:).*repmat(synwin, 1, size(S,2));clear SfTmp;
xsyn = zeros(D*(size(S,2)-1)+N,1);
for i=1:size(S,2)
    ii = (i-1)*D+1+(0:N-1);
    xsyn(ii) = iS(:,i)+xsyn(ii);
end
end

function [awin, swin] = normalize_analysissynthesis_windows(D, awin, swin)
% [awin, swin] = normalize_analysissynthesis_windows(D, awin, swin)
% Normalize (scale) windows for FFT filterbank so that
% 1) Analysis windows have max gain of 0dB
% 2) Synthesis window compensates for decimation factor D, and resulting
% filterbank gain is approximately 0dB 
% Inputs:
%   D     Filterbank decimation factor
%   awin  Analysis window (vector) 
%   swin  Synthesis window (vector). If no swin is provided, awin is used.
% Outputs:
%   awin, swin   Normalized windows.
%

if nargin < 3
    swin = awin;
end

awin=awin/sum(awin);
swin=swin/sum(swin);
w=awin.*swin; sw=zeros(1, D-1);
for i=1:D-1,sw(i)=sum(w(i:D:end));end
swin = swin/mean(sw); % Normalize gain
end

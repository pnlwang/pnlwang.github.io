 function [gfcc gf_sub fs_gf] = get_gfccfeature(subband_sig,dim, nchan,srate)


if nargin < 3
    srate = 16000;
    nchan = 64;
end

if srate == 12000
    nFrame = floor(length(subband_sig)/192)-1; % hopsize = 16ms
elseif srate == 16000
    nFrame = floor(length(subband_sig)/160)-1; % hopsize = 16ms
end

%gf_sub = gammatone(subband_sig,nchan,[50 8000],srate); %hopsize = 10ms
para.nc = 64; para.fs = 16000; para.fRange = [50 8000];
gf_sub = gammatone(subband_sig, para);
gff = gf_sub';       

if srate == 12000
    fs_gf=(abs(resample(abs(gff(1:length(subband_sig),:)),62,srate)')).^(1/3); %12k/192
elseif srate == 16000
    fs_gf=(abs(resample(abs(gff(1:length(subband_sig),:)),100,srate)')).^(1/3); %16k/160
    %fs_gf=resample(abs(gff(1:length(subband_sig),:)),100,srate)'; %16k/160
    %disp('gm on env...');
end



% dd_fs_gf = fs_gf(:,1:nFrame)';
gfcc= gtf2gtfcc(fs_gf, 1, dim)';
gfcc = gfcc(1:nFrame, :);
fs_gf = fs_gf(:,1:nFrame);
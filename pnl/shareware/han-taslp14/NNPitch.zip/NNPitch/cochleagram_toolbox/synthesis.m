function [r,r_all1] = synthesis(input, mask, parameters) 

% [r,r_all1] = synthesis(input, mask, parameters)
%
% Mask and resynthesize signal using gammatone filterbank
%
% Inputs:
%   input               input signal
%   mask                T-F mask to be applied: chan x frame
%   parameters          struct of optional parameters
%       .fs             sample rate (default = 16 kHz)
%       .winL           window length (default = 0.02 s)
%       .fRange         lower and upper center frequencies (default = [80 7000] Hz)
%       .delayComp      (0/1) determine if channels should compensate for frequency-dependent delay (default = 0, no compensation)
%       .synthBank      (0/1) determine if synthesis filterbank is included (default = ~delayComp, i.e. if delay compensation is applied, assumes no synthesis bank; if delay compensation is not applied, includes synthesis bank)
%       .normalize      (0/1) determine if filterbank pass-band should be scaled to unity gain. note that scaling doesn't make sense of equal loudness is applied (default = 1, normalization applied)
%
% Outputs:
%   r                   synthesized signal
%   r_all1              signal without gains applied
%
% Written by John Woodruff in June 2012 (adapted from code by ZZ Jin and DL Wang)

if nargin < 3
    parameters = struct;
end

if ~isfield(parameters,'fs')
    parameters.fs = 16000;
end
if ~isfield(parameters,'winL')
    parameters.winL = .02; % 20 ms
end
if ~isfield(parameters,'fRange')
    parameters.fRange = [50 8000];
end
if ~isfield(parameters,'delayComp')
    parameters.delayComp = 0;
end
if ~isfield(parameters,'synthBank')
    parameters.synthBank = ~parameters.delayComp;
end
if ~isfield(parameters,'normalize')
    parameters.normalize = 1;
end

filterOrder = 4;
winLength = 2*round(parameters.winL*parameters.fs/2);
winShift = winLength/2;     % frame shift rate (default is 1/2 frame length)
increment = winLength/winShift;     % special treatment for beginning frames
sigLength = length(input);
[numChan,numFrame] = size(mask);     % number of channels and time frames
input = reshape(input,sigLength,1);      % convert input to column vector

% get gammatone filterbank
parameters.nc = numChan;
parameters.el = 1;
parameters.complex = 0;
normalize = parameters.normalize;
parameters.normalize = 0;  % normalize here based on synthesis process
%[junk,gt,cf,b] = gammatone(zeros(10,1), parameters);
%clear junk;
[gt,cf,b] = gammatone(zeros(10,1), parameters);

% normalize for unity gain if desired (with awareness of synthesis process)
parameters.normalize = normalize;
if parameters.normalize
    gt = normalize_gtbank(gt,cf,parameters.fs,~parameters.synthBank);
end

% if synthesis bank is included, adjust filters
gt = gt.';
if parameters.synthBank
    L = size(gt,1);
    gt = fftfilt(gt,flipud([zeros(L-1,parameters.nc);conj(gt)]));
end
L = size(gt,1);

% pad input to account for circular convolution by fftfilt
input = [input;zeros(L-1,1)];

% filter signal
temp1 = fftfilt(gt,input).';

% select the appropriate samples so that output is time-aligned to input
% (note that this process is non-causal)
if parameters.synthBank
    start = (L+1)/2;
    range = start:(start+sigLength-1);
else
    start = ceil(parameters.fs*(filterOrder-1)/(2*pi*b(1)));
    range = start:(start+sigLength-1);
end
temp1 = temp1(:,range);

% time window
coswin = (1 + cos(2*pi*(0:winLength-1)/winLength - pi))/2;
coswin = repmat(coswin,[numChan 1]);

% compute sample-level weights based on mask
weight = zeros(size(temp1));
for m = 1:numFrame-increment/2+1
    startpoint = (m-1)*winShift;
    if m <= increment/2
        weight(:,1:startpoint+winLength/2) = weight(:,1:startpoint+winLength/2) + repmat(mask(:,m),[1 startpoint+winLength/2]).*coswin(:,winLength/2-startpoint+1:end);
    else
        weight(:,startpoint-winLength/2+1:startpoint+winLength/2) = weight(:,startpoint-winLength/2+1:startpoint+winLength/2) + repmat(mask(:,m),[1 winLength]).*coswin;
    end
end

r = sum(temp1.*weight);
r_all1 = sum(temp1);
clear temp1 weight gt GT;
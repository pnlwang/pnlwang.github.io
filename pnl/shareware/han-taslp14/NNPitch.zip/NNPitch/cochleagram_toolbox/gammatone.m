function [r,fb,parameters] = gammatone(signal, parameters)

% [r,fb,parameters] = gammatone(signal, parameters)
%
% Produce an array of filtered responses from a Gammatone filterbank.
%
% Inputs:
%   signal              input signal
%   parameters          struct of optional parameters
%       .fs             sample rate (default = 16 kHz)
%       .nc             number of frequency channels (default = 64)
%       .fRange         lower and upper center frequencies (default = [50 8000] Hz)
%       .complex        (0/1) determine if output is real or complex valued (default = 0, real output)
%       .el             (0/1) determine if equal loudness contours are used to adjust output gains (default = 0, no equal loudness)
%       .delayComp      (0/1) determine if channels should compensate for frequency-dependent delay (default = 0, no compensation)
%       .normalize      (0/1) determine if filterbank pass-band should be scaled to unity gain. note that scaling doesn't make sense if equal loudness is applied (default = 1, normalization applied)
%
% Outputs:
%   r                   filtered signals
%   fb                  filterbank
%       .h              gammatone FIR filters
%       .cf             center frequencies
%       .bw             bandwidths
%   parameters          output parameter settings for synthesis stage
%
% Written by John Woodruff in June 2012 (adapted from code by ZZ Jin and DL Wang)


if nargin < 2
    parameters = struct;
end

if ~isfield(parameters,'fs')
    parameters.fs = 16000;
end
if ~isfield(parameters,'nc')
    parameters.nc = 64;
end
if ~isfield(parameters,'fRange')
    parameters.fRange = [50 8000];
end
if ~isfield(parameters,'complex')
    parameters.complex = 0;
end
if ~isfield(parameters,'el')
    parameters.el = 1;
end
if ~isfield(parameters,'delayComp')
    parameters.delayComp = 0;
end
if ~isfield(parameters,'normalize')
    parameters.normalize = 0;
end

filterOrder = 4;    % filter order
gL = ceil(.128*parameters.fs);  % gammatone filter length: ~128 ms

sigLength = length(signal);     % input signal length

erb_b = hz2erb(parameters.fRange);       % upper and lower bound of ERB
erb = erb_b(1):diff(erb_b)/(parameters.nc-1):erb_b(2);     % ERB segment
cf = erb2hz(erb);       % center frequency array indexed by channel
% Glasberg and Moore
b = 1.019*24.7*(4.37*cf/1000+1);       % rate of decay or bandwidth

if parameters.delayComp == 1
    % adjust envelope and fine structure to account for channel-dependent
    % delay, high frequency channels are delayed to match group delay of lowest
    % channel
    env_max = (filterOrder-1)./(2*pi*b);
    shift = ceil(parameters.fs*env_max(1))/parameters.fs - env_max; % ensure desired group delay falls on sample value
    phase = -2*pi*cf*env_max(1);
else
    shift = zeros(1,parameters.nc);
    phase = zeros(1,parameters.nc);
end
gains = zeros(1,parameters.nc);

% Generating gammatone impulse responses
gt = zeros(parameters.nc,gL);  % Initialization
tmp_t = [1:gL]/parameters.fs;

for i = 1:parameters.nc
    gain = 1/3*(2*pi*b(i)/parameters.fs).^4;   
    if parameters.el
        gain = gain * 10^((loudness(cf(i))-60)/20);   % loudness-based gain adjustments
    end
    gains(i) = gain;

    if parameters.complex
        gt(i,:) = gain*parameters.fs^3*max(0,tmp_t-shift(i)).^(filterOrder-1).*exp(-2*pi*b(i)*(tmp_t-shift(i))).*exp(1i*2*pi*cf(i)*tmp_t+1i*phase(i));
    else
        gt(i,:) = gain*parameters.fs^3*max(0,tmp_t-shift(i)).^(filterOrder-1).*exp(-2*pi*b(i)*(tmp_t-shift(i))).*cos(2*pi*cf(i)*tmp_t+phase(i));
    end
    
end

if parameters.normalize
    % normalize filterbank to have unity gain in pass band
    gt = normalize_gtbank(gt,cf,parameters.fs,parameters.delayComp);
end

sig = reshape(signal,sigLength,1);      % convert input to column vector

if parameters.delayComp == 1
    % pad with zeros to allow time-alignment with input below
    sig = [sig;zeros(gL-1,1)];
end

% gammatone filtering using FFTFILT
r = fftfilt(gt.',sig).';

% select the appropriate samples so that output is time-aligned to input
% (note that this process is non-causal)
if parameters.delayComp == 1
    start = ceil(parameters.fs*env_max(1));
    range = start:(start+sigLength-1);
    r = r(:,range);
end

fb.h = gt;
fb.cf = cf;
fb.bw = b;

function [gmt cvmat] = logsp2gmt(logsp, cvmat)

    if ~exist('cvmat')
        para.NFFT = 320;
        cvmat = spc2gmt(para);
    end
    
    logsp = logsp';
    sp = [logsp; flipud(logsp(2:end-1,:))];
    sp = (10.^sp).^2;
    
    gmt = cvmat * sp;
    

end
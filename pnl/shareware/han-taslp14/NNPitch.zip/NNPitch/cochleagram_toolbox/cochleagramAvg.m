function [a,b] = cochleagramAvg(r, winLength, winShift)
% a = cochleagram(r, winLength, winShift)
%
% Generate a cochleagram from responses of a Gammatone filterbank.
% It gives the energy of T-F units
% The first variable is required.
% winLength: window (frame) length in samples
% Written by ZZ Jin, and adapted by DLW in Jan'07

if nargin < 2
    winLength = 320;      % default window length in sample points which is 20 ms for 16 KHz sampling frequency
end
    
[numChan,sigLength] = size(r);     % number of channels and input signal length

if nargin < 3
    winShift = floor(winLength/2);            % frame shift (default is half frame)
end

increment = floor(winLength/winShift);    % special treatment for first increment-1 frames
M = floor(sigLength/winShift);     % number of time frames

% calculate energy for each frame in each channel
a = zeros(numChan,M);
b = zeros(numChan,M);
%c = zeros(numChan,M);
for m = 1:M      
    for i = 1:numChan
        if m < increment        % shorter frame lengths for beginning frames
           % a(i,m) = r(i,1:m*winShift)*r(i,1:m*winShift)';
            a(i,m) = mean(r(i,1:m*winShift));
            b(i,m) = std(r(i,1:m*winShift));
        else
            startpoint = (m-increment)*winShift;
            a(i,m) = mean(r(i,startpoint+1:startpoint+winLength));
            b(i,m) = std(r(i,startpoint+1:startpoint+winLength));
            
            %temp = mean((r(i,startpoint+1:startpoint+winLength) - a(i,m)).^4);
            %c(i,m) = temp/(b(i,m).^4) - 3;
        end
    end
end

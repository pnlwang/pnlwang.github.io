function gt = normalize_gtbank(gt,cf,fs,mode)

if nargin < 4
    mode = 0;
end
    
NFFT = 2^ceil(log2(size(gt,2)));
bin_freqs = (0:(NFFT/2))*(fs/NFFT);
range = find(bin_freqs>=cf(4) & bin_freqs<=cf(end-3));
    
GT = fft(gt,NFFT,2);
    
if mode == 0
    % this normalization assumes linear phase analysis-synthesis process
    func = sum(abs(GT(:,range)).^2,1);
    scale = sqrt(1/mean(func));
else
    % this normalization assumes single-pass synthesis through
    % time-aligned filters
    func = abs(sum(GT(:,range),1));
    scale = 1/mean(func);
end
gt = gt*scale;
    

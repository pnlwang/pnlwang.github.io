function mid = compute_neuron(Z, unittype)

    switch unittype
        case 'sigmoid'
            mid = sigmoid(Z);
        case 'relu'
            Z(Z==-inf) = -1e7;
            Z(Z==inf) = 1e7;
            pos = single(Z>0);
            mid = Z.*pos;
    end

end
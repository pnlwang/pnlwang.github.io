function sigmgrad = sigmoid_grad(x)
    sigmgrad = x.*(1-x);
end

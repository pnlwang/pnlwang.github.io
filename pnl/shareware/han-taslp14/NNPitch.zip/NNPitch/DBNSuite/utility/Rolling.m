function [net rest] = Rolling(theta, netstruct)

nLayer = length(netstruct) - 1;

% [26 500 50]

net = [];
tmp = theta;
for ll = 1: nLayer
    vis = netstruct(ll);
    hid = netstruct(ll+1);
    net(ll).W = reshape(tmp(1:vis*hid),hid, vis);
    tmp = tmp(vis*hid+1 : end);
    net(ll).b = tmp(1:hid);
    tmp = tmp(hid+1:end);
end

rest = tmp;
% assert(isempty(tmp));
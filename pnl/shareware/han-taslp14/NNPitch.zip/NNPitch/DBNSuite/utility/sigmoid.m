
function sigm = sigmoid(x,a,b)
  
    if ~exist('a')
        a = 1;
    end
    if ~exist('b')
        b = 0;
    end
    
    sigm = 1 ./ (1 + exp(-a*x+b));
end


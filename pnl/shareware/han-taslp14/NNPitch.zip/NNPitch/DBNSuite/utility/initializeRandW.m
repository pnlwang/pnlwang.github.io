function W = initializeRandW(nhid,nvis)

r  = 6 / sqrt(nhid+nvis+1);  
W = rand(nhid, nvis) * 8 * r - 4*r;

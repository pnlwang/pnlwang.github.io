function [l2loss cost lastact] = checkCVRateMulti(theta, netstruct, data, clData, para)

[net, junk] = Rolling(theta, netstruct);
if strcmp(para.costFunc,'xentropy')
    [lastact record] = passThruNetSoftmax(net, data, para.unit_type);
else
    [lastact record] = passThruNet(net, data, para.unit_type);    
end
data = data';
[d,m] = size(data);
rho = para.sparsityParam;
lambda = para.lambda_L2;
beta = para.sp_beta;

nS = length(record);
rho_hidden = mean(record(nS-1).A,2); % sparsity on the last hidden layer

%l2loss = 0.5*(sum(sum((lastact - clData).^2)))/(m);
l2loss = (sum(sum(abs(lastact - clData))))/(m*size(clData,2));

if strcmp(para.thetaType,'mse')  
    KL = sum(rho*log(rho./rho_hidden)+(1-rho)*log((1-rho)./(1-rho_hidden)));
    sumw = 0;
    for i = 1:length(net)
        tmpW = net(i).W;
        sumw = sumw + 0.5*lambda*sum(sum(tmpW.^2));
    end
    cost = l2loss + beta * KL + sumw;
    
else % cross-entropy
    cost = -(mean(clData.*log(lastact)+(1-clData).*log(1-lastact)));
    cost = mean(cost);
end


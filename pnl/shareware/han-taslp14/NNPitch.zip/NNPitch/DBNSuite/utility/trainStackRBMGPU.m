function deepnet = trainStackRBMGPU(data,netstruct,maxepoch,nbatch)

if nargin < 3; maxepoch = 200; end;
if nargin < 4; nbatch = 20; end;
    
deepnet = struct;
nLayer = length(netstruct)-1;
% 26-50-25-26
% 26-100-50

curData = data;
icount = 1;
for ll = 1: nLayer
    disp(['Training Stacked RBM Layer #',int2str(ll)]);
    hiddenSize = netstruct(ll+1);
    visibleSize = netstruct(ll); 
    
    para.hiddenSize = hiddenSize; 
    para.visibleSize = visibleSize;
    para.maxepoch = maxepoch;
%     para.nbatch = 20000; % s200n5/20000 is good. approx 26 in a batch
    para.nbatch = nbatch;
    
%     net = trainRBM(curData,para);
    if ll <=1 
        net = fastTrainRBMGPU(curData,para);
    else
        net = fastTrainRBMBinaryGPU(curData,para);
    end
    
    net.W1 = gather(net.W1);
    net.b1 = gather(net.b1);
    net.bb1 = gather(net.bb1);
    
    deepnet(icount).W1 = net.W1;
    deepnet(icount).b1 = net.b1;
    deepnet(icount).bb1 = net.bb1;
        
    curData = passThruNet2(net,curData);
    
    %normalize CurD?
        
    icount = icount+1;
end

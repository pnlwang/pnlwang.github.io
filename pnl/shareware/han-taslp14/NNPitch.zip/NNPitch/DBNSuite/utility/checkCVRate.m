function [cvrate accrate hit fa pred prob] = checkCVRate(theta,cvdata,cvlb, netstruct)

% netstruct = opts.netstruct;

[optnet optlrtheta] = Rolling(theta, netstruct);


[lastact] = passThruNet(optnet, cvdata);
[pred prob] = lrRegressionPred(optlrtheta,lastact);
pred = double(pred);

accrate = sum(pred == cvlb) / length(cvlb);    


% or hit-fa rate
[j1 hit fa] = getHITFA(cvlb,pred);
cvrate = hit-fa;

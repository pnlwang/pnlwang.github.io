function net = dropout_net(net, dpw)

for i = 1:length(net)
    net(i).W = net(i).W * dpw;
    net(i).b = net(i).b * dpw;
end
function W = initializeRandW3(nhid,nvis)

 r  = 1 / sqrt(nhid*nvis+1);  
 W = randn(nhid, nvis) * r - 20 *r;
  W = randn(nhid, nvis) ;

  
%  r  = 6 / sqrt(nhid+nvis+1);  
%W = rand(nhid, nvis) * 8 * r - 4*r;

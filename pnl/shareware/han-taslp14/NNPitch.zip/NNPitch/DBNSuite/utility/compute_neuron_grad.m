function grad = compute_neuron_grad(x, unit_type)

switch unit_type
    case 'sigmoid'
        grad = x.*(1-x);
    case 'relu'
        grad = double(x>0);
end

end
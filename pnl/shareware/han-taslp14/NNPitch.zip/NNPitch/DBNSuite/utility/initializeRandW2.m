function W = initializeRandW2(nhid,nvis)

%r  = 6 / sqrt(nhid+nvis+1);  
%W = rand(nhid, nvis) * 8 * r - 4*r;

%nw = randn(nhid, nvis);
%alpha = 0.3/sqrt(nvis);
%W = nw*alpha;

for i = 1:nhid
    nw(i,:) = randn(1, nvis);
end
alpha = 0.3/sqrt(nvis);
W = nw*alpha;

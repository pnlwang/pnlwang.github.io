function net = randinitnet(netstruct, isNorm)

if nargin < 2; isNorm = 0; end;

nLayer = length(netstruct)-1;

net = [];
for i = 1: nLayer
    net(i).W1 = initializeRandW2(netstruct(i+1),netstruct(i));
    net(i).b1 = zeros(netstruct(i+1),1);
    
    if isNorm
        tmp = net(i).W1;
        net(i).W1 = tmp ./ repmat(sqrt(sum(tmp.^2,2)), 1, size(tmp,2)); 
    end
    
end

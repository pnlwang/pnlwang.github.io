function [nm] = zero_one_norm_restoring(data, minData, rangeData)
% [zero to one] norm w.r.t features

% NOTE: when data is a single point, the following still
%       performs mean/var norm, but w.r.t. that single point
%       rather than features. --> change to mean(data,1); var(data,1)
%       esstially the same as mean_var_norm_row

%minData = min(data, [], 1);
%rangeData = max(data, [], 1) - minData;

%nm = (data - repmat(minData, size(data,1),1))./repmat(rangeData,size(data,1),1);

data = data .* repmat(rangeData,size(data,1),1);
nm = data + repmat(minData, size(data,1),1);
nm(isnan(nm)) = 0;
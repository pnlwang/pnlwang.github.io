 function [pred mse optnet optlrtheta lastact para] = DNNTrainMultiSoftmaxLabelsGPU(data, label, cv_data, cv_label, para)
%function [pred acc hit fa prob cvprob optnet optlrtheta para preNet] = DNNTrain(data, label, cv_data, cv_label, test_data, test_label)

% %%
% clear all;

addpath(genpath('./DBNSuite'));


label = double(label);
cv_label = double(cv_label);

%% params setting
if ~isfield(para,'sgdBatch')
    para.sgdBatch = 256;
end

if ~isfield(para,'unit_type')
    para.unit_type = 'sigmoid';
end

if ~isfield(para,'sp_beta')
    para.sp_beta = 0.01;
end
if ~isfield(para,'sparsityParam')
    para.sparsityParam = 0.1;    
end
if ~isfield(para,'lambda_L2')
    para.lambda_L2 = 1e-4;
end


if ~isfield(para,'rbmEpoch')
    para.rbmEpoch = 50;
end


if ~isfield(para,'sgdMaxEpoch')
    para.sgdMaxEpoch = 50;
end
if ~isfield(para,'thetaType')
    para.thetaType = 'mse';
    % para.thetaType = 'avg';
    %para.thetaType = 'acc';
end
if ~isfield(para,'hidstruct')
    para.hidstruct = [200 200];
    % para.hidstruct = [60 60];
end
if ~isfield(para,'isRBM')
    para.isRBM = true;
    %para.isRBM = false;
end
if ~isfield(para,'costFunc')
    %para.costFunc = 'HFAcc';
     para.costFunc = 'xentropy';
    % para.costFunc = 'maxHF';    
    % para.costFunc = 'consFA';
end
if ~isfield(para,'lastLayer')
    para.lastLayer = 'sigmoid';
end
if ~isfield(para,'epsilon1')
    para.epsilon1 = 0.1;
end
if ~isfield(para,'epsilon2')
    para.epsilon2 = -1;
end
%% normalization

[rowTrData, para.tr_mu, para.tr_std] = mean_var_norm(data);
cv_data = mean_var_norm_testing(cv_data, para.tr_mu, para.tr_std);

%% intialization
netStruct = [size(rowTrData,2) para.hidstruct]

if ~isfield(para,'initWeights') || isempty(para.initWeights)
    
    if para.isRBM
        if ~isfield(para,'gpu') | para.gpu == 1
            preNet = trainStackRBMGPU(rowTrData, netStruct, para.rbmEpoch, 512);
        else
            preNet = trainStackRBM(rowTrData, netStruct, para.rbmEpoch, 512);
        end
    else
        preNet = randinitnet(netStruct,1);
    end

    outact = passThruNetSoftmax2(preNet,rowTrData,para.unit_type);
    prelastNet = randinitnet([size(outact,2) size(label,2)]);
    
else
    nHiddenLayer = length(para.hidstruct);
    preNet(1:nHiddenLayer) = para.initWeights(1:nHiddenLayer);
    preNet = fixWb(preNet);
    prelastNet = fixWb(para.initWeights(nHiddenLayer+1));
end


%% CV
% cv_data = mean_var_norm_testing(cv_data, para.tr_mu, para.tr_std);
cv_data(isnan(cv_data)) = 0;
%cv_label(cv_label == -1) = 0;


%% SGD training
maxEpoch = para.sgdMaxEpoch;
epsilonw = linspace(para.epsilon1,para.epsilon2,maxEpoch);
if para.epsilon2 == -1     
    sctmp = 1.^[0:maxEpoch-1];
    epsilonw = sctmp .* para.epsilon1;
end

initialmomentum  = 0.5;
finalmomentum    = 0.9;

%label(label== -1) = 0 ;
nettheta = unRolling(preNet);
preopttheta = unRolling(prelastNet);
alltheta = [nettheta; preopttheta];
alltheta = single(alltheta);

batchid = genBatchFixNum(size(data,1),para.sgdBatch);
nBatch = size(batchid,2);
% batchSize = batchid(2,1) - batchid(1,1) + 1;

para
Winc = 0;
icount = 0;
avgtheta = 0;
cvrecord = [];
netStruct2 = [netStruct size(label,2)];
for epoch = 1: maxEpoch
   seq = randperm(size(data,1));      
   permData = (rowTrData(seq,:));
   permLabel = label(seq,:);
   
   costsum = 0; errsum = 0;
   for bid = 1: nBatch-1 % need to fix it
       icount = icount + 1;
       numcases = batchid(2,bid) - batchid(1,bid) + 1;
       batchData = permData(batchid(1,bid):batchid(2,bid),:);
       if ~isfield(para,'gpu') | para.gpu == 1
            batchData = gpuArray(batchData);
       end
       batchLabel = permLabel(batchid(1,bid):batchid(2,bid),:);
       
       switch para.costFunc
           case 'xentropy'
               %[cost grad] = fineTuneLRCost(alltheta, netStruct, batchLabel, batchData, para.lambda_L2);
               [cost,grad,merr] = MultiLayerCESoftmaxCost(alltheta, netStruct2, para.lambda_L2, para.sparsityParam, para.sp_beta, batchData, batchLabel, para.unit_type);
           case 'mse'               
               [cost,grad,merr] = MultiLayerAECost(alltheta, netStruct2, para.lambda_L2, para.sparsityParam, para.sp_beta, batchData, batchLabel, para.unit_type);
           case 'msereg'               
               [cost,grad,merr] = MultiLayerAERegressCost(alltheta, netStruct2, para.lambda_L2, para.sparsityParam, para.sp_beta, batchData, batchLabel, para);               
           case 'maxHF'
               [cost grad] = fineTuneHFLRCost(alltheta, netStruct, batchLabel, batchData, para.lambda_L2);
           case 'HFAcc'
               [cost grad] = fineTuneHFAccLRCost(alltheta, netStruct, batchLabel, batchData, para.lambda_L2, 0.5);               
           case 'consFA'
               [cost grad] = fineTuneHFLRCost_consFA(alltheta, netStruct, batchLabel, batchData, para.lambda_L2, 0.03,3);
           case 'alter'
%                if mod(epoch,2)
               if epoch <= 8
                   [cost grad] = fineTuneLRCost(alltheta, netStruct, batchLabel, batchData, para.lambda_L2);
               else
                   [cost grad] = fineTuneHFLRCost(alltheta, netStruct, batchLabel, batchData, para.lambda_L2);
               end
           otherwise
               error('no cost func.')
       end
      
       if epoch>maxEpoch/2
         momentum=finalmomentum;
       else
         momentum=initialmomentum;
       end
      
       if ~isfield(para,'gpu') | para.gpu == 1
            grad = gather(grad);
            cost = gather(cost);
       end
       if exist('merr')
            merr = gather(merr);
       end
       if ~isempty(find(isnan(grad)==1))
           ttttt=111;
       end
       
       Winc = momentum*Winc + epsilonw(epoch)*(grad);       
       alltheta = alltheta - Winc;                     
       costsum = costsum + cost;
       if exist('merr')
            errsum = errsum + merr;
       end
   end   
   errsum = errsum / size(data,1);
   fprintf(['Sum of cost at epoch ', int2str(epoch), ' is ', num2str(costsum)]);   
   fprintf([', MAbE: ', num2str(errsum)]);   
   if (isnan(errsum))
       fprintf('NAN Error!');
       return;
   end
   
   avgtheta = avgtheta + alltheta;
   
   % cross-validation 
   [cvmse cvcost cvoutput] = checkCVRateMulti(alltheta, netStruct2, cv_data, cv_label, para);

   %disp([' / CV MSE: ' num2str(cvmse) ' Cost: ' num2str(cvcost)])   
       
       if size(cvoutput,2)>1       
            [~,id] = max(cvoutput,[],2);
            [~,cvid] = find(cv_label==1);
       else
           id = cvoutput>0.5;
           cvid = cv_label;
       end
       cverr = sum(id~=cvid)/length(cvid);
       %cvmse = mean(mean((cvoutput-cv_label).^2));%1 - weighted_acc(id, cvid);   
       %disp([' / CV UE: ' num2str(cvmse) ' WE: ' num2str(cverr)])
       fprintf(' / CV MSE: %g Err: %g', cvmse, cverr)

   if strcmp(para.thetaType,'xentropy')
       cvmse = cvcost;
       fprintf(' / CV XEntropy: %g', cvcost);
   end       
   fprintf('\n');

   if epoch>1 & para.epsilon2==-1
        if (cvmse >= cvrecord.mse(epoch-1))
            alltheta = (cvrecord.X(epoch-1,:))';
            disp('CV err increase !!! Reduce the learning rate!!!');
            epsilonw = epsilonw * 0.618;
            cvmse = cvrecord.mse(epoch-1);
            cvcost = cvrecord.cost(epoch-1);
        end
   end
   
   
   cvrecord.mse(epoch) = cvmse;
   cvrecord.cost(epoch) = cvcost;
   cvrecord.X(epoch,:) = alltheta';      
end

switch para.thetaType
    case 'avg'
        optalltheta = avgtheta / maxEpoch;
        [cvmse cvcost] = checkCVRateMulti(optalltheta, netStruct2, cv_data, cv_label, para);
        disp(['Avergared SGD --> CV MSE: ' num2str(cvmse) ' Cost: ' num2str(cvcost)])           
    case 'mse'
        [mv mi] = min(cvrecord.mse);
        disp(['Early Stopping --> best MSE ' num2str(mv),' at epoch ',int2str(mi)]);
        optalltheta = cvrecord.X(mi,:)';                
        [cvmse cvcost] = checkCVRateMulti(optalltheta, netStruct2, cv_data, cv_label, para);
        disp(['Training MSE ' num2str(cvmse) ', Cost ' num2str(cvcost)])
    case 'xentropy'
        [mv mi] = min(cvrecord.cost);
        disp(['Early Stopping --> best Cross Entropy ' num2str(mv),' at epoch ',int2str(mi)]);
        optalltheta = cvrecord.X(mi,:)';                
        [cvmse cvcost] = checkCVRateMulti(optalltheta, netStruct2, cv_data, cv_label, para);
        disp(['Training Cross-entropy ' num2str(cvmse) ', Cost ' num2str(cvcost)])        
    case 'HITFA'
        [mv mi] = max(hitfa);
        disp(['Early Stopping --> best HITFA ' num2str(mv),' at epoch ',int2str(mi)]);
        optalltheta = cvrecord.X(mi,:)';                
        [cvmse cvcost] = checkCVRateMulti(optalltheta, netStruct2, cv_data, cv_label, para);
        disp(['Training MSE ' num2str(cvmse) ', Cost ' num2str(cvcost)])        
end

[optnet optlrtheta] = Rolling(optalltheta, netStruct2);

[lastact] = passThruNetSoftmax(optnet, rowTrData, para.unit_type);
%[pred prob] = lrRegressionPred(optlrtheta,lastact);
pred = lastact;
mse = 0.5 * sum(sum((pred-label).^2))/size(rowTrData,1);


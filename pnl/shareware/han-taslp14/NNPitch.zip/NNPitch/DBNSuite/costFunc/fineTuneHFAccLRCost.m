function [cost grad] = fineTuneHFAccLRCost(alltheta, netstruct, label, data, lambda, beta)

% if nargin < 5; lambda = 0; end; % lambda is l2 regularizer for LR, we don't consider decay for networks
label(label==-1) = 0; % label=double(label);
[net lrtheta] = Rolling(alltheta, netstruct);
assert(length(lrtheta) == length(net(end).b)+1);


[lastact record] = passThruNet(net, data); % feedforward, no W2

data = data'; m = size(data,2);
lrtheta = lrtheta'; % row vector

%% -- COST and gradient for LR ----
[junk prob] = lrRegressionPred(lrtheta',lastact); % already padded with bias

% cost = -(mean(label.*log(prob)+(1-label).*log(1-prob))) + 0.5*lambda*sum(lrtheta.^2); % cross-entropy + weight decay
% cost = 0.5*mean((label-prob).^2) + 0.5*lambda*sum(lrtheta.^2);

% lambda = 1e-4;
n_label = 1-label; P = sum(label); Q = sum(n_label);

% cost = -(sum(label.*prob)/P - sum(n_label.*prob)/Q) + 0.5*lambda*sum(lrtheta.^2);

xentropy = -beta*(sum(label.*log(prob)+(1-label).*log(1-prob))) / m;
cost = -(sum(label.*prob)/P - sum(n_label.*prob)/Q) + xentropy + 0.5*lambda*sum(lrtheta.^2);

expand_act = [lastact ones(m,1)];

lhs = label.*sigmoid_grad(prob);
hit_grad = (sum(repmat(lhs,1,size(expand_act,2)) .* expand_act)')/P;     
rhs = n_label.*sigmoid_grad(prob);
fa_grad = (sum(repmat(rhs,1,size(expand_act,2)) .* expand_act)')/Q; 

% xentropy_grad = -expand_act'*(label-prob)/m;
xentropy_grad = -beta*expand_act'*(label-prob) / m;

lrtheta_grad = -(hit_grad - fa_grad) + xentropy_grad + lambda*lrtheta';


%% -- gradients for deepnets by backprop to each hidden units----
partial = lrtheta(1:end-1);
nLayer = length(netstruct) - 1;
Grads = struct;

% if n layer net then n+1 layer units (n_l = nLayer+1)
nHidden = nLayer+1;
% D_out = -((label - prob)*partial)'.*sigmoid_grad(record(nHidden).A);
% intm =  -(label.*sigmoid_grad(prob)/P - n_label.*sigmoid_grad(prob)/Q);
% D_out = -(intm * partial)'.*sigmoid_grad(record(nHidden).A);
xentropy_D_out = -beta*((label - prob)*partial)'.*sigmoid_grad(record(nHidden).A)/m;
D_out = xentropy_D_out -((label.*sigmoid_grad(prob) * partial)'.*sigmoid_grad(record(nHidden).A)/P - (n_label.*sigmoid_grad(prob) * partial)'.*sigmoid_grad(record(nHidden).A)/Q);


% Grads(nHidden-1).Wgrad = D_out*record(nHidden-1).A'/m;
% Grads(nHidden-1).bgrad = mean(D_out,2);

upperD = D_out;
for ll = nHidden-1 : -1 : 1        
%     Grads(ll).Wgrad = upperD*record(ll).A'/m;
%     Grads(ll).bgrad = mean(upperD,2); 

    Grads(ll).Wgrad = upperD*record(ll).A';
    Grads(ll).bgrad = sum(upperD,2); 

    D = net(ll).W'*upperD.*sigmoid_grad(record(ll).A);       
%     D = net(ll).W'*upperD.*grad_sigmoid(record(ll).A);       
%     Grads(ll-1).Wgrad = upperD.*record(ll-1).A'/m;
%     Grads(ll-1).bgrad = mean(upperD,2);
    upperD = D;
end
% Ds = zeros(nLayer+1,size(D_last,1),size(D_last,2));
% Ds(nLayer+1,:,:) = D_last;
% grad = [];
% 
% for ll = (nLayer-1): -1 : 2
%     Ds(ll,:,:) = net(ll).W'*Ds(ll+1,:,:).*sigmoid_grad(record(ll).A);
% end
% 

grad=[];
for ll = 1:nLayer   
    grad = [grad; Grads(ll).Wgrad(:); Grads(ll).bgrad(:)];
end
grad = [grad; lrtheta_grad];

%% test -- only one hidden layer, topped by an LR layer
% D2 = -((label - prob)*partial)'.*sigmoid_grad(record(2).A); % not Z since f'(z) = a*(1-a)
% % D1 = net(1).W'*D2.*sigmoid_grad(record;
% Wgrad = D2*record(1).A'/m;
% bgrad = mean(D2,2);
% 
% grad = [Wgrad(:); bgrad(:)];
% grad = [grad; lrtheta_grad];


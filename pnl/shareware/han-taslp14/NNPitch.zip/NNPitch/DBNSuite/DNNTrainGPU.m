 function [pred acc optnet optlrtheta lastact para] = DNNTrainGPU(data, label, cv_data, cv_label, para)
%function [pred acc hit fa prob cvprob optnet optlrtheta para preNet] = DNNTrain(data, label, cv_data, cv_label, test_data, test_label)

% %%
% clear all;

addpath('./DBNSuite/costFunc');
addpath('./DBNSuite/trainFunc');
addpath('./DBNSuite/utility');
addpath('./DBNSuite/minFunc');

label = double(label);
cv_label = double(cv_label);

%% params setting

if ~isfield(para,'sp_beta')
    para.sp_beta = 0.01;
end
if ~isfield(para,'sparsityParam')
    para.sparsityParam = 0.1;    
end
if ~isfield(para,'lambda_L2')
    para.lambda_L2 = 1e-4;
end
para.sgdBatch = 256;
if ~isfield(para,'rbmEpoch')
    para.rbmEpoch = 50;
end

if ~isfield(para,'sgdMaxEpoch')
    para.sgdMaxEpoch = 50;
end
if ~isfield(para,'thetaType')
    para.thetaType = 'hitfa';
    % para.thetaType = 'avg';
    %para.thetaType = 'acc';
end
if ~isfield(para,'hidstruct')
    para.hidstruct = [200 200];
    % para.hidstruct = [60 60];
end
if ~isfield(para,'isRBM')
    para.isRBM = true;
    %para.isRBM = false;
end
if ~isfield(para,'isMVA')
    para.isMVA = true;
    para.MVAOrder = 4;
    % para.isMVA = false;
end
if ~isfield(para,'costFunc')
    para.costFunc = 'HFAcc';
    % para.costFunc = 'xentropy';
    % para.costFunc = 'maxHF';    
    % para.costFunc = 'consFA';
end

%% normalization
if para.isMVA
    [rowTrData para.tr_mu para.tr_std] = MVAProcess(data, para.MVAOrder, 0); 
    cv_data = MVAProcess_testing(cv_data, para.MVAOrder, 0, para.tr_mu, para.tr_std);
%    cv_data = MVAProcess(cv_data, para.MVAOrder, 0);
else
    [rowTrData, para.tr_mu, para.tr_std] = mean_var_norm(data);
    cv_data = mean_var_norm_testing(cv_data, para.tr_mu, para.tr_std);
end
%% intialization
netStruct = [size(rowTrData,2) para.hidstruct]
if para.isRBM
    preNet = trainStackRBMGPU(rowTrData, netStruct, para.rbmEpoch, 512);
else
    preNet = randinitnet3(netStruct,1);
end
    
outact = passThruNet2(preNet,rowTrData);
[x,y,preopttheta] = lrRegression(label, outact, 3, 0, 'on');

%% CV
% cv_data = mean_var_norm_testing(cv_data, para.tr_mu, para.tr_std);
cv_data(isnan(cv_data)) = 0;
cv_label(cv_label == -1) = 0;



%% SGD training
maxEpoch = para.sgdMaxEpoch;
%epsilonw = linspace(1,0.01,maxEpoch);
slr = min(1, 0.1*length(para.hidstruct));
epsilonw = linspace(slr,0.001,maxEpoch);

initialmomentum  = 0.5;
finalmomentum    = 0.9;

label(label== -1) = 0 ;
nettheta = unRolling(preNet);
alltheta = [nettheta; preopttheta];

batchid = genBatchFixNum(size(data,1),para.sgdBatch);
nBatch = size(batchid,2);
% batchSize = batchid(2,1) - batchid(1,1) + 1;

para
Winc = 0;
icount = 0;
avgtheta = 0;
cvrecord = [];
for epoch = 1: maxEpoch
   seq = randperm(size(data,1));      
   permData = rowTrData(seq,:);
   permLabel = label(seq,:);
   
   costsum = 0;
   for bid = 1: nBatch-1 % need to fix it
       icount = icount + 1;
       numcases = batchid(2,bid) - batchid(1,bid) + 1;
       batchData = permData(batchid(1,bid):batchid(2,bid),:);
       batchData = gpuArray(batchData);
       batchLabel = permLabel(batchid(1,bid):batchid(2,bid));
       
       switch para.costFunc
           case 'xentropy'
               [cost grad] = fineTuneLRCost(alltheta, netStruct, batchLabel, batchData, para.lambda_L2);
           case 'maxHF'
               [cost grad] = fineTuneHFLRCost(alltheta, netStruct, batchLabel, batchData, para.lambda_L2);
           case 'HFAcc'
               [cost grad] = fineTuneHFAccLRCost(alltheta, netStruct, batchLabel, batchData, para.lambda_L2, 0.5);               
           case 'consFA'
               [cost grad] = fineTuneHFLRCost_consFA(alltheta, netStruct, batchLabel, batchData, para.lambda_L2, 0.03,3);                                             
           case 'alter'
%                if mod(epoch,2)
               if epoch <= 8
                   [cost grad] = fineTuneLRCost(alltheta, netStruct, batchLabel, batchData, para.lambda_L2);
               else
                   [cost grad] = fineTuneHFLRCost(alltheta, netStruct, batchLabel, batchData, para.lambda_L2);
               end
           otherwise
               error('no cost func.')
       end
      
       cost = gather(cost);
       grad = gather(grad);
       
       if epoch>maxEpoch/2
         momentum=finalmomentum;
       else
         momentum=initialmomentum;
       end        
       
       Winc = momentum*Winc + epsilonw(epoch)*(grad);       
       alltheta = alltheta - Winc;                     
       costsum = costsum + cost;
   end   
   fprintf(['Sum of cost at epoch ', int2str(epoch), ' is ', num2str(costsum)]);   
   
   avgtheta = avgtheta + alltheta;
   
   % cross-validation 
   [hitfa_rate acc_rate] = checkCVRate(alltheta, cv_data, cv_label, netStruct);
   disp(['CV HIT-FA Rate: ' num2str(hitfa_rate) ' Acc Rate: ' num2str(acc_rate)])
   cvrecord.hitfa_rate(epoch) = hitfa_rate;
   cvrecord.acc_rate(epoch) = acc_rate;
   cvrecord.X(epoch,:) = alltheta';   
end

switch para.thetaType
    case 'avg'
        optalltheta = avgtheta / maxEpoch;
        [hitfa_rate acc_rate hit fa cvpred cvprob] = checkCVRate(optalltheta, cv_data, cv_label, netStruct);
        disp(['Avergared SGD --> CV HIT-FA Rate: ' num2str(hitfa_rate) ' Acc Rate: ' num2str(acc_rate)])        
    case 'hitfa'
        [mv mi] = max(cvrecord.hitfa_rate);
        disp(['Early Stopping --> best HIT-FA rate ' num2str(mv),' at epoch ',int2str(mi)]);
        optalltheta = cvrecord.X(mi,:)';
        [hitfa_rate acc_rate hit fa cvpred cvprob] = checkCVRate(optalltheta, cv_data, cv_label, netStruct);
        disp(['HIT: ' num2str(hit) ' FA: ' num2str(fa)])        
    case 'acc'
        [mv mi] = max(cvrecord.acc_rate);
        disp(['Early Stopping --> best Acc rate ' num2str(mv),' at epoch ',int2str(mi)]);
        optalltheta = cvrecord.X(mi,:)';                
        [hitfa_rate acc_rate hit fa cvpred cvprob] = checkCVRate(optalltheta, cv_data, cv_label, netStruct);
        disp(['HIT: ' num2str(hit) ' FA: ' num2str(fa)])
end

[optnet optlrtheta] = Rolling(optalltheta, netStruct);


[lastact] = passThruNet(optnet, rowTrData);

[pred prob] = lrRegressionPred(optlrtheta,lastact);
acc = mean(pred == label);
pred = double(pred);
pred(pred == 0) = -1;
hit = sum((pred == 1) & (label == 1)) / sum(label == 1);
fa = sum((pred == 1) & (label == 0)) / sum(label == 0);


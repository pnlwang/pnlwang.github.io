function  [pred mse optnet optlrtheta lastact para] = DNNTrainDiscPretrain(data, label, cv_data, cv_label, para)

    
    para.isRBM = 0;
    nHidden = length(para.hidstruct);
    para1 = para;   
    
    netStruct = [size(data,2) para.hidstruct(1)]
    para1.initWeights = randinitnet(netStruct,1);
    para1.initWeights(2) = randinitnet([para.hidstruct(1) size(label,2)]);        
    para1.sgdMaxEpoch = 2;
    para1.epsilon1 = 0.1;  
    para1.epsilon2 = -1;
    para1.discPreTrain = 1;
    
    for curLayer = 1 : nHidden
        para1.hidstruct = para.hidstruct(1:curLayer);        
        [pred mse optnet optlrtheta lastact para1] = DNNTrainMulti2(data, label, cv_data, cv_label, para1);
        para1.initWeights = optnet;
    end

    para.initWeights = para1.initWeights;
    para.discPreTrain = 1;
    [pred mse optnet optlrtheta lastact para1] = DNNTrainMulti2(data, label, cv_data, cv_label, para);
    
end
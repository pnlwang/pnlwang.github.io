 function [pred mse optnet optlrtheta lastact para] = DNNTrainMultiGPU(data, label, cv_data, cv_label, para)
%function [pred acc hit fa prob cvprob optnet optlrtheta para preNet] = DNNTrain(data, label, cv_data, cv_label, test_data, test_label)

% %%
% clear all;

addpath('./DBNSuite');


label = double(label);
cv_label = double(cv_label);

%% params setting
if ~isfield(para,'unit_type')
    para.unit_type = 'sigmoid';
end
if ~isfield(para,'lambda_L2')
    para.lambda_L2 = 1e-4;
end
if ~isfield(para,'sgdBatch')
    para.sgdBatch = 256;
end
if ~isfield(para,'sparsityParam')
    para.sparsityParam = 0.1;
end
if ~isfield(para,'sp_beta')
    para.sp_beta = 0.01;    % regularization weight
end

if ~isfield(para,'rbmEpoch')
    para.rbmEpoch = 10;
end

if ~isfield(para,'sgdMaxEpoch')
    para.sgdMaxEpoch = 50;
end
if ~isfield(para,'thetaType')
    para.thetaType = 'mse';
    % para.thetaType = 'avg';
    %para.thetaType = 'acc';
end
if ~isfield(para,'hidstruct')
    para.hidstruct = [200 200];
    % para.hidstruct = [60 60];
end
if ~isfield(para,'isRBM')
    para.isRBM = true;
    %para.isRBM = false;
end
if ~isfield(para,'costFunc')
    %para.costFunc = 'HFAcc';
     para.costFunc = 'xentropy';
    % para.costFunc = 'maxHF';    
    % para.costFunc = 'consFA';
end
if ~isfield(para,'lastLayer')
    para.lastLayer = 'sigmoid';
end
if ~isfield(para,'epsilon1')
    para.epsilon1 = 0.1;
end
if ~isfield(para,'epsilon2')
    para.epsilon2 = -1;
end
%% normalization

[rowTrData, para.tr_mu, para.tr_std] = mean_var_norm(data);
cv_data = mean_var_norm_testing(cv_data, para.tr_mu, para.tr_std);

%% intialization
netStruct = [size(rowTrData,2) para.hidstruct]
if para.isRBM
    %rowTrData = gpuArray(rowTrData);
    preNet = trainStackRBMGPU(rowTrData, netStruct, para.rbmEpoch, 512);
else
    preNet = randinitnet(netStruct,1);
end
    
outact = passThruNet2(preNet,rowTrData);
%[x,y,preopttheta] = lrRegressionMulti(label, outact, 3, 0, 'on');
%preopttheta = 0.001*rand(size(outact,2)+1,size(label,2));
prelastNet = randinitnet([size(outact,2) size(label,2)]);

%% CV
% cv_data = mean_var_norm_testing(cv_data, para.tr_mu, para.tr_std);
cv_data(isnan(cv_data)) = 0;
%cv_label(cv_label == -1) = 0;



%% SGD training
maxEpoch = para.sgdMaxEpoch;
epsilonw = linspace(para.epsilon1,para.epsilon2,maxEpoch);
if para.epsilon2 == -1     
    sctmp = 1.^[0:maxEpoch-1];
    epsilonw = sctmp .* para.epsilon1;
end

initialmomentum  = 0.5;
finalmomentum    = 0.9;

%label(label== -1) = 0 ;
nettheta = unRolling(preNet);
preopttheta = unRolling(prelastNet);
alltheta = [nettheta; preopttheta];
alltheta = single(alltheta);

batchid = genBatchFixNum(size(data,1),para.sgdBatch);
nBatch = size(batchid,2);
% batchSize = batchid(2,1) - batchid(1,1) + 1;

para
Winc = 0;
icount = 0;
avgtheta = 0;
cvrecord = [];
netStruct2 = [netStruct size(label,2)];
for epoch = 1: maxEpoch
   seq = randperm(size(data,1));      
   permData = (rowTrData(seq,:));
   permLabel = label(seq,:);
   
   costsum = 0; errsum = 0;
   for bid = 1: nBatch-1 % need to fix it
       icount = icount + 1;
       numcases = batchid(2,bid) - batchid(1,bid) + 1;
       batchData = permData(batchid(1,bid):batchid(2,bid),:);
       batchData = gpuArray(batchData);
       batchLabel = permLabel(batchid(1,bid):batchid(2,bid),:);
       
       switch para.costFunc
           case 'xentropy'
               [cost grad] = fineTuneLRCost(alltheta, netStruct, batchLabel, batchData, para.lambda_L2);
           case 'mse'               
               [cost,grad,merr] = MultiLayerAECost(alltheta, netStruct2, para.lambda_L2, para.sparsityParam, para.sp_beta, batchData, batchLabel);
           case 'msereg'               
               [cost,grad,merr] = MultiLayerAERegressCost(alltheta, netStruct2, para.lambda_L2, para.sparsityParam, para.sp_beta, batchData, batchLabel, para);               
           case 'maxHF'
               [cost grad] = fineTuneHFLRCost(alltheta, netStruct, batchLabel, batchData, para.lambda_L2);
           case 'HFAcc'
               [cost grad] = fineTuneHFAccLRCost(alltheta, netStruct, batchLabel, batchData, para.lambda_L2, 0.5);               
           case 'consFA'
               [cost grad] = fineTuneHFLRCost_consFA(alltheta, netStruct, batchLabel, batchData, para.lambda_L2, 0.03,3);
           case 'alter'
%                if mod(epoch,2)
               if epoch <= 8
                   [cost grad] = fineTuneLRCost(alltheta, netStruct, batchLabel, batchData, para.lambda_L2);
               else
                   [cost grad] = fineTuneHFLRCost(alltheta, netStruct, batchLabel, batchData, para.lambda_L2);
               end
           otherwise
               error('no cost func.')
       end
      
       if epoch>maxEpoch/2
         momentum=finalmomentum;
       else
         momentum=initialmomentum;
       end
      
       grad = gather(grad);
       cost = gather(cost);
       if exist('merr')
        merr = gather(merr);
       end
       
       Winc = momentum*Winc + epsilonw(epoch)*(grad);       
       alltheta = alltheta - Winc;                     
       costsum = costsum + cost;
       if exist('merr')
        errsum = errsum + merr;
       end
   end   
   errsum = errsum / size(data,1);
   fprintf(['Sum of cost at epoch ', int2str(epoch), ' is ', num2str(costsum)]);   
   fprintf([', MAbE: ', num2str(errsum)]);   
   if (isnan(errsum))
       fprintf('NAN Error!');
       return;
   end
   
   avgtheta = avgtheta + alltheta;
   
   % cross-validation 
   [cvmse cvcost cvoutput] = checkCVRateMulti(alltheta, netStruct2, cv_data, cv_label, para);
   disp([' / CV MSE: ' num2str(cvmse) ' Cost: ' num2str(cvcost)])
   if strcmp(para.thetaType,'HITFA') ||strcmp(para.thetaType,'hitfa') 
       [j1(epoch) hit(epoch) fa(epoch)] = getHITFA(cv_label(:),gather(cvoutput(:))>0.5);
       hitfa(epoch) = hit(epoch) - fa(epoch);
       fprintf('Acc: %g HIT: %g, FA: %g, HIT-FA: %g\n',j1(epoch), hit(epoch), fa(epoch), hitfa(epoch));   
   end
   
   if epoch>1 & para.epsilon2==-1
        if (cvmse >= cvrecord.mse(epoch-1))
            alltheta = (cvrecord.X(epoch-1,:))';
            disp('CV err increase !!! Reduce the learning rate!!!');
            epsilonw = epsilonw * 0.618;
            cvmse = cvrecord.mse(epoch-1);
            cvcost = cvrecord.cost(epoch-1);
        end
   end   
   
   
   cvrecord.mse(epoch) = cvmse;
   cvrecord.cost(epoch) = cvcost;
   cvrecord.X(epoch,:) = alltheta';      
end

switch para.thetaType
    case 'avg'
        optalltheta = avgtheta / maxEpoch;
        [cvmse cvcost] = checkCVRateMulti(optalltheta, netStruct2, cv_data, cv_label, para);
        disp(['Avergared SGD --> CV MSE: ' num2str(cvmse) ' Cost: ' num2str(cvcost)])           
    case 'mse'
        [mv mi] = min(cvrecord.mse);
        disp(['Early Stopping --> best MSE ' num2str(mv),' at epoch ',int2str(mi)]);
        optalltheta = cvrecord.X(mi,:)';                
        [cvmse cvcost] = checkCVRateMulti(optalltheta, netStruct2, cv_data, cv_label, para);
        disp(['Training MSE ' num2str(cvmse) ', Cost ' num2str(cvcost)])
    case 'HITFA'
        [mv mi] = max(hitfa);
        disp(['Early Stopping --> best HITFA ' num2str(mv),' at epoch ',int2str(mi)]);
        optalltheta = cvrecord.X(mi,:)';                
        [cvmse cvcost] = checkCVRateMulti(optalltheta, netStruct2, cv_data, cv_label, para);
        disp(['Training MSE ' num2str(cvmse) ', Cost ' num2str(cvcost)])        
end

[optnet optlrtheta] = Rolling(optalltheta, netStruct2);

[lastact] = passThruNet(optnet, rowTrData);
%[pred prob] = lrRegressionPred(optlrtheta,lastact);
pred = lastact;
mse = 0.5 * sum(sum((pred-label).^2))/size(rowTrData,1);


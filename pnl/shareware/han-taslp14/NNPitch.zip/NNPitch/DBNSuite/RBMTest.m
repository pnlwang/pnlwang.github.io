 function [output mse] = RBMTest(Model, data)
%function [pred acc hit fa prob cvprob optnet optlrtheta para preNet] = DNNTrain(data, label, cv_data, cv_label, test_data, test_label)

% %%
% clear all;

addpath('./DBNSuite/costFunc');
addpath('./DBNSuite/trainFunc');
addpath('./DBNSuite/utility');
addpath('./DBNSuite/minFunc');


%% normalization
para = Model.para;

[rowTrData] = mean_var_norm_testing(data, para.tr_mu, para.tr_std);

%% intialization
Net = Model.optnet;
upact = passThruNet2(Net,rowTrData);
downact = passThruNet2Down(Net,upact);
%downact = passThruNet2DownSigmoid(Net,upact);
output = mean_var_norm_restoring(downact, para.tr_mu, para.tr_std);


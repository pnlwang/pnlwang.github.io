function [pred mse] = DNNTestMultiSoftmax(DNNModel, data, label)
%function [pred acc hit fa prob cvprob optnet optlrtheta para preNet] = DNNTrain(data, label, cv_data, cv_label, test_data, test_label)

% %%
% clear all;

addpath('./DBNSuite/costFunc');
addpath('./DBNSuite/trainFunc');
addpath('./DBNSuite/utility');
addpath('./DBNSuite/minFunc');


para = DNNModel.para;
optnet = DNNModel.optnet;
if ~isfield(para,'unit_type')
    para.unit_type = 'sigmoid';
end
%% normalization

[rowTrData] = mean_var_norm_testing(data, para.tr_mu, para.tr_std);

[lastact] = passThruNetSoftmax(optnet, rowTrData, para.unit_type);
%[pred prob] = lrRegressionPred(optlrtheta,lastact);
pred = lastact;
mse = 0.5 * sum(sum((pred-label).^2))/size(rowTrData,1);

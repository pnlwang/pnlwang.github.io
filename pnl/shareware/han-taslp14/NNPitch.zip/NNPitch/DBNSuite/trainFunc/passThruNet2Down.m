function [output record] = passThruNet2Down(deepnet,data)
% index i stores i-th activiation

nLayer = length(deepnet);
record = struct;

m = size(data,1);
data = data';
mid = data;
record(1).A = data;
for ll = nLayer+1:-1:3    
   Z = deepnet(ll-1).W1'*mid+repmat(deepnet(ll-1).bb1,1,m);
   mid = sigmoid(Z);
   record(ll).A = mid';
end

Z = deepnet(1).W1'*mid+repmat(deepnet(1).bb1,1,m);
%mid = sigmoid(Z);
mid = Z;
record(ll).A = mid';

output = mid';


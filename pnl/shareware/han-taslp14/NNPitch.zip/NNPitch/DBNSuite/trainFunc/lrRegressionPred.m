 function [pred prob] = lrRegressionPred(theta,data)


theta = theta';
data = data'; 
[ndim m] = size(data);
data = [data; ones(1,m)];


pred = sigmoid(theta*data); prob = pred';
pred = pred > 0.5;
pred = pred';


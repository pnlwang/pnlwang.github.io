function batchid = genBatchFixNum(datasize,fixnum)

display = false;
% [ndata ndim] = size(data);
ndata = datasize;
nbatch = ceil(ndata/fixnum);

batchid = zeros(2,nbatch);
for ii = 1: nbatch    
    first =  (ii-1)*fixnum+1;
    last = ii*fixnum;
    if display
        disp(['Batch #',int2str(ii),'...',int2str(first),'-->', int2str(last)]);
    end
    if last <= ndata
%         curdata = data(first:last,:);
        batchid(1,ii) = first;
        batchid(2,ii) = last;
    else
%         curdata = data(first:end,:);
        batchid(1,ii) = first;
        batchid(2,ii) = ndata;
    end
    
    
end
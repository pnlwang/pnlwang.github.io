function [pred acc opttheta] = lrRegressionMulti(label, data, maxiter, lambda, display)


[m ndim] = size(data);
theta = 0.005*randn(ndim+1,size(label,2));
% theta = 0.01*randn(ndim+1,1);

% theta = zeros(ndim+1,1);
% debug = true;
debug = false;
%% --- DEBUG ----
if debug
    testlb = label(1:1000); testlb(testlb==-1) = 0;
    testd = data(1:1000,:);
    lambda = 0; 
    [cost grad] = lrRegressionCost(theta, testlb, testd,lambda);

    %function below accepts column theta
    numgrad = computeNumericalGradient( @(p) lrRegressionCost(p, testlb, testd,lambda), theta);  

    [grad numgrad]
    diff = norm(numgrad-grad)/norm(numgrad+grad)
    assert(diff<1e-6)
end
%
% 

opt.maxiter = maxiter;
opt.display = display;

%label(label==-1) = 0;
[opttheta cost] = minFunc( @(p) lrRegressionMultiCost(p, label, data,lambda), theta, opt);

[pred prob] = lrRegressionMultiPred(opttheta,data);

acc = sum(pred == label) / length(label);

function [cost grad] = lrRegressionCost(theta,label,data,lambda)


label(label==-1)=0;
% theta is m-by-1 which is required by minFunc
theta = theta';

% append data
data = data'; 
[ndim m] = size(data);
data = [data; ones(1,m)];


prob = sigmoid(theta*data); prob = prob'; % m-by-1
cost = -(mean(label.*log(prob)+(1-label).*log(1-prob))) + 0.5*lambda*sum(theta.^2); % cross-entropy + weight decay

grad = -data*(label-prob)/m + lambda*theta';




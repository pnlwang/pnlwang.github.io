function [pred prob] = lrRegressionMultiPred(theta,data)


%theta = theta';
[net rest] = Rolling(theta, [size(data,2) length(theta)/(size(data,2)+1)]);

data = data'; 
[ndim m] = size(data);
data = [data; ones(1,m)];

pred = sigmoid([net.W net.b]*data); prob = pred';
pred = pred > 0.5;
pred = pred';

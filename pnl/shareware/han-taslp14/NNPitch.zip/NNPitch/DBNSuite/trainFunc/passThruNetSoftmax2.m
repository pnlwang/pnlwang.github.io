function [output record] = passThruNetSoftmax2(deepnet,data,unittype)
% index i stores i-th activiation

nLayer = length(deepnet);
record = struct;

if ~exist('unittype')
    unittype = 'sigmoid';
end

m = size(data,1);
data = data';
mid = data;
record(1).A = data;

for ll = 2: nLayer
   Z = deepnet(ll-1).W1*mid+repmat(deepnet(ll-1).b1,1,m);
   mid = compute_neuron(Z, unittype);
   record(ll).A = mid';
end

% last layer softmax
Z = deepnet(nLayer).W1*mid+repmat(deepnet(nLayer).b1,1,m);
sumZ = sum(exp(Z),1);
mid = exp(Z)./repmat(sumZ, size(deepnet(nLayer).W1, 1), 1);
record(nLayer+1).A = mid';

output = mid';



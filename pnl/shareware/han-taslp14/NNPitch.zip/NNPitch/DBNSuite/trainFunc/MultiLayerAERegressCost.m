function [cost,grad,err] = MultiLayerAERegressCost(alltheta, netstruct, lambda, sparsityParam, beta, data, clData, para)


[net, junk] = Rolling(alltheta, netstruct);

stacknet = net(1:length(net)-1);
[prelastact record] = passThruNet(stacknet, data);
data = data';
[d,m] = size(data);
%% Last layer neuron 

lastnet = net(length(net));
tmpsum = prelastact*lastnet.W'+repmat(lastnet.b',m,1);

if isfield(para,'lastLayer')&strcmp(para.lastLayer,'linear')
    % y = 0.125*x + 0.5
    lastact = 0.05 * tmpsum + 0.5;
elseif isfield(para,'lastLayer')&strcmp(para.lastLayer,'sigmoid3')
    lastact = 1 ./ (1 + exp(-3*tmpsum));
elseif isfield(para,'lastLayer')&strcmp(para.lastLayer,'sigmoid05')
    lastact = 1 ./ (1 + exp(-0.5*tmpsum));    
else
    lastact = sigmoid(tmpsum);
end

err = sum(sum(abs(lastact-clData)));

%%
rho = sparsityParam;

%% Modified, because of the last layer
nS = length(record)+1;
rho_hidden = mean(record(nS-1).A,2); % sparsity on the last hidden layer
%% ------ loss function --------
% beta = 0; 
% lambda = 0;

% xentropy = -mean((mean(A1.*log(A3)+(1-A1).*log(1-A3))));
l2loss = 0.5*(sum(sum((lastact - clData).^2)))/m;

KL = sum(rho*log(rho./rho_hidden)+(1-rho)*log((1-rho)./(1-rho_hidden)));

% lastW = net(end).W;
% cost = l2loss + beta * KL + lambda * 0.5 *sum(sum(lastW.^2)) ;

% lambda = 0;
sumw = 0;
for i = 1:length(net)
    tmpW = net(i).W;
    sumw = sumw + 0.5*lambda*sum(sum(tmpW.^2));
end
cost = l2loss + beta * KL + sumw;
%% ------ backprob -------
sp_grad = beta*(-rho./rho_hidden + (1-rho)./(1-rho_hidden));
sp_grad_mat = repmat(sp_grad,1,m);

nLayer = length(netstruct) - 1;
Grads = struct;

nHidden = nLayer+1;
%D_out = -(clData - lastact) .* sigmoid_grad(lastact);

if isfield(para,'lastLayer')&strcmp(para.lastLayer,'linear')
    % y = 0.125*x + 0.5
    D_out = -(clData - lastact) .* (0.05);
elseif isfield(para,'lastLayer')&strcmp(para.lastLayer,'sigmoid3')
    D_out = -(clData - lastact) .* sigmoid_grad(lastact) .* 3;
elseif isfield(para,'lastLayer')&strcmp(para.lastLayer,'sigmoid05')
    D_out = -(clData - lastact) .* sigmoid_grad(lastact) .* 0.5;   
else
    D_out = -(clData - lastact) .* sigmoid_grad(lastact);
end


upperD = D_out;
for ll = nHidden-1 : -1 : 1        
    % The last layer is linear
%     if ll == nHidden - 1
%         Grads(ll).Wgrad = upperD'*record(ll).A'/m + lambda * lastW;
%     else
%         Grads(ll).Wgrad = upperD'*record(ll).A'/m;
%     end
%     ll
    tmpW = net(ll).W;
    Grads(ll).Wgrad = upperD'*record(ll).A'/m + lambda * tmpW;    
    Grads(ll).bgrad = mean(upperD',2); 
    if ll == nS-1
        D = (net(ll).W'*upperD' + sp_grad_mat) .*sigmoid_grad(record(ll).A);       
    else
        D = (net(ll).W'*upperD') .*sigmoid_grad(record(ll).A);       
    end 
    upperD = D';
end


grad=[];
for ll = 1:nLayer   
    grad = [grad; Grads(ll).Wgrad(:); Grads(ll).bgrad(:)];
end

end

function sigmgrad = sigmoid_grad(x)
    sigmgrad = x.*(1-x);
end

function sigm = sigmoid(x) 
    sigm = 1 ./ (1 + exp(-x));
end


function [output record] = passThruNetSoftmax(deepnet,data,unittype)
% index i stores i-th activiation

nLayer = length(deepnet);
record = struct;

if ~exist('unittype')
    unittype = 'sigmoid';
end

m = size(data,1);
data = data';
mid = data;
record(1).A = data;
% for ll = 2: nLayer+1
% %    Z = deepnet(ll).W1*mid+repmat(deepnet(ll).b1,1,m);
%    Z = deepnet(ll-1).W*mid+repmat(deepnet(ll-1).b,1,m);
%    mid = sigmoid(Z);
% %    record(ll).Z = Z;
%    record(ll).A = mid;
% end

for ll = 2: nLayer
%    Z = deepnet(ll).W1*mid+repmat(deepnet(ll).b1,1,m);
   Z = deepnet(ll-1).W*mid+repmat(deepnet(ll-1).b,1,m);
   %mid = sigmoid(Z);
   mid = compute_neuron(Z, unittype);
%    record(ll).Z = Z;
   record(ll).A = mid;
end

% last layer softmax
Z = deepnet(nLayer).W*mid+repmat(deepnet(nLayer).b,1,m);

Z(Z>50) = 50;
Z(Z<-50) = -50;

sumZ = sum(exp(Z),1);
mid = exp(Z)./repmat(sumZ, size(deepnet(nLayer).W, 1), 1);

mid(mid>=1) = 1-1e-7;
mid(mid<=0) = 1e-7;

record(nLayer+1).A = mid;

if(~isempty(mid(mid>=1)) || ~isempty(mid(mid<=0)))
    tt=1;
end

output = mid';





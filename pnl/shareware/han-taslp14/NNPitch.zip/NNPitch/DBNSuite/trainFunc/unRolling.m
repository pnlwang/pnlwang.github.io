function theta = unRolling(deepnet)
% theta = unRolling(deepnet)

nLayer = length(deepnet);

theta = [];
for ll = 1: nLayer
    if isfield(deepnet(ll),'W1')            
        theta = [theta; deepnet(ll).W1(:); deepnet(ll).b1(:)];    
    else
        theta = [theta; deepnet(ll).W(:); deepnet(ll).b(:)];            
    end
end


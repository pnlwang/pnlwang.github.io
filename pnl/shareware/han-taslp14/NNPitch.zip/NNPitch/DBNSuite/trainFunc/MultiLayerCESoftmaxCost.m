function [cost,grad,err] = MultiLayerCESoftmaxCost(alltheta, netstruct, lambda, sparsityParam, beta, data, clData, unit_type)


if ~exist('unit_type')
    unit_type = 'sigmoid';
end

[net, junk] = Rolling(alltheta, netstruct);

[lastact record] = passThruNetSoftmax(net, data, unit_type);
data = data';
%% 

%fprintf('%g %g\n',max(lastact(:,50)), max(clData(:,50)));

[d,m] = size(data);
rho = sparsityParam;

nS = length(record);
rho_hidden = mean(record(nS-1).A,2); % sparsity on the last hidden layer
%% ------ loss function --------
% beta = 0; 
% lambda = 0;

% xentropy = -mean((mean(A1.*log(A3)+(1-A1).*log(1-A3))));
%l2loss = 0.5*(sum(sum((lastact - clData).^2)))/m;
err = sum(sum(abs(lastact-clData)));

%KL = sum(rho*log(rho./rho_hidden)+(1-rho)*log((1-rho)./(1-rho_hidden)));

% lastW = net(end).W;
% cost = l2loss + beta * KL + lambda * 0.5 *sum(sum(lastW.^2)) ;

% lambda = 0;
sumw = 0;
% for i = 1:length(net)
%     tmpW = net(i).W;
%     sumw = sumw + 0.5*lambda*sum(sum(tmpW.^2));
% end
try
lastact(lastact>=1) = 1-1e-7;
lastact(lastact<=0) = 1e-7;
cost = -(mean(clData.*log(lastact)+(1-clData).*log(1-lastact))) + sumw; % cross-entropy + weight decay
cost = mean(cost);
catch
    cost = 1;
end
%cost = l2loss + beta * KL + sumw;

%% ------ backprob -------
if beta ~= 0
    sp_grad = beta*(-rho./rho_hidden + (1-rho)./(1-rho_hidden));
    sp_grad_mat = repmat(sp_grad,1,m);
else
    sp_grad_mat = 0;
end

nLayer = length(netstruct) - 1;
Grads = struct;

nHidden = nLayer+1;
%D_out = -(clData - lastact) .* sigmoid_grad(lastact); % MSE
D_out = -(clData - lastact); % Cross entropy with softmax
%aa = [0.5 0.4 0.6 0.5 0.5]; bb = 1 - aa;
%D_out = -(repmat(aa, m, 1).*clData - repmat(bb, m, 1).*lastact - clData.*lastact.*repmat((aa-bb), m, 1));

upperD = D_out;
for ll = nHidden-1 : -1 : 1        
%     if ll == nHidden - 1
%         Grads(ll).Wgrad = upperD'*record(ll).A'/m + lambda * lastW;
%     else
%         Grads(ll).Wgrad = upperD'*record(ll).A'/m;
%     end
%     ll
    tmpW = net(ll).W;
    Grads(ll).Wgrad = upperD'*record(ll).A'/m + lambda * tmpW;
    
    Grads(ll).bgrad = mean(upperD',2); 
    if ll == nS-1
        D = (net(ll).W'*upperD' + sp_grad_mat) .*compute_neuron_grad(record(ll).A, unit_type);       
    else
        D = (net(ll).W'*upperD') .*compute_neuron_grad(record(ll).A, unit_type);       
    end
    
    mid2=D;
    mid2=gather(mid2);
    if find(isnan(mid2)==1)
        tt=2;
    end    
    
    upperD = D';   

end


grad=[];
for ll = 1:nLayer   
    grad = [grad; Grads(ll).Wgrad(:); Grads(ll).bgrad(:)];
end


end

function sigmgrad = sigmoid_grad(x)
    sigmgrad = x.*(1-x);
end

function sigm = sigmoid(x) 
    sigm = 1 ./ (1 + exp(-x));
end


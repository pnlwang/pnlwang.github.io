function [output record] = passThruNet2(deepnet,data,unittype)
% index i stores i-th activiation

if ~exist('unittype')
    unittype = 'sigmoid';
end

nLayer = length(deepnet);
record = struct;

m = size(data,1);
data = data';
mid = data;
record(1).A = data;
for ll = 2: nLayer+1
   Z = deepnet(ll-1).W1*mid+repmat(deepnet(ll-1).b1,1,m);
   mid = compute_neuron(Z, unittype);
   record(ll).A = mid';
end

output = mid';


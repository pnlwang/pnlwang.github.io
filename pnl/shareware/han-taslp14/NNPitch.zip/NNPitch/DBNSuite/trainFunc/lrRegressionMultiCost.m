function [cost grad] = lrRegressionMultiCost(theta,label,data,lambda)


%label(label==-1)=0;
% theta is mIn-by-mOut % which is required by minFunc
theta = theta'; % mOut x mIn

% append data
data = data';   % mIn x N
label = label';
[ndim m] = size(data);
[ndimOut m] = size(label);
data = [data; ones(1,m)];
b1 = ones(ndimOut,1); 
A3 = sigmoid(theta*data); 
prob = A3;

%prob = sigmoid(theta*data); prob = prob'; % m-by-1
%cost = -(mean(label.*log(prob)+(1-label).*log(1-prob))) + 0.5*lambda*sum(theta.^2); % cross-entropy + weight decay

sqLoss = 0.5*(sum(sum((prob-label).^2)))/m; % square loss
D3 = -(label - prob).*sigmoid_grad(prob); 

%l2_lambda = 1e-4; % l2 regularization, preventing weights from being too large
cost = sqLoss + 0.5*lambda*(sum(sum(theta.^2)));

grad = D3*data'/ m + lambda * theta;
%bgrad = mean(D3,2); 
%grad = [Wgrad(:); bgrad(:)];

%grad = -data*(label-prob)/m + lambda*theta';

%%


% %% ------ forward pass ----
% A1 = input'; 
% A2 = sigmoid(W1*A1+repmat(b1,1,nData)); 
% A3 = sigmoid(W2*A2+repmat(b2,1,nData)); 
% output = output';
% 
% mact_hidden = mean(A2,2); % mean activation level in the hidden layer
% %% ------ backprop --------
% sqLoss = 0.5*(sum(sum((A3-output).^2)))/nData; % square loss
% 
% D3 = -(output - A3).*sigmoid_grad(A3); 
% sp_grad =  sp_beta*(-mactLv./mact_hidden + (1-mactLv)./(1-mact_hidden)); 
% D2 = (W2'*D3+repmat(sp_grad,1,nData)).*sigmoid_grad(A2); 
% 
% KL = sum(mactLv*log(mactLv./mact_hidden)+(1-mactLv)*log((1-mactLv)./(1-mact_hidden))); % sparsity measure
% cost = sqLoss + 0.5*l2_lambda*(sum(sum(W1.^2))+ sum(sum(W2.^2))) + sp_beta*KL;
% 
% W2grad = D3*A2'/nData + l2_lambda * W2;
% b2grad = mean(D3,2); 
% %% 
% grad = [W1grad(:) ; W2grad(:) ; b1grad(:) ; b2grad(:)]; % vectorize gradients


 function [Net para downact] = RBMTrain(data, para)
%function [pred acc hit fa prob cvprob optnet optlrtheta para preNet] = DNNTrain(data, label, cv_data, cv_label, test_data, test_label)

% %%
% clear all;

addpath('./DBNSuite/costFunc');
addpath('./DBNSuite/trainFunc');
addpath('./DBNSuite/utility');
addpath('./DBNSuite/minFunc');

%% params setting
if ~isfield(para,'rbmEpoch')
    para.rbmEpoch = 100;
end
para.lambda_L2 = 1e-4;
para.sgdBatch = 256;
para.sparsityParam = 0.1;
para.sp_beta = 0.01;
if ~isfield(para,'sgdMaxEpoch')
    para.sgdMaxEpoch = 50;
end
if ~isfield(para,'thetaType')
    para.thetaType = 'mse';
    % para.thetaType = 'avg';
    %para.thetaType = 'acc';
end
if ~isfield(para,'hidstruct')
    para.hidstruct = [200 200];
    % para.hidstruct = [60 60];
end
para.isRBM = true;

if ~isfield(para,'costFunc')
    %para.costFunc = 'HFAcc';
     para.costFunc = 'xentropy';
    % para.costFunc = 'maxHF';    
    % para.costFunc = 'consFA';
end

%% normalization

[rowTrData, para.tr_mu, para.tr_std] = mean_var_norm(data);

%% intialization
netStruct = [size(rowTrData,2) para.hidstruct]

Net = trainStackRBM(rowTrData, netStruct, para.rbmEpoch, 512);

upact = passThruNet2(Net,rowTrData);
downact = passThruNet2Down(Net,upact);
mse = sum(sum(rowTrData - downact).^2)/size(data,2);
fprintf('Reconstruction MSE: %g\n', mse);


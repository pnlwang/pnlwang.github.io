function net2 = grad_checker(net, dim)

 nlayer = length(net);
 net2 = net;
 delta = 10e-4;
 
 for ll = 1:nlayer
     net2(ll).W = net(ll).W + delta;
     net2(ll).b = net(ll).b + delta;
 end

end
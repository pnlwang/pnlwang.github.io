function [pred acc hit fa test_label] = DNNTest(DNNModel, test_data, test_label)

    addpath('~/Kun/tools/DBNSuite/costFunc');
    addpath('~/Kun/tools/DBNSuite/trainFunc');
    addpath('~/Kun/tools/DBNSuite/utility');
    addpath('~/Kun/tools/DBNSuite/minFunc');    

    test_label = double(test_label);
    
    %% params setting
    para.hidstruct = [200 200];
    % para.hidstruct = [60 60];
    para.isRBM = true;
    % para.isRBM = false;
    para.rbmEpoch = 100;
    para.sgdMaxEpoch = 35;
    para.lambda_L2 = 1e-5;
    % para.thetaType = 'avg';
    para.thetaType = 'hitfa';
    para.sgdBatch = 256;
    para.MVAOrder = 4;
    para.isMVA = true;
    % para.isMVA = false;
    % para.costFunc = 'xentropy';
    % para.costFunc = 'maxHF';
     para.costFunc = 'HFAcc';
    % para.costFunc = 'consFA';

    para = DNNModel.para;
    optnet = DNNModel.optnet;
    if isfield(DNNModel,'optlrtheta')
        optlrtheta = DNNModel.optlrtheta;
    else
        optlrtheta = DNNModel.optweights;
    end
    
    %% normalization
    if para.isMVA
        test_data = MVAProcess_testing(test_data, para.MVAOrder, 0, para.tr_mu, para.tr_std);
    else
        test_data = mean_var_norm_testing(test_data, para.tr_mu, para.tr_std);
    end    

    %% Test
    test_data(isnan(test_data)) = 0;
    test_label(test_label == -1) = 0;    
    
    
    [lastact] = passThruNet(optnet, test_data);
      
    [pred prob] = lrRegressionPred(optlrtheta,lastact);
    acc = mean(pred == test_label);
    pred = double(pred);
    pred(pred == 0) = 0;
    hit = sum((pred == 1) & (test_label == 1)) / sum(test_label == 1);
    fa = sum((pred == 1) & (test_label == 0)) / sum(test_label == 0);    


end
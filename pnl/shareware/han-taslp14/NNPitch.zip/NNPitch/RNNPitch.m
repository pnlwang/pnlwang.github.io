function [f0] = RNNPitch(sig, alpha, model)
% Input:
%   sig: Time-domain signal, 16 kHz sampling frequency is required
%   alpha: Parameter of the voiced portion (default 0.22)
%   model: A trained DNN model. A model trained on TIMIT corpus is provided
%
% Output:
%   f0: Estimated fundermental frequency 
%
% Note that, to run the RNN code, you have to access a GPU and the Parallel toolbox in Matlab
% 
% Publication:
%   Han K. and Wang D.L. (2014):�Neural network based pitch tracking in very noisy speech.�IEEE/ACM Transactions on Audio, Speech, and Language Processing, vol. 22, pp. 2158-2168.�
%
    addpath(genpath('./DBNSuite/'));
    addpath(genpath('./RNN/'));
    addpath('./HMM/');
    addpath('./utilities/');
 
    if ~exist('model')
        model = load('./Models/RNN_Model.mat');
        model = model.net;
    end

    if nargin < 2
        alpha = 0.22;
    end
    vprob = 0.2;
    fs = 16000;
    feawin = 2;
    first = 0;
    last = 0;
    outputdim = 68;
    freqscale = load('./utilities/pitch_candidates_freqz.txt');
        

    [X tx] = feature_pefac(sig, fs, 0.01);   
    X = time_align(X, tx, length(sig));
    fea = getNeighbor(X,feawin);

    numfr = size(fea, 1);
    label = zeros(numfr, outputdim);
    
    [~,netid] = min(model.xentropy);
    net = model.net{netid};
    data = mean_var_norm_testing(fea, model.tr_mu, model.tr_std);
    opts = model.opt;
    ptprob = (gather(predDeepRNN_anyLayer(data', net, opts)))';
     
   
    load('./HMM/transition.mat');    
    priorProb(1) = priorProb(1)*alpha;    % reverberant
    
    ptprob1 = ptprob./repmat(priorProb,size(ptprob,1),1);    
    ptprobfn = ptprob1;    
    
    [VV, PP, path] = viterbi_decoding(transProb, ptprob1);
    path = path - 1;    % path: [0~67]
    f0p = pitch2freq(path, freqscale);       
    
    f0p = smooth_f0(f0p);
    f0 = f0p;
    
    PP = PP';
end


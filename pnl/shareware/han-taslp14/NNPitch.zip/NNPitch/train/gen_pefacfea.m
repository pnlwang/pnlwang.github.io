function [allfea] = gen_pefacfea(sig, feawin)

        addpath('../utilities/');
        addpath('../');
    
        if ~exist('feawin')
            feawin = 5;
        end
        win = 320;
        shift = 160;    
        fs = 16000;
        first = 0;
        last = 0;
        
        freqscale = load('./utilities/pitch_candidates_freqz.txt');
        
        [X, tx] = feature_pefac(sig, fs, 0.01);   
        
        T = floor(length(sig)/160);
        times_coch = [.5,1:T-1]*.01;
        tmpX = zeros(T, size(X,2));
        for t = 1:T
            [val,index] = min(abs(times_coch(t)-tx));            
            tmpX(t, :) = X(index, :);
        end      
        X = tmpX;
        
        fea = getNeighbor(X,feawin);
        fea = fea([first+1:(size(fea,1)-last)],:);
        allfea = [fea];
    

end


function X = zerofix(X)

    sumx=(sum(X,2));
    idx = find(sumx<=0);
    if isempty(idx)
        return;
    else
        sumx(idx) = 10e6;
        [dum midx] = min(sumx);
        dummy = repmat(X(midx,:),length(idx),1);
        X(idx,:) = dummy;
    end
end
function [allfea] = gen_praatfea(sig)

        addpath('../utilities/');
        addpath('../cochleagram_toolbox/');    
        addpath('../');

        win = 320;
        shift = 160;    
        fs = 16000;

        freqscale = load('./utilities/pitch_candidates_freqz.txt');


        [f0,junk,times] = praat_pd(sig,fs,0,shift/fs,80,500);            
        T = floor(length(sig)/shift);
        times_coch = [.5,1:T-1]*(shift/fs);
        gt_lag = zeros(1,T);
        fpt = zeros(1,T);
        outpt = zeros(T, 68);
        for t = 1:T
            [val,index] = min(abs(times_coch(t)-times));
            if f0(index)>0
                gt_lag(t) = fs/f0(index);
                fpt(t) = f0(index);
            end
        end        

        [gt_lag] = freq2pitchix(fpt, freqscale');

        for t=1:T
            outpt(t, gt_lag(t)+1) = 1;
        end
        allfea = outpt;

end


function X = zerofix(X)

    sumx=(sum(X,2));
    idx = find(sumx<=0);
    if isempty(idx)
        return;
    else
        sumx(idx) = 10e6;
        [dum midx] = min(sumx);
        dummy = repmat(X(midx,:),length(idx),1);
        X(idx,:) = dummy;
    end
end
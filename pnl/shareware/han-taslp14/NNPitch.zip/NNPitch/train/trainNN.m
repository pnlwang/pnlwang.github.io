function [net] = trainNN(trData, trLabel, cvData, cvLabel, trRange, cvRange, NNType)
% Input: 
%    trData, trLabel: training features and training labels: frames x dim
%    cvData, cvLabel: development set features and labels: frames x dim
%    trRange: a cell structure indicating the row frame index of each
%    utterance in trData or trLabel, e.g., in matrix "trData", if
%        1st utterance features: Row 1 ~ Row 300
%        2nd utterance features: Row 301 ~ Row 550
%        3rd utterance features: Row 551 ~ Row 800
%        ......
%     Then, trRange should be:
%        trRange{1} = [1:300];
%        trRange{2} = [301:550];
%        trRange{3} = [551:800];
%        ......
%     cvRange: similar to trRange, but for cvData / cvLabel
%     NNType: neural network type, set to 'DNN' or 'RNN'
%
% Output:
%    net: trained neural network
%
% Note:
%    To train the neural network, the user has to access a GPU and the
%    Parallel toolbox in Matlab
%
% Publication:
%    Han K. and Wang D.L. (2014):�Neural network based pitch tracking in very noisy speech.�IEEE/ACM Transactions on Audio, Speech, and Language Processing, vol. 22, pp. 2158-2168.�
%

    addpath(genpath('../'));

    ModelFN = 'YOUR_DNN_MODEL_NAME';
        
    if strcmp(NNType, 'DNN')
        
        para.isRBM = isRBM;
        para.hidstruct = hidstruct;

        para.costFunc = 'xentropy';        
        para.thetaType = para.costFunc;
        para.sgdMaxEpoch = 30;
        para.rbmEpoch = 10;
        [pred mse optnet optweights lastact para] = DNNTrainMultiSoftmaxLabelsGPU(trData,trLabel,cvData,cvLabel,para);

        net.optnet = optnet;
        net.optweights = optweights;
        net.para = para;
        net.target_min = 0;
        net.target_range = [0 1];

        save(ModelFN, 'net');
        
    elseif strcmp(NNType, 'RNN')
        if ~iscell(trRange) | ~iscell(cvRange)
            error('trRange / cvRange must be a cell');
        end
        [trData, tr_mu, tr_std] = mean_var_norm(trData);
        trData = buildCell(single(trData), trRange);
        trLabel = buildCell(single(trLabel), trRrange);
        
        [cvData] = mean_var_norm_testing(cvData, tr_mu, tr_std);
        cvData = buildCell(single(cvData), cvRange);
        cvLabel = buildCell(single(cvLabel), cvRange);    
        
        para.outdim = 68;
        para.hidstruct = [256 256]; 
        para.hidrecurr = [0 1]; 
        para.T = 15; 
        para.ada_sgd_scale = 0.008;        
        
        net = RNN_train(trData,trLabel,cvData,cvLabel,para);

        net.tr_mu = tr_mu;
        net.tr_std = tr_std;
        net.para = para;
        net.target_min = 0;
        net.target_range = [0 1];

        save(ModelFN, 'net');        
    end
        
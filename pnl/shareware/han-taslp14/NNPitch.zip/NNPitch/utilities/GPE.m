function dtrt = GPE(grd, est, rt)
% grd: groundtruth pitch frequency
% est: estimated pitch frequency
% rt: usually set to 0.05

    if ~exist('rt')
        rt = 0.2;
    end
    
    count = 0;
    len = 0;
    for i = 1:length(grd)        
        if grd(i) > 0 && est(i) > 0
            if abs(grd(i) - est(i)) < grd(i)*rt
                count = count + 1;
            %elseif abs(grd(i) - 2*est(i)) < grd(i)*rt || abs(grd(i) - 0.5*est(i)) < grd(i)*rt
            %    count = count + 1;
            end
            len = len + 1;
        end
    end

    dtrt = count/len;
    
end
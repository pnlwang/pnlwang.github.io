function  dimcelldata = dimFeature(celldata, feawin)

    if (feawin==0)    
        dim = [1 : 254];
    elseif (feawin==1)
        dim = [1:254 255:508 763:1016];
    elseif (feawin==2)
        dimcelldata = celldata;
        return;
    end

    for i = 1:length(celldata)
        curdata = celldata{i};
        dimdata = curdata(:,dim);
        dimcelldata{i} = dimdata;
    end

end
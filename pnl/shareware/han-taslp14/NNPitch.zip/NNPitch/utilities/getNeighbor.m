function [allData] = getNeighbor(data, window)

    if window == 0
        allData = data;
        return;
    end

    lw = window(1);
    rw = window(end); 
    dummyl = data(1,:);
    dummyr = data(end,:);
    
    preData = [];
    for i = 1:lw
        tmpPreData = data(1:end-i,:);
        tmpPreData = [repmat(dummyl, i, 1); tmpPreData];
        preData = [preData tmpPreData];
    end
    
    postData = [];
    for i = 1:rw
        tmpPostData = data(i+1:end,:);
        tmpPostData = [tmpPostData; repmat(dummyr, i, 1); ];
        postData = [postData tmpPostData];
    end

    allData = [data preData postData];
end
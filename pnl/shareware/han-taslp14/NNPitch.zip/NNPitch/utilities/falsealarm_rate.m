function farate = falsealarm_rate(gtpt, estpt)
% gtpt: groundtruth pitch frequency
% estpt: estimated pitch frequency

    count = 0;
    for i = 1:length(gtpt)
        if gtpt(i) == 0 && estpt(i) ~=0
            count = count + 1;
        end
    end    

    farate = count/length(gtpt);
end
function ce = buildCell(data, range)

    for i= 1 : length(range)
        ce{i} = data(range{i},:);
    end

end
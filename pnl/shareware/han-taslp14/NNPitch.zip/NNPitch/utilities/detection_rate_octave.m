function dtrt = detection_rate_octave(grd, est, rt)

    if ~exist('rt')
        rt = 0.05;
    end
    
    count = 0;
    len = 0;
    for i = 1:length(grd)        
        if grd(i) > 0
            if abs(grd(i) - est(i)) < grd(i)*rt
                count = count + 1;
            elseif abs(grd(i)*2 - est(i)) < (grd(i)*2)*rt
                count = count + 1;
            elseif abs(grd(i)/2 - est(i)) < (grd(i)/2)*rt
                count = count + 1;
            end
            len = len + 1;
        end
    end

    dtrt = count/len;
    
end
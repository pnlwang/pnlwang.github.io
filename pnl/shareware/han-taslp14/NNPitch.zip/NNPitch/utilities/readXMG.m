function data = readXMG(fn)

    fid = fopen(fn);
    flag = 0;
    data = [];
    
    tline = fgetl(fid);
    while ischar(tline)
        
        if length(tline)==1 && (tline-'0') == -36;
            flag = 1;
        end
                   
        tline = fgetl(fid);
        if (feof(fid))
            break;
        end
            
        if flag==1 && ~strcmp(tline,'=')
            try
            data = [data; str2num(tline)];
            catch
                xx=1;
            end
        end
    end

    fclose(fid);    
    
    
    
end
function XX = time_align(X, tx, siglen)

        stepsize = 160;
        steptime = .01;
        
        T = floor(siglen/stepsize);
        times_coch = [.5 , 1:T-1] * steptime;
        tmpX = zeros(T, size(X,2));
        for t = 1:T
            [val,index] = min(abs(times_coch(t)-tx));            
            tmpX(t, :) = X(index, :);
        end      
        XX = tmpX;
end
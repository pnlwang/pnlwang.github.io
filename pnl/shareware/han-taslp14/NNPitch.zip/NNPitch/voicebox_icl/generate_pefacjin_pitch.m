function generate_pefacjin_pitch(gender,noise,snr,lists)


p_opt.fs = 16000;
p_opt.nc = 64;
p_opt.fRange = [50 8000];

path('~/research/tools/voicebox_icl',path);
addpath('~/research/tools/noise_tracker_V1_altered');

p_opt.fs = 16000;
p_opt.nc = 64;
p_opt.fRange = [50 8000];

% mix_path = ['/data/data1/woodrufj/Kuzer/test_data_gmm/',gender,'/Unprocessed/',num2str(snr),filesep,noise];
% if strcmp(noise,'n1')||strcmp(noise,'n2')
%     mix_path = ['/data/data1/woodrufj/Kuzer/test_data_newnoise/',gender,filesep,num2str(snr),filesep,noise];    
% end

mix_path = ['/data/data1/hank/research/Loizou_Bayes/IEEE/Unprocessed_16kHz/',gender,filesep,num2str(snr),filesep,noise];
if strcmp(noise,'n1')||strcmp(noise,'n2')
    mix_path = ['/data/data1/woodrufj/Kuzer/test_data_newnoise/',gender,filesep,num2str(snr),filesep,noise];    
end

my_mix_path = ['/data/data1/hank/research/Loizou_Bayes/IEEE/pitch/',gender,filesep,num2str(snr),filesep,noise];


if nargin < 4
    lists = 1:72;
end

if ~isdir(my_mix_path)
    mkdir(my_mix_path)
end

background_level = .01;

[inv_win inv_log] = inv_filters(p_opt.fs, 0.01);

for l = 1:length(lists)
    
    list = lists(l);
    disp(['List: ',num2str(list)])
    
    utt_range = (list-1)*10 + (1:10);
    
    I = length(utt_range);

    for i = 1:I,
        
        %try
            mix_full_path = [mix_path,filesep,num2str(utt_range(i)),'.wav'];
            
            %ptdatFN = [my_mix_path,filesep,num2str(utt_range(i)),'.offnormpefacpitch'];
            ptdatFN = [my_mix_path,filesep,num2str(utt_range(i)),'.pefacpitch'];
            
            if 1==1%~exist(ptdatFN)            
                % noisy speech
                [y Srate_mix] = wavread(mix_full_path);
                y = resample(y,p_opt.fs,Srate_mix);

                % used with 'alt_scale'
                alpha = sqrt(background_level/mean(y.^2));
                y = y*alpha;
                y = round(y*2^16);
                
                
                
                %[fx, tx, pv, fv] = fxpefac(y, p_opt.fs, 0.01);
                [OT O] = ltass_norm(y, p_opt.fs, 0.01, inv_log, inv_win);
                options.nfft = 8192;
                synsig = syncl_sp(OT,options);
                
                unvoiced = pv<0.5;
                f0 = fx;
                f0(unvoiced) = 0;
                
                T = floor(length(y)/160);
                times_coch = [.5,1:T-1]*.01;
                pt_lag = zeros(1,T);
                for t = 1:T
                    [val,index] = min(abs(times_coch(t)-tx));
                    if f0(index)>0
                        pt_lag(t) = p_opt.fs/f0(index);
                    end
                end  

                dlmwrite(ptdatFN, pt_lag, ' ');
  
            end
            fprintf('%s New Done.\n',ptdatFN);
    end
    
  
    
end
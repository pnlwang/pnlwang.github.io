function [SegLab]=factorizationSeg(Ig,ws,segn,NC)
% Compute segment labels using matrix factorization

% Input:
%     Ig: an N1*N2*bn array containing bn filter responses
%     ws: Integration scale (a ws*ws square window)
%     segn: segment number. 0 for automatically selection
%     NC: 1 for imposing nonnegativity constraint. 0 for no constraint.
% Output: label map of the segmented image
%
%     default parameters:
%     omega = .05; For segment number estimation based on singular values 
%                  need to be tuned if the choice of filters are changed.
%     bb = 11; the number of bins in histograms


[N1,N2,bn]=size(Ig);

bb=11;
omega=.05;

% clear I Ir Ign Ib In
% HImap=zeros(bb,N1,N2,bn,'single');
HImap2=zeros(bn*bb,N1,N2,'single');

for b=1:bn
    Ic=single(Ig(:,:,b));
    mx=max(Ic(:));
    mn=min(Ic(:));
    U=(mx-mn)/bb;
    binc=mn+(1:bb)*U-U/2;


    difc=abs(Ic(1,1)-binc);
    [d,id]=min(difc);
    tmp=zeros(1,bb,'single');
    tmp(id)=1;
    HImap2((bb*b-bb+1):bb*b,1,1)=tmp';

    for j=2:N2
        difc=abs(Ic(1,j)-binc);
        [d,id]=min(difc);
        tmp(id)=tmp(id)+1;
        HImap2((bb*b-bb+1):bb*b,1,j)=tmp';
    end

    for i=2:N1
        difc=abs(Ic(i,1)-binc);
        [d,id]=min(difc);
        HImap2(bb*b-bb+id,i,1)=HImap2(bb*b-bb+id,i-1,1)+1;
        tmp=zeros(1,bb,'single');
        tmp(id)=1;
        for j=2:N2
            difc=abs(Ic(i,j)-binc);
            [d,id]=min(difc);
            tmp(id)=tmp(id)+1;
            HImap2((bb*b-bb+1):bb*b,i,j)=HImap2((bb*b-bb+1):bb*b,i-1,j)+tmp';
        end
    end
end

sh_mx=zeros(bn*bb,N1,N2,'single');

ws=floor(ws/2);
bs=1:bn*bb;
for i=1:N1
    for j=1:N2
        wtl=[max(i-ws,1),max(j-ws,1)];
        wbr=[min(i+ws,N1),min(j+ws,N2)];
        sz=(wbr(1)-wtl(1)+1)*(wbr(2)-wtl(2)+1);
        if wtl(1)==1 && wtl(2)==1
            sh_mx(bs,i,j)=HImap2(bs,wbr(1),wbr(2));
        elseif wtl(1)==1 && wtl(2)~=1
            sh_mx(bs,i,j)=HImap2(bs,wbr(1),wbr(2))-HImap2(bs,wbr(1),wtl(2)-1);
        elseif wtl(1)~=1 && wtl(2)==1
            sh_mx(bs,i,j)=HImap2(bs,wbr(1),wbr(2))-HImap2(bs,wtl(1)-1,wbr(2));
        else
            sh_mx(bs,i,j)=HImap2(bs,wbr(1),wbr(2))+HImap2(bs,wtl(1)-1,wtl(2)-1)...
                -HImap2(bs,wbr(1),wtl(2)-1)-HImap2(bs,wtl(1)-1,wbr(2));
        end
        sh_mx(bs,i,j)=sh_mx(bs,i,j)/sz;
    end
end

Y=reshape(sh_mx,bb*bn,N1*N2);

S=Y*Y';
[v,d]=eig(S);

if segn==0 % estimate the segment number
    k=flipud(sqrt(diag(abs(d)))); % compute singular value
    tmp=0;
    lse=zeros(length(k),1);
    for i=length(k):-1:1;
        tmp=tmp+k(i).^2;
        lse(i)=tmp/N1/N2;
    end
    a=find(lse>omega);
    segn=length(a);
    if segn<=1
        segn=2;
        disp('Warning: Segment number is set to 1. Adjust omega for better results.')
    end
end

dimn=segn;

v1=fliplr(v);
U1=v1(:,1:dimn); 

Y2=Y;
Y1=(Y2'*U1)'; % project features onto the subspace

% Compute edgeness
intreg=zeros(N1,N2);
for i=1+ws:N1-ws
    for j=1+ws:N2-ws
        up=U1'*sh_mx(:,i-ws,j);
        bt=U1'*sh_mx(:,i+ws,j);
        lf=U1'*sh_mx(:,i,j-ws);
        rt=U1'*sh_mx(:,i,j+ws);
        tmp=sqrt(sum((up-bt).^2)+sum((lf-rt).^2));
        if tmp<.8
            intreg(i,j)=1;
        end
    end
end 

idx=find(intreg==1);
len=length(idx);
Mx=Y1(:,idx);

tmplt=zeros(dimn,segn,'single');
L=sum(Mx.^2);
[y rn]=max(L);
tmplt(:,1)=Mx(:,rn); 
n=1; 

seedmap=zeros(N1,N2);
seedmap(idx(rn))=1;

tn=n+1;
CY=repmat(tmplt(:,n),1,len);
ccos=sqrt(sum((Mx-CY).^2));
[m id]=max(ccos);
tmplt(:,tn)=Mx(:,id);
seedmap(idx(id))=1;
    
while tn<segn
    tmp=zeros(tn,len);
    for i=1:tn
        CY=repmat(tmplt(:,i),1,len);
        tmp(i,:)=sqrt(sum((Mx-CY).^2));
    end
    tn=tn+1;
    ccos=min(tmp); 
    [m id]=max(ccos);
    tmplt(:,tn)=Mx(:,id);
    seedmap(idx(id))=1;
end

% Kmeans clustering for representative feature estimation

cenInt=tmplt;
ccos=zeros(segn,len,'single');
flag=1;

while flag==1    
for i=1:segn
    CY=repmat(cenInt(:,i),1,len);
    ccos(i,:)=sqrt(sum((Mx-CY).^2));

end

[M clab]=min(ccos);
NcenInt=zeros(dimn,segn,'single');

for i=1:segn
    tmind=find(clab==i);
    tmp=Mx(:,tmind);
    NcenInt(:,i)=sum(tmp,2)./length(tmind);
end

if NcenInt==cenInt
    flag=0;
else
    cenInt=NcenInt;
end
end

B=(NcenInt'*NcenInt)^(-1)*NcenInt'*Y1;
[m,slab]=max(B);

% Impose nonnegativity constraint
if NC==1
    w0=U1*NcenInt;
    w0(w0<0)=0;
    slab=NNMFSeg(Y,w0);    
end

SegLab=reshape(slab,N1,N2);


    


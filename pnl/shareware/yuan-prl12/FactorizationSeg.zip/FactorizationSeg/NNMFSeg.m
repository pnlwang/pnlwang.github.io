function [slab]=NNMFSeg(Y,w0)
% Segmentation using non-negative matrix factorization (ALS algorithm)

% Input:
%     Y: feature matrix
%     w0: the initial matrix of representative features
% Output: label map of the segmented image

dnorm0 = 1e+5;
[n segn]=size(w0);
[K1 K2]=size(Y);

for i=1:100

    h=max(0,(w0'*w0+eye(segn)*0.1)\(w0'*Y));
    w=max(0,(h*h'+eye(segn)*0.1)\(h*Y'));
    w=w';
 
    d = Y - w*h;
    dnorm = sqrt(sum(sum(d.^2))/(K1*K2));
%     dw = max(max(abs(w-w0) / (eps+max(max(abs(w0))))));
%     dh = max(max(abs(h-h0) / (eps+max(max(abs(h0))))));
%     delta = max(dw,dh);
    
    % Check for convergence
    if i>1
        if abs(dnorm0-dnorm) <= 1e-3
            break;
        end
    end

    w0=w;
    dnorm0=dnorm;
   
end
[m,slab]=max(h);



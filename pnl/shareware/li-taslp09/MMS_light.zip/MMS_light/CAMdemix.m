function [final,result] = CAMdemix(mix,cleanSignals,sampFreq,winL,hopF,th1,th2,midiPitch,refPitch,multiSource,F,soMode)

% [final,result] = CAMdemix(mix,cleanSignals,sampFreq,winL,hopF,theta1,theta2,midiPitch,refPitch,F,soMode)
%
% Matlab code to implement algorithm described in:
% Li Y., Woodruff J., and Wang D.L. (2009): Monaural musical sound 
% separation based on pitch and common amplitude modulation. IEEE 
% Transactions on Audio, Speech, and Language Processing, vol. 17, 
% pp. 1361-1371.
%
%
% Inputs:
%   mix(sample,channel) - time domain mix signal(s)
%   cleanSignals(sample,source_num) - the time domain source signals
%   sampFreq - the sampling frequency of the audio signals
%               (default=44.1kHz)
%   winL - (must be a power of 2, try 1024 if not sure) the window 
%       length used in the STFT stage in samples
%               (default=4096 samples)
%   hopF - (should be an integer between 1 and 4) this controls the hop 
%       size (number of samples between STFT windows) as follows: 
%       hopSize = winLength/(2^hopF)
%               (default=2)
%   th1 - threshold (in Hz) determining when a frequency bin is
%       associated with a harmonic
%               (default=34.5Hz)
%   th2 - threshold (in Hz) determining when to harmonics are labeled as
%       overlapped
%               (default=1.5*(sampFreq/winL))
%   midiPitch - binary variable to determine if "midi" pitches should be
%       created from ground truth pitch tracks
%               (default=off)
%   refPitch - binary variable to turn on/off pitch refinement
%               (default=on)
%   multiSource - binary variable to turn on/off reconstruction of
%       overlapping regions
%               (default=on)
%   F - pitch tracks from multi-pitch tracker (set F = [] if ground truth
%       or MIDI pitches are to be used)
%               (default=[], i.e. ground truth pitch)
%   soMode - binary variable to use either rule-based sequential
%       organization (DP in TASLP paper) or ideal sequential organization (DPI
%       in TASLP paper).  this variable is only used when 'F' is nonempty
%               (default=0)
%   
% Outputs:
%   final(sample,source_num) - the final time domain signals
%   result - 
%            MIX: [215x2048 double]   - the mixture spectrum
%             CS: [215x2048x2 double] - the clean signal(s) spectra
%            ibm: [215x2048x2 logical] - the ideal binary mask for each source
%          trueF: [215x2 double]      - the ground truth pitch tracks of each source (in Hz)
%              F: [215x2 double]      - the pitch track of each source (in Hz)
%          binHM: [215x2048x2 double] - the binary harmonic mask for each source
%       binHMind: {2x1 cell}          - bin indices for binary harmonic mask
%          envTH: {2x1 cell}          - the estimated amplitude envelopes for each harmonic of each signal
%      envTHtrue: {2x1 cell}          - the  true amplitude envelopes for each harmonic of each signal
%        phaseTH: {2x1 cell}          - the predicted phase change for each harmonic of each signal
%     overlapReg: {2x1 cell}          - labels t-h units with overlap as 1, otherwise 0
%       overlapS: {2x1 cell}          - the sources that overlap with t-h units labeled as 1
%        numHarm: [1x2 double]             - the number of harmonics for each source
%           oneS: [215x2048x2 double] - the source spectra after stage 1
%            OUT: [215x2048x2 double] - the final reconstructed spectra
%            SNR: [1x2 double]        - output SNR for reconstructed signals
%
%   John Woodruff
%   9/28/2009


%%%%%%%%%%%%%%%%%%%%%%%%MAIN%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% variable decleration and assignment
if nargin < 3
    sampFreq = 44100;
end
if nargin < 4
    winL = 4096;
end
if nargin < 5
    hopF = 2;
end
if nargin < 6
    th1 = 34.5;
end
if nargin < 7
    th2 = 1.5*(sampFreq/winL);
end
if nargin < 8
    midiPitch = 0;
end
if nargin < 9
    refPitch = 1;
end
if nargin < 10
    multiSource = 1;
end
if nargin < 11
    F = [];
end
if nargin < 12
    soMode = 0;
end

global winLength fs f0 hopFactor numTimes numFreqs numSignals theta1 theta2 result; 
winLength = winL; fs = sampFreq; hopFactor = hopF;
theta1 = th1; theta2 = th2;

% Create time-frequency representations, calculate IBMs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% find total number of source signals
numSignals = size(cleanSignals,2);

% compute DFT of mix signal
MIX = stft(mix,winLength,hopFactor,fs);
CS = stft(cleanSignals,winLength,hopFactor,fs);

% use only half of each spectrum
MIX = MIX(:,2:end/2+1);
CS = CS(:,2:end/2+1,:);

% get the number of time frames and frequency bins in the mix spectrum
[numTimes,numFreqs] = size(MIX);

% store spectra in result
result.MIX = MIX;
result.CS = CS;

% make ibms for each source
if numSignals > 1
    for i=1:numSignals
        ibm(:,:,i) = CS(:,:,i) >= max(CS(:,:,setdiff(1:numSignals,i)),[],3);
        ibmSpec(:,:,i) = ibm(:,:,i).*MIX(:,:,1);
    end
else 
    ibm = ones(size(CS));
end

% store ibms
result.ibm = ibm;

% frequency resolution (in Hz);
f0 = fs/winLength;


% Create pitch tracks and harmonic masks for all sources
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if isempty(F)
    % track the fundamental frequency of each clean signal
    F = pitchEstimation(cleanSignals);
    result.trueF = F;
else
    CF = pitchEstimation(cleanSignals);
    result.trueF = CF;

    if soMode == 0
        % use rule based system
        [F,Fprior] = sequentialOrganization(CF, F);
    elseif soMode == 1
        % use prior knowledge for streaming
        [Frule,F] = sequentialOrganization(CF, F);
    end
    result.origF = F;
end


if midiPitch
    MIDI = round(log2((F+eps)/440)*12 + 69);
    midiF = 440*2.^((MIDI - 69)/12);
    F = midiF.*(F > 0);
    result.origF = F;
end

result.F = F;
display('...F0 estimates done')


% create harmonic masks for each source and get predicted phase change in
% each t-f unit that is 1 in harmonic mask.
makeHM;



% Create 'One-Source' Distribution
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% create reconstructed signal matrices
OUT = zeros(numTimes,numFreqs,numSignals);

for s=1:numSignals
    % add single source t-f units that are on the harmonic tracks
    OUT(:,:,s) = result.binHM(:,:,s).*MIX;
end

% store the spectra after stage 1
result.oneS = OUT;

if refPitch  
    F = refinePitch;
    result.F = F;

    makeHM;

    % create reconstructed signal matrices
    OUT = zeros(numTimes,numFreqs,numSignals);

    for s=1:numSignals
        % add single source t-f units that are on the harmonic tracks
        OUT(:,:,s) = result.binHM(:,:,s).*MIX;
    end

    result.oneS = OUT;
end




% Distribute energy for the 'Multi-source' frames
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% continue to reconstruct source signals for frames with 2 or more sources
if multiSource
    estEnvelopesMIXOPT;
else
    result.OUT = result.oneS;
end
display('...Multi-source frames distributed')



%Create a symmetric spectrum from the 'half-spectrum' used in processing
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    

symmetricSpec = zeros(numTimes,numFreqs*2,numSignals);
for s=1:numSignals
   symmetricSpec(:,:,s) = [zeros(numTimes,1),result.OUT(:,:,s),conj(fliplr(result.OUT(:,1:end-1,s)))];
end

display('...Symmetric spectrum created')


%create time-domain signals from the final spectra and store results
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
final = overlapAdd(symmetricSpec,length(cleanSignals),winLength,hopFactor);
display('...Time-domain signals created')

SNR1 = 10*log10(sum(cleanSignals.^2)./sum((cleanSignals-final).^2));
SNR2 = 10*log10(sum(cleanSignals.^2)./sum((cleanSignals-fliplr(final)).^2));
if sum(SNR2) > sum(SNR1)
    final = fliplr(final);
end

result.SNR = 10*log10(sum(cleanSignals.^2)./sum((cleanSignals-final).^2));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%END MAIN%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ADDITIONAL FUNCTIONS%%%%%%%%%%%%%%%%%%%%%%%%%%


function [F,HNR,amp,steps] = pitchEstimation(signals,mode,HNRthresh)

% [F,HNR,amp,steps] = pitchEstimation(signals,mode,HNRthresh)
%
%
% Inputs:
%   signals - time-domain input signals
%   mode - mode == 1 will apply 'heuristics' to the resulting pitch tracks,
%       while mode == 0 (or any other integer than 1) will not apply the
%       heuristics  (default 0)
%   HNRthresh - when mode == 1 above, this variable the threshold at which
%           pitch information is deemed unreliable (default .9)
%
% Outputs:
%   F - the final pitch tracks
%   HNR - the harmonic-to-noise ratio of each signal
%   amp - the amplitude values at each time step
%   steps - the center in the time (in seconds) of each frame

if nargin < 2
    mode = 0;
end
if nargin < 3
    HNRthresh = .9;
end

global winLength hopFactor fs numTimes; 

% get the number of signals
numSignals = size(signals,2);

% set the time step of the praat_pd function to equal the time step of the
% original STFTs
stepSize = winLength/(2^hopFactor);
timeStep = stepSize/fs;
steps = ((0:numTimes-1)*stepSize + winLength/2)/fs;
% use Bartsch's praat_pd to estimate fundamental frequency,
% harmonics-to-noise ratio and amplitude envelope for each signal
for s=1:numSignals
    [F(:,s),HNR(:,s),time,amp(:,s)] = praat_pd(signals(:,s),fs,0,timeStep);
end

% warp praat estimates to match time indices of FFT processing
numFrames = length(F);
[junk,ind] = min(abs(repmat(steps,[numFrames 1])-repmat(time,[1 numTimes])));
F = F(ind,:); HNR = HNR(ind,:); amp = amp(ind,:);


if mode == 1
    
    % time to look ahead in spurious pitch change elimination
    skipTime = .06;

    for s=1:numSignals
        % change F estimates to 0 when HNR is too low
        F(:,s) = F(:,s).*mod(mod(sign(HNR(:,s) - HNRthresh),3),2);

        % change F estimates to 0 when amp is too low
        lowAmp = max(amp(:,s))*.05;
        F(:,s) = F(:,s).*mod(mod(sign(amp(:,s) - lowAmp),3),2);

        % find the change in frequency between frames
        changeF(:,s) = diff(F(:,s));

        % if the frequency change between frames is too large, check to see if
        % any of the next three frames return to the frequency at t-1.  if so,
        % change the frequency at t to match t-1.  if not, do not adjust
        % frequency estimate
        skip = ceil(skipTime/timeStep);
        for t=2:numTimes
            if abs(changeF(t-1,s)) > F(t-1,s)*.1
                minDiff = min(abs(F(t-1,s) - F(t:min(numTimes,t+skip),s)));
                if minDiff < F(t-1,s)*.1
                    F(t,s) = F(t-1,s);
                end
            end

        end
    end
end


%--------------------------------------------------------------------------
%--------------------------------------------------------------------------

function makeHM

% makeHM(F,mode,width)
%
% Create 'Harmonic Masks' for each signal, and store the predicted phase
% change of each t-f unit that has a corresponding 1 in the harmonic mask
 

global theta1 theta2 numTimes numFreqs numSignals winLength fs f0 w wInd result;


% get the fund. frequency estimates
F = result.F;
MIX = result.MIX;
CS = result.CS;

% calculate bin spacing and center frequency of each bin
cfBins = (1:numFreqs) * f0;  

timeStep = (winLength/(2^2))/fs;

% initialize masks
binHM = zeros(numTimes,numFreqs,numSignals);
binHMind = cell(numSignals,1);
envTH = cell(numSignals,1);
envTHtrue = cell(numSignals,1);
phaseTH = cell(numSignals,1);
overlapReg = cell(numSignals,1);
overlapSources = cell(numSignals,1);

% get the highest harmonic for each source
maxHarm = floor((fs/2)./max(F));

% for each output signal
for s=1:numSignals

    binHMind{s} = zeros(2,numTimes,maxHarm(s));
    envTH{s} = zeros(numTimes,maxHarm(s));
    envTHtrue{s} = zeros(numTimes,maxHarm(s));
    phaseTH{s} = zeros(numTimes,maxHarm(s));
    overlapReg{s} = zeros(numTimes,maxHarm(s));
    overlapSources{s} = cell(numTimes,maxHarm(s));

    for t=1:numTimes
        % get the fundamental estimate for this time frame
        Festimate = F(t,s);

        % if the fundamental frequency estimate is nonzero
        if Festimate > 30

            % create array of harmonic frequencies (integer multiples
            % of F)
            for h=1:maxHarm(s)
                
                % frequency of this harmonic
                harm = Festimate*h;
                
                % estimate sinusoidal parameter of clean signal
                bins = find(harm-theta1 <= cfBins & cfBins <= harm+theta1);
                binInd = [];
                for i=1:length(bins)
                    [junk,binInd(i)] = min(abs(bins(i)*f0 - (wInd+harm)));
                end

                envTHtrue{s}(t,h) = sum(w(binInd)'.*abs(CS(t,bins,s)))/sum(w(binInd).^2);        
                
                obs = 0; FD = zeros(numSignals,1);
                overSources = [];
                % is this harmonic obstructed by other sources?
                for otherS = 1:numSignals
                    if otherS~=s
                        harmFreqs = F(t,otherS)*(1:maxHarm(otherS));
                        [m,ind] = min(abs(harmFreqs - harm));
                        FD(otherS) = harmFreqs(ind) - harm;
                        if m < theta2
                            obs = 1;
                            overSources = [overSources,otherS];
                        end
                    end
                end
                  
                if obs == 0
                    lowerLim = max(FD(FD<0));
                    upperLim = min(FD(FD>0));
                    if isempty(lowerLim)
                        lowerLim = harm - theta1;
                    else
                        lowerLim = harm+max(lowerLim/2,-theta1);
                    end
                    if isempty(upperLim)
                        upperLim = harm + theta1;
                    else
                        upperLim = harm + min(upperLim/2,theta1);
                    end

                    useBins = find(lowerLim <= cfBins & cfBins <= upperLim);
                    binHM(t,useBins,s) = 1;
                    
                    
                    binInd = [];
                    for i=1:length(useBins)
                        [junk,binInd(i)] = min(abs(useBins(i)*f0 - (wInd+harm)));
                    end
                    % estimate sinusoidal parameter of non-overlapped
                    % harmonic
                    envTH{s}(t,h) = sum(w(binInd)'.*abs(MIX(t,useBins)))/sum(w(binInd).^2);        

                
                else
                    useBins = find(harm-theta1 <= cfBins & cfBins <= harm+theta1);
                    overlapReg{s}(t,h) = 1;
                    overlapSources{s}{t,h} = sort(overSources,'ascend');
                end
                    
                binHMind{s}(:,t,h) = [min(useBins) , max(useBins)];
                % predicted phase change for this harmonic based on fundamental
                % frequency
                phaseTH{s}(t,h) = mod(harm*timeStep*2*pi + pi,2*pi) - pi;
                
            end
        end
    end
end

result.binHM = binHM;
result.binHMind = binHMind;
result.envTH = envTH;
result.envTHtrue = envTHtrue;
result.phaseTH = phaseTH;
result.overlapReg = overlapReg;
result.overlapS = overlapSources;
result.numHarm = maxHarm;
display('...Harmonic masks done')


%--------------------------------------------------------------------------
%--------------------------------------------------------------------------

function F = refinePitch

global numTimes winLength hopFactor fs numSignals f0 result;


F = result.F;
binHMind = result.binHMind;
OUT = result.oneS;
hop = (winLength/(2^hopFactor));


for s = 1:numSignals
    
    numHarms = size(binHMind{s},3);

    for t = 1:numTimes

        if F(t,s) > 0

            if t == numTimes | abs(log2((F(t+1,s)+eps)/(F(t,s)+eps))) > .04 & t~=1
                oF = t-1;
            else
                oF = t+1;
            end

            refineF = zeros(numHarms,1);
            enHarm = zeros(numHarms,1);
            for h = 1:numHarms

                % determine if the harmonic is obstructed or not
                bins1 = binHMind{s}(1,t,h):binHMind{s}(2,t,h);
                bins2 = binHMind{s}(1,oF,h):binHMind{s}(2,oF,h);

                useBins = intersect(bins1,bins2);

                if ~isempty(useBins) & sum(sign(abs(OUT(t,useBins,s)))) == length(useBins) & sum(sign(abs(OUT(oF,useBins,s)))) == length(useBins)

                    if oF > t
                        range = t:oF;
                    else
                        range = oF:t;
                    end
                    [enHarm(h),bin] = max(sum(abs(OUT(range,useBins,s))));
                    bin = useBins(bin);
                    phase1 = angle(OUT(range(1),bin,s));
                    phase2 = angle(OUT(range(2),bin,s));
                    x = (1/(2*pi))*(phase1+2*pi*bin*f0*(hop/fs)-phase2);
                    predFMQ = (fs/(2*pi*hop))*((phase2-phase1) + 2*pi*round(x));

                    refineF(h) = predFMQ/h;
                end
            end

            useHarms = find(refineF > 0);
            if ~isempty(useHarms)
                F(t,s) = sum(refineF(useHarms).*enHarm(useHarms))/sum(enHarm(useHarms));
            end
        end

    end
    
        
end

            
%--------------------------------------------------------------------------
%--------------------------------------------------------------------------


function estEnvelopesMIXOPT

% estEnvelopesMIXOPT
% 
% Estimates amplitude for corrupted t-h units and use this to estimate
% amplitude for corrupted t-f units
% 

global numSignals f0 w wInd result;

OUT = result.oneS;
CS = result.CS;
MIX = result.MIX;
envTH = result.envTH;
overlapReg = result.overlapReg;
numHarm = result.numHarm;
binHMind = result.binHMind;
overlapSources = result.overlapS;
F = result.F;
phaseTH = result.phaseTH;
envTHtrue = result.envTHtrue;

harmChooseMode = 0;
for s = 1:numSignals

    disp(['...Estimating energy for source ',num2str(s)]);

    % other possible sources
    pSet = powerSet(num2cell(setdiff(1:numSignals,s)));
    possSets = pSet(2:end);

    fprintf('......Harmonic #:   ');
    for f = 1:numHarm(s)
        fprintf('\b\b%2.0f',f);
        
        % find time frames that are overlapped
        frames = find(overlapReg{s}(:,f));
        
        if ~isempty(frames)
            [region,sources] = createRegions(s,f,frames,F,overlapSources,possSets);
            % now process all regions found
            for i = 1:length(region)
    
                if length(region{i}) > 2
                    
                    data.window = w;
                    data.windowIndices = wInd;
                    data.frames = region{i};

                     % find the other sources that are active here
                    activeSources = sort([s,sources{i}],'ascend');

                    minBin = inf;
                    maxBin = 0;
                    for actS = 1:length(activeSources)
  
                        data.F(:,actS) = F(region{i},activeSources(actS));
                        if activeSources(actS) == s
                            data.harmNum(actS) = f;
                        else
                            data.harmNum(actS) = round(mean((binHMind{s}(1,region{i},f)*f0)./F(region{i},activeSources(actS))'));
                        end

                        data.phaseChange(:,actS) = phaseTH{activeSources(actS)}(region{i}(1:end-1),data.harmNum(actS));
                        data.ampScaleTrue(:,actS) = envTHtrue{activeSources(actS)}(region{i}(2:end),data.harmNum(actS))/(envTHtrue{activeSources(actS)}(region{i}(1),data.harmNum(actS))+eps);

                        minBin = min(minBin,min(binHMind{activeSources(actS)}(1,region{i},data.harmNum(actS))));
                        maxBin = max(maxBin,max(binHMind{activeSources(actS)}(2,region{i},data.harmNum(actS))));
                      
                        % create local energy weighting within this region
                        % for each harmonic
                        enWeight = zeros(numHarm(activeSources(actS)),1);
                        availFrames = zeros(numHarm(activeSources(actS)),1);
                        for hn = 1:numHarm(activeSources(actS))
                            % is the whole region available?
                            if sum(sign(envTH{activeSources(actS)}(region{i},hn))) == length(region{i})
                                enWeight(hn) = mean(envTH{activeSources(actS)}(region{i},hn));
                            else
                                availFrames(hn) = length(find(envTH{activeSources(actS)}(region{i},hn)));
                            end
                        end
                        
                        % choose harmonic with max amplitude
                        if harmChooseMode == 0
                            [maxVal,ind] = max(enWeight);
                        else
                            %available harmonics
                            possHarms = find(enWeight>0);
                            possHarms = setdiff(possHarms,data.harmNum);
                            [junk,ind] = min(abs(data.harmNum(actS) - possHarms));
                            ind = possHarms(ind);
                            maxVal = max(enWeight);
                        end
                        
                        if maxVal ~= 0
                            closeHarm(actS) = ind;
                            envClose = envTH{activeSources(actS)}(region{i},ind);
                        else
                            [maxAvail,ind] = max(availFrames);
                            if maxAvail > 1
                            goodFrames = region{i}(envTH{activeSources(actS)}(region{i},ind)>0);
                            closeHarm(actS) = ind;
                            envClose = interp1(goodFrames,envTH{activeSources(actS)}(goodFrames,ind),region{i},'linear','extrap');
                            else
                                closeHarm(actS) = 0;
                            end
                            %disp('not a single harmonic is totally uncorrupted in this region!');
                        end

                        if closeHarm(actS) ~= 0
                            data.ampScale(:,actS) = envClose(2:end)/envClose(1);
                        end           
                        
                        overlapReg{activeSources(actS)}(region{i},data.harmNum(actS)) = 0;
                    end
                    

                    data.bins = minBin:maxBin;

                    data.CS = CS(region{i},data.bins,activeSources);
                    data.MIX = MIX(region{i},data.bins);

                    if min(closeHarm) > 0
                        estRegion = overlappedEstimation(data, '00');
                        OUT(region{i},data.bins,activeSources) = estRegion;
                    end
                    clear data;
                else
                   % do something with short regions
                end
                
            end
            clear region;
        end
    end
    fprintf('\b\b\b\bDone\n')
end
result.OUT = OUT;

%--------------------------------------------------------------------------
%--------------------------------------------------------------------------


function [region,sources] = createRegions(s,f,frames,F,overlapSources,possSets)

% find continuous time segments
jumps = find([2;diff(frames);2] > 1);

% find places within continuous segments where this source
% changes pitch
if length(frames) > 1 
    newJumps = find(abs(diff(F(frames,s))./(F(frames(1:end-1),s)+eps))>.035);
    jumps = sort(unique([jumps;newJumps+1]),'ascend');
end

% create time regions to operate on
m = 1;
for i=1:length(jumps)-1

    % overlap region at harmonic # f
    possRegion = frames(jumps(i)):frames(jumps(i+1)-1);

    if length(possRegion) > 1

        overSources = zeros(length(possRegion),1);
        % find the other sources that are active in this region
        for t = 1:length(possRegion)
            overSet = overlapSources{s}{possRegion(t),f};
            if isempty(setdiff(overSet,possSets{1}))
                overSources(t) = 1;
            elseif isempty(setdiff(overSet,possSets{2}))
                overSources(t) = 2;
            else
                overSources(t) = 3;
            end
        end

        changeSourceSets = find(diff(overSources))+1;

        if isempty(changeSourceSets)
            otherSources = possSets{overSources(1)};

            % find spots where the interferring sources change pitch

            newJumps2 = [];
            for k=1:length(otherSources)
                newJumps2 = [newJumps2;find(abs(diff(F(possRegion,otherSources(k)))./(F(possRegion(1:end-1),otherSources(k))+eps))>.035)];
            end
            newJumps2 = unique(sort(newJumps2,'ascend'));

            if isempty(newJumps2)
                region{m} = possRegion;
                sources{m} = otherSources;
                m = m + 1;
            else
                newJumps2 = [1;newJumps2+1;length(possRegion)+1];

                % further divide region
                for n = 1:length(newJumps2)-1
                    region{m} = possRegion(newJumps2(n)):possRegion(newJumps2(n+1)-1);
                    sources{m} = otherSources;
                    m = m + 1;
                end
            end
        else
            changeSourceSets = [1;changeSourceSets;length(possRegion)+1];
            for ss = 1:length(changeSourceSets)-1
                subRegion = possRegion(changeSourceSets(ss)):possRegion(changeSourceSets(ss+1)-1);
                otherSources = possSets{overSources(changeSourceSets(ss))};

                newJumps2 = [];
                if length(subRegion) > 1
                    for k=1:length(otherSources)
                        newJumps2 = [newJumps2;find(abs(diff(F(subRegion,otherSources(k)))./(F(subRegion(1:end-1),otherSources(k))+eps))>.035)];
                    end
                    newJumps2 = unique(sort(newJumps2,'ascend'));
                end

                if isempty(newJumps2)
                    region{m} = subRegion;
                    sources{m} = otherSources;
                    m = m + 1;
                else
                    newJumps2 = [1;newJumps2+1;length(subRegion)+1];

                    % further divide region
                    for n = 1:length(newJumps2)-1
                        region{m} = subRegion(newJumps2(n)):subRegion(newJumps2(n+1)-1);
                        sources{m} = otherSources;
                        m = m + 1;
                    end
                end
            end
        end
    else
        region{m} = possRegion;
        sources{m} = overlapSources{s}{possRegion(1),f};
        m = m + 1;
    end
end


%--------------------------------------------------------------------------
%--------------------------------------------------------------------------

function estRegion = overlappedEstimation(d, option)

% r: the input data with all the necessary information
% option:
% '00': estimated amplitude scaling and phase change
% '01': estimated amplitude scaling but true phase change for each bin
% '10': true amplitude scaling but estimated phase change
% '11': true amplitude scaling and phase change
% estRegion: estimated spectra of the region

global fs f0 winLength

% % -- please comment out when the function is integrated -- %
% fs = 44100;
% winLength = 4096;
% f0 = fs/winLength;
% numSignals = 2;
% 
% option = '00';
% %r = load('optimizationData.mat');
% % -- end -- %

%d = r.data; % get the input data
timWin = hamming(winLength);

% supply the first frame to simply the loop

numSignals = size(d.ampScale,2);

d.phaseChange = [zeros(1,numSignals); d.phaseChange]; % add 0 as the phase change for the first frame
d.phaseChangeTrue = diff(unwrap(angle(d.CS))); % get the true phase change (for each bin)
d.phaseChangeTrue = cat(1, zeros(1,length(d.bins),numSignals), d.phaseChangeTrue); % add 0 for the first frame
d.ampScale = [ones(1,numSignals); d.ampScale]; % add 1 as the amp change for the first frame
d.ampScaleTrue = [ones(1,numSignals); d.ampScaleTrue]; % add 1 as the true amp change for the first frame

startBin = d.bins(1); % the start bin of the region
endBin = d.bins(end); % the end bin of the region
startFrame = d.frames(1); % the start frame of the region
endFrame = d.frames(end); % the end frame of the region
% use suffix r to avoid possible conflict with global variables
r_numBins = endBin-startBin+1;
r_numFrames = endFrame-startFrame+1;

% construct the coefficient matrix
R = zeros(r_numFrames*r_numBins, numSignals*r_numBins);
for s = 1:numSignals
    for j = 1:r_numBins % bins
        for k = 1:r_numFrames % frames
            BF = f0*d.bins(j); % BF: bin frequency
            HF = d.F(k, s)*d.harmNum(s); % HF: harmonic frequency
            deltaF = HF - BF;
            windowCompensate = ampWindowRatio(timWin, deltaF/fs);
            
            switch option
                case '00' % estimated ampScale, estimated phaseChange, and complex window scaling
                    ampScale = d.ampScale(k,s); % use envelope information
                    phaseCompensate = exp(i*sum(d.phaseChange(1:k,s))); % use phase information
                case '01'
                    ampScale = d.ampScale(k,s); % use envelope information
                    phaseCompensate = exp(i*sum(d.phaseChangeTrue(1:k,j,s))); % use phase information
                case '10'
                    ampScale = d.ampScaleTrue(k,s); % use envelope information
                    phaseCompensate = exp(i*sum(d.phaseChange(1:k,s))); % use phase information
                case '11'
                    ampScale = d.ampScaleTrue(k,s); % use envelope information
                    phaseCompensate = exp(i*sum(d.phaseChangeTrue(1:k,j,s))); % use phase information
            end
                       
            R(k+(j-1)*r_numFrames, s+(j-1)*numSignals) = ampScale*phaseCompensate*windowCompensate;
        end
    end
end

% LS estimation
estInitial = inv(R'*R)*R'*reshape(d.MIX, r_numFrames*r_numBins, 1);

% get the estimation of the each source
for s = 1:numSignals
    tmpR = R;
    % mask the coefficients for source other than s
    for j = 1:size(R, 2)
        if mod(j, numSignals) ~= mod(s, numSignals)
            tmpR(:, j) = 0;
        end
    end
    estRegion(:,:,s) = reshape(tmpR*estInitial, r_numFrames, r_numBins);
end

dummy = 1;


%--------------------------------------------------------------------------
%--------------------------------------------------------------------------

function a = ampWindowRatio(w, deltaF)
% w: window function
% deltaF: difference in frequency
% it calculates W(deltaF)/W(0), W(0) is simply the sum of w.
a = (sum(w.*(exp(-i*2*pi*deltaF*(0:length(w)-1)'))))/sum(w);


%--------------------------------------------------------------------------
%--------------------------------------------------------------------------

function X = stft(in,winLength,hopFactor,fs)

% X = stft(in,winLength,hopFactor,fs)
%
% Input parameters
% --------------------
% in - two channel signal input
%
% fileLength - the length (in samples) of the input signals
%
% winLength - the length of the ifft window
%
% overlap - the amount of overlap used in the stft
%
% fs - the sampling frequency of the audio signals
%
% Output values
% -----------------------
% X(t,f,x) - the complex valued time-frequency frames for x signals
%
% author - John Woodruff, May 25, 2005.

% create window vector for use in specgram

global w wInd; 
win = window('hamming',winLength);

% get magnitude of fft win 
% (sampled every .5 Hz between -250 Hz and 250Hz)
% (theta1 cannot exceed 250 Hz as a result)
x = fft(win,fs*2);
w = [abs(x(end-499:end));abs(x(1:501))];
w = w/max(w);
wInd = -250:.5:250;

% find the correct hop size
hop = (winLength/(2^hopFactor));

[fileLength,numSignals] = size(in);
numsteps = floor(fileLength/hop);

% for each channel, calculate the STFT using specgram.  transpose matrix to
% end up with X(time,frequency,channel).
X = zeros(numsteps,winLength,numSignals);
for x=1:numSignals
    for i=1:numsteps
        winLeft = 1 + ((i-1)* hop);
        winRight = winLeft + winLength  - 1;
        if winRight < fileLength
            signal = in(winLeft:winRight,x);
            signal = signal.*win;
        else
            signal = in(winLeft:fileLength,x);
            signal = signal.*win(1:fileLength-winLeft+1);
        end
        X(i,:,x) = fft(signal,winLength);
    end
end


%--------------------------------------------------------------------------
%--------------------------------------------------------------------------

function out = overlapAdd(X,fileLength,winLength,hopFactor)

% out = overlapAdd(X,fileLength,winLength,hopFactor)
%
% Input parameters
% --------------------
% X - Time-frequency domain representation of signals, X(t,f,s)
%
% fileLength - the length (in samples) of the desired output signals
%
% winLength - the length of the ifft window
%
% hopFactor - the hop size used is winLength/(2^hopFactor)
%
% Output values
% -----------------------
% out - the time-domain output signals
%
% author - John Woodruff, May 17, 2005.


hop = (winLength/(2^hopFactor));

% get the appropriate number of signals, sources, and time-frequency frames
[numTimes,numFreqs,numSources] = size(X);

out = zeros(fileLength,numSources);

win = window('hamming',winLength);

normFactor = zeros(fileLength,1);
for i=1:numTimes
    start = 1+(i-1)*hop;
    stop = min(fileLength,start + winLength - 1);
    normFactor(start:stop) = normFactor(start:stop)+win(1:stop-start+1);
end

for h=1:numSources
    for i=1:numTimes
        winLeft = 1 + ((i-1)*hop);
        winRight = winLeft + winLength - 1;
        outFrame = ifft(X(i,:,h));
        if winRight > fileLength, winRight = fileLength; end;
        out(winLeft:winRight,h) = out(winLeft:winRight,h) + outFrame(1:winRight-winLeft+1)';            
    end
end

out = real(out)./repmat(normFactor+eps,[1 numSources]);


%--------------------------------------------------------------------------
%--------------------------------------------------------------------------

function pSet = powerSet(set)

if isempty(set)
    pSet = {[]};
else
    T = {};
    for i = 1:length(set)
        
        if i == 1
            e = set{i};
        else
            T{i-1} = set{i};
        end
    end
    
    pT = powerSet(T);
    
    for i = 1:length(pT);
        
        pSet{i*2-1} = pT{i};
        pSet{i*2} = [e,pT{i}];
    end
end


%--------------------------------------------------------------------------
%--------------------------------------------------------------------------

function [F,Fprior] = sequentialOrganization(CF, DF)

% first set frames that are all zero in CF to 0
ind = find(sum(CF,2)==0);
DF(ind,:) = 0;
% now set second detected pitch to 0 when one true pitch is 0
ind = find(CF(:,1)==0 | CF(:,2)==0);
DF(ind,2) = 0;

% rule based streaming
F = sort(DF, 2, 'descend');

% minimize sum of pitch errors
nz = CF~=0;
c = sum(abs(CF(nz)-F(nz))./CF(nz));
CF = fliplr(CF);
nz = CF~=0;
c2 = sum(abs(CF(nz)-F(nz))./CF(nz));
if c2 < c;
    F = fliplr(F);
end
CF = fliplr(CF);

Fprior = zeros(size(F));
% prior knowledge of streaming
for i = 1:length(CF)
    if CF(i,1)==0 && CF(i,2)==0
        Fprior(i,:) = DF(i,:);
    elseif CF(i,1)==0
        % just find the closest one to track 2
        [junk,ind] = min(abs(DF(i,:)-CF(i,2))./CF(i,2));
        Fprior(i,2) = DF(i,ind);
        Fprior(i,1) = DF(i,3-ind);
    elseif CF(i,2)==0
        % just find the closest one to track 1
        [junk,ind] = min(abs(DF(i,:)-CF(i,1))./CF(i,1));
        Fprior(i,1) = DF(i,ind);
        Fprior(i,2) = DF(i,3-ind);
    else
        % first find the minimum of all 4 combinations
        x1 = abs(DF(i,1)-CF(i,1))./CF(i,1);
        x2 = abs(DF(i,2)-CF(i,1))./CF(i,1);
        x3 = abs(DF(i,1)-CF(i,2))./CF(i,2);
        x4 = abs(DF(i,2)-CF(i,2))./CF(i,2);
        [junk,ind] = min([x1 x2 x3 x4]);
        if ind==1 || ind==4
            Fprior(i,:) = DF(i,:);
        else 
            Fprior(i,:) = fliplr(DF(i,:));
        end
    end
end
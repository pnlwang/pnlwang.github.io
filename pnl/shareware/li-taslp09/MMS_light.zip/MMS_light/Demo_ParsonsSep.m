function [final,result] = Demo_ParsonsSep(pitchType,filename)

%
% Inputs:
%   pitchType - string specifying type of pitch points to be used
%       true: ground truth pitch points
%       klapuri: previously estimated detected pitch by Klapuri algorithm
%   filename - name of file to be used for output (will be placed in
%       'signals' subdirectory
%
%   John Woodruff
%   9/28/2009


[sig fs] = wavread('signals/input_signals.wav'); % each column of sig is a signal; there might be more than 2 signals
cleanSignals = Adjust_SNR_v3(sig);
mix = sum(cleanSignals, 2);
numSignals = size(cleanSignals, 2);
for j = 1:numSignals
    SNRin(j) = 10*log10(sum(cleanSignals(:,j).^2)/sum((mix-cleanSignals(:,j)).^2));
end
    
winLength = 4096;
hopFactor = 2;


if strcmp(pitchType,'true')
    
    F = [];

elseif strcmp(pitchType,'klapuri');
            
    load('signals/input_pitches');
    F = result.F0s';

    % warp pitch estimates to match time indices of FFT processing
    stepSize = winLength/(2^hopFactor);
    numTimes = floor(length(cleanSignals)/stepSize);
    steps = ((0:numTimes-1)*stepSize + winLength/2)/fs;
    numFrames = length(F);
    [junk,ind] = min(abs(repmat(steps,[numFrames 1])-repmat(result.timeVec',[1 numTimes])));
    F = F(ind,:);
    clear result; 
    
else
    disp('bad pitchType string');
end
   
[final,result] = ParsonsSep(mix,cleanSignals,fs,winLength,hopFactor,F);
    
wavwrite(final,fs,16,['signals/',filename,'.wav']);



function new_sig = Adjust_SNR_v3(sig)
% adjust to be equally strong
snr = 0;
numSource = size(sig, 2); % the number of column is the number of sources
if numSource == 1
    new_sig = sig;
else
    new_sig(:, 1) = sig(:, 1);
    for i = 2:numSource
        org_snr = 10*log10(sum(sig(:, 1).^2)/sum(sig(:, i).^2));
        m = power(10, (org_snr - snr)/20);
        new_sig(:, i) = m*sig(:, i);
    end
end



The code and data in this folder correspond to the paper:

Li Y., Woodruff J., and Wang D.L. (2009): Monaural musical sound separation based on pitch and common amplitude modulation. IEEE Transactions on Audio, Speech, and Language Processing, vol. 17, pp. 1361-1371.

All code included has been tested on Matlab 7 on Linux operating system.



MATLAB CODE:

Demo_CAMdemix.m - example code to run 'CAMdemix' using the input signal and pitch points provided

CAMdemix.m - code to implement the algorithm proposed in above paper.

Demo_ParsonsSep.m - example code to run 'ParsonsSep' using the input signal and pitch points provided

ParsonsSep.m- code to implement the algorithm proposed in Parson's paper: JASA, 1976, Vol.60, No.4

praat_pd.m - code used to generate ground truth pitch points for single source signals


FOLDERS:

signals - folder containing an audio example
	input_signals.wav - two 5-second source signals
	input_pitches.mat - pitch estimates using Klapuri's algorithm
	example_output.wav - estimated source signals using 'CAMdemix' and ground truth pitches
	example_outputParsons.wav - estimated source signals using 'ParsonsSep' and ground truth 		pitches

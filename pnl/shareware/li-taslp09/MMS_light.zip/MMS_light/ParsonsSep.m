function [final,result] = ParsonsSep(mix,cleanSignals,sampFreq,winL,hopF,F)

% [final,result] = ParsonsSep(mix,cleanSignals,sampFreq,winL,hopF,F);
%
% this program implement Parsons' separation system 
% (JASA, 1976, Vol. 60, No. 4)
%
% Inputs:
%   mix(sample,channel) - time domain mix signal(s)
%   cleanSignals(sample,source_num) - the time domain source signals
%   sampFreq - the sampling frequency of the audio signals
%               (default=44.1kHz)
%   winL - (must be a power of 2, try 1024 if not sure) the window 
%       length used in the STFT stage
%               (default=4096 samples)
%   hopF - (should be an integer between 1 and 4) this controls the hop 
%       size (number of samples between STFT windows) as follows: 
%       hopSize = winLength/(2^hopF)
%               (default=2)
%   F - pitch tracks from multi-pitch tracker (set F = [] if ground truth
%       are to be used)
%               (default=[], i.e. ground truth pitch)

% Outputs:
%   final(sample,source_num) - the final time domain signals
%   result - 
%            MIX: [215x2048 double]   - the mixture spectrum
%             CS: [215x2048x2 double] - the clean signal(s) spectra
%            ibm: [215x2048x2 logical] - the ideal binary mask for each source
%          trueF: [215x2 double]      - the ground truth pitch tracks of each source (in Hz)
%              F: [215x2 double]      - the pitch track of each source (in Hz)
%          binHM: [215x2048x2 double] - the binary harmonic mask for each source
%       binHMind: {2x1 cell}          - bin indices for binary harmonic mask
%          envTH: {2x1 cell}          - the estimated amplitude envelopes for each harmonic of each signal
%      envTHtrue: {2x1 cell}          - the  true amplitude envelopes for each harmonic of each signal
%        phaseTH: {2x1 cell}          - the predicted phase change for each harmonic of each signal
%     overlapReg: {2x1 cell}          - labels t-h units with overlap as 1, otherwise 0
%       overlapS: {2x1 cell}          - the sources that overlap with t-h units labeled as 1
%        numHarm: [1x2 double]             - the number of harmonics for each source
%           oneS: [215x2048x2 double] - the source spectra after stage 1
%            OUT: [215x2048x2 double] - the final reconstructed spectra
%            SNR: [1x2 double]        - output SNR for reconstructed signals
%
%   Yipeng Li
%   06/17/2008


%%%%%%%%%%%%%%%%%%%%%%%%MAIN%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% variable decleration and assignment
if nargin < 3
    sampFreq = 44100;
end
if nargin < 4
    winL = 4096;
end
if nargin < 5
    hopF = 2;
end
if nargin < 6
    F = [];
end

global winLength fs f0 hopFactor numTimes numFreqs numSignals result; 
winLength = winL; fs = sampFreq; hopFactor = hopF;

% find total number of source signals
numSignals = size(cleanSignals,2);
lenSignals = size(cleanSignals,1);

% compute DFT of mix signal
MIX = stft(mix,winLength,hopFactor,fs);
CS = stft(cleanSignals,winLength,hopFactor,fs);

% use only half of each spectrum
MIX = MIX(:,2:end/2+1);
CS = CS(:,2:end/2+1,:);

% get the number of time frames and frequency bins in the mix spectrum
[numTimes,numFreqs] = size(MIX);
newSpec1 = zeros(size(MIX));
newSpec2 = zeros(size(MIX));

% store spectra in result
result.MIX = MIX;
result.CS = CS;

% frequency resolution (in Hz);
f0 = fs/winLength;


% Create pitch tracks and harmonic masks for all sources
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if isempty(F)
    % track the fundamental frequency of each clean signal
    F = pitchEstimation(cleanSignals);
    display('...F0 estimates done')
end
result.F = F;


% check if a peak is overlap
% figure;
minBin = 3; % specify the minimum bin distance between peaks
idealWin = abs(fft(hamming(winLength)))'; % row vector
idealWin = [fliplr(idealWin) idealWin(2:end)]; % construct the window spectrum
noSeparation = 0;

for iFrame = 1:numTimes
    oneFrame = abs(MIX(iFrame, :)); % process one frame
    
    % -----
    % find the peaks; get the peaks and their positions
    oneFrameM = oneFrame(2:end-1);
    oneFrameL = oneFrame(1:end-2);
    oneFrameR = oneFrame(3:end);
    tmp = (oneFrameM>oneFrameL).*(oneFrameM>oneFrameR);
    pIndex = find(tmp==1);
    pIndex = pIndex + 1; % the indices of peaks
    
    if isempty(pIndex) % in case no peaks are found, e.g., no signal
        continue;
    else
        % keep going
    end

    % get the first pConsidered strongest peaks. Parsons used all peaks. But for
    % music, most peaks in the high frequency range are not useful
    pConsidered = 70;
    pMag = oneFrame(pIndex); % the magnitude of peaks
    [tmp tmpIndex] = sort(pMag, 'descend');
    
    try
    pCIndex = pIndex(tmpIndex(1:min(length(tmpIndex),pConsidered))); % pCIndex: index of peaks considered
    catch
        dummy = 1;
    end
    pCMag   = oneFrame(pCIndex);
    
    [pCIndex tempIndex] = sort(pCIndex, 'ascend');
    pCMag = pCMag(tempIndex); % the strongest peaks in their order in frequency
    % -----
    
    % check if a peak is non-overlap, overlap, and shared
    numPeaks = length(pCIndex);
    for iPeak = 1:numPeaks-1
        % record the type of peaks. 0: non-overlap;
        % 1: overlap becuase of too close
        % 2: overlap because of asymmetry
        % 3: overlap becuase of not well-behaved phases
        pType(iPeak) = 0; 
        if noSeparation == 1
            continue;
        end
        
        % perform separation
        if pCIndex(iPeak+1)-pCIndex(iPeak) <= minBin % overlap if the distance is less then certain bins
            pType(iPeak) = 1;
        end
        if pType(iPeak) == 2 % check the symmetry
            if iPeak > 1 && pType(iPeak-1) == 0 % if previous peak is not overlapped
                % check two points away from the peak
                p_a1 = oneFrame(pCIndex(iPeak)-1);
                p_b1 = oneFrame(pCIndex(iPeak)+1);
                p_a2 = oneFrame(pCIndex(iPeak)-2);
                p_b2 = oneFrame(pCIndex(iPeak)+2);
                if p_a1>p_b1
                    r1 = p_a1/p_b1;
                    r2 = p_a2/p_b2;
                else
                    r1 = p_b1/p_a1;
                    r2 = p_b2/p_a2;
                end
                if r1 > 1808/942 || r2 > 250.6/4 % These magic numbers are related to the window function, which indicate the maximum deviation possible
                    pType(iPeak) = 2;
                end
            end
        end
        if pType(iPeak) == 2 % check the phase
            if iPeak > 1 && pType(iPeak-1) == 0 % if previous peak is not overlapped
                % 1. get the range
                p.index = pCIndex(iPeak);
                lRange = p.index;
                while lRange > 1 && oneFrame(lRange-1)<oneFrame(lRange) && p.index-lRange<minBin  % lefe valey or minBin
                    lRange = lRange - 1 ;
                end
                rRange = p.index;
                while oneFrame(rRange+1)<oneFrame(rRange) && rRange-p.index<minBin % rihgt valey or minBin
                    rRange = rRange + 1;
                end
                
                % 2. get the phase
                phase = angle(MIX(iFrame, lRange:rRange));
                meanPhaseChange = mean(diff(phase)); % get the average phase change
                phaseChangeRate = abs((diff(phase)-meanPhaseChange)/meanPhaseChange);
                if ~isempty(phaseChangeRate>0.2)
                    pType(iPeak) = 3;
                end
            end
        end
    end
    pType(numPeaks) = 0; % specify that the last one (the weakest one is assumed non-overlapping)
    
    % construct a peak table
    countPeak = 0;
    for iPeak = 1:numPeaks-1
        if pType(iPeak) == 0 % non-overlapped
            countPeak = countPeak + 1;
            PT(countPeak).Frequency = pCIndex(iPeak)*f0;
            PT(countPeak).Index = max(1, pCIndex(iPeak)-minBin):pCIndex(iPeak)+minBin;
            PT(countPeak).Mag = oneFrame(PT(countPeak).Index);
        elseif pType(iPeak) > 0 % overlapped
            if pType(iPeak) == 1
                % do the separation and add peaks into the peak table
                % the peak is overlapped with the one immediately next to
                % it
                % 1. get the range
                p1.index = pCIndex(iPeak); p2.index = pCIndex(iPeak+1);
                p1.mag   = oneFrame(pCIndex(iPeak)); p2.mag = oneFrame(pCIndex(iPeak+1));
                lRange = p1.index;
                while lRange > 1 && oneFrame(lRange-1)<oneFrame(lRange) && p1.index-lRange<minBin  % lefe valey or minBin
                    lRange = lRange - 1 ;
                end
                rRange = p2.index;
                while oneFrame(rRange+1)<oneFrame(rRange) && rRange-p2.index<minBin % rihgt valey or minBin
                    rRange = rRange + 1;
                end
                
                if p1.mag > p2.index
                    firstSpec = p1.mag*idealWin(winLength-(p1.index-lRange):winLength+(rRange-p1.index))/max(idealWin);
                    secondSpec = max(oneFrame(lRange:rRange) - firstSpec, 0); % always positive                   
                else
                    secondSpec = p2.mag*idealWin(winLength-(p2.index-lRange):winLength+(rRange-p2.index))/max(idealWin);
                    firstSpec = max(oneFrame(lRange:rRange) - secondSpec, 0); % always positive
                end
                pType(iPeak+1) = -1; % unmark the next peak as non-overlapped, will not be processed again
                countPeak = countPeak + 1;
                PT(countPeak).Frequency = pCIndex(iPeak)*f0;
                PT(countPeak).Index = lRange:rRange;
                PT(countPeak).Mag = firstSpec;
                countPeak = countPeak + 1;
                PT(countPeak).Frequency = pCIndex(iPeak+1)*f0;
                PT(countPeak).Index = lRange:rRange;
                PT(countPeak).Mag = secondSpec;
            end
            if pType(iPeak) > 1
                p.index = pCIndex(iPeak);
                p.mag = pCMag(iPeak);
                lRange = p.index;
                while lRange > 1 && oneFrame(lRange-1)<oneFrame(lRange) && p.index-lRange<minBin  % lefe valey or minBin
                    lRange = lRange - 1 ;
                end
                rRange = p.index;
                while oneFrame(rRange+1)<oneFrame(rRange) && rRange-p.index<minBin % rihgt valey or minBin
                    rRange = rRange + 1;
                end
                firstSpec = p.mag*idealWin(winLength-(p.index-lRange):winLength+(rRange-p.index))/max(idealWin);
                secondSpec = max(oneFrame(lRange:rRange) - firstSpec, 0); % always positive   
                
                countPeak = countPeak + 1;
                PT(countPeak).Frequency = pCIndex(iPeak)*f0;
                PT(countPeak).Index = lRange:rRange;
                PT(countPeak).Mag = firstSpec;
                countPeak = countPeak + 1;
                PT(countPeak).Frequency = pCIndex(iPeak+1)*f0;
                PT(countPeak).Index = lRange:rRange;
                PT(countPeak).Mag = secondSpec;
            end
        end
    end
      
    % use the pitch to assign peaks and separate overlap peaks
    numHarmonic1 = 0;
    numHarmonic2 = 0;
    numNewPeaks = countPeak;
    for iPeak = 1:numNewPeaks-1
        pFreq = PT(iPeak).Frequency;
        h1 = isHarmonic(pFreq, F(iFrame, 1), f0);
        if h1 > 0 % hth harmonic          
            % construct peak table
            PT1(h1).hbIndex = PT(iPeak).Index; % hbIndex: harmonic bins
            PT1(h1).hbMag = PT(iPeak).Mag;
            hLabel1(h1) = 1; % indicate if a harmonic is filled.
            numHarmonic1 = h1;
        end
        
        h2 = isHarmonic(pFreq, F(iFrame, 2), f0);
        if h2 > 0
            PT2(h2).hbIndex = PT(iPeak).Index; % hbIndex: harmonic bins
            PT2(h2).hbMag = PT(iPeak).Mag;
            hLabel2(h2) = 1; % indicate if a harmonic is filled.
            numHarmonic2 = h2;
        end
        
        if h1 > 0 & h2 > 0 % shared peak
            sharedPeak1(h1) = 1;
            sharedPeak2(h2) = 1;
        end
    end
    sharedPeak1(numHarmonic1+1) = 0;
    sharedPeak2(numHarmonic2+1) = 0;
    
    % process shared peaks
    for iHarmonic = 1:numHarmonic1
        if sharedPeak1(iHarmonic) == 1
            if iHarmonic > 1 && iHarmonic < numHarmonic1 && hLabel1(iHarmonic-1) == 1 && hLabel1(iHarmonic+1) == 1
                mag = max(PT1(iHarmonic).hbMag);
                mag1 = max(PT1(iHarmonic-1).hbMag);
                mag2 = max(PT1(iHarmonic+1).hbMag);
                PT1(iHarmonic).hbMag = PT1(iHarmonic).hbMag./mag(1) * (mag1(1)+mag2(1))/2;
            end
        end
    end
    
    for iHarmonic = 1:numHarmonic2
        if sharedPeak2(iHarmonic) == 1
            if iHarmonic > 1 && iHarmonic < numHarmonic2 && hLabel2(iHarmonic-1) == 1 && hLabel2(iHarmonic+1) == 1
                mag = max(PT2(iHarmonic).hbMag);
                mag1 = max(PT2(iHarmonic-1).hbMag);
                mag2 = max(PT2(iHarmonic+1).hbMag);
                PT2(iHarmonic).hbMag = PT2(iHarmonic).hbMag./mag(1) * (mag1(1)+mag2(1))/2;            
            end
        end
    end
    
    % fill out the spectrogram
    for iHarmonic = 1:numHarmonic1
        if hLabel1(iHarmonic)==1
            tmpIndex = PT1(iHarmonic).hbIndex;
            tmpMag   = PT1(iHarmonic).hbMag;
            if size(tmpMag) ~= size(angle(MIX(iFrame, tmpIndex)))
                dummy = 1;
            end
            newSpec1(iFrame, tmpIndex) = tmpMag.*exp(i*angle(MIX(iFrame, tmpIndex)));
        end
    end
    
    for iHarmonic = 1:numHarmonic2
        if hLabel2(iHarmonic)==1
            tmpIndex = PT2(iHarmonic).hbIndex;
            tmpMag   = PT2(iHarmonic).hbMag;
            newSpec2(iFrame, tmpIndex) = tmpMag.*exp(i*angle(MIX(iFrame, tmpIndex)));
        end
    end
    
    PT1 = [];
    PT2 = [];
    hLabel1 = [];
    hLabel2 = [];
    sharedPeak1 = [];
    sharedPeak2 = [];
    

%     subplot(311); plot(abs(MIX(iFrame, 1:300)));
%     subplot(312); plot(abs(CS(iFrame, 1:300, 1)));
%     subplot(313); plot(abs(newSpec1(iFrame, 1:300)));
%     input(['Press ENTER to continue...: ' num2str(iFrame)]);
end

% resynthesis
symmetricSpec = zeros(numTimes,numFreqs*2,numSignals);
symmetricSpec(:,:,1) = [zeros(numTimes,1),newSpec1,conj(fliplr(newSpec1(:,1:end-1)))];
symmetricSpec(:,:,2) = [zeros(numTimes,1),newSpec2,conj(fliplr(newSpec2(:,1:end-1)))];
    
final = overlapAdd(symmetricSpec,length(cleanSignals),winLength,hopFactor);
display('...Time-domain signals created')

SNR1 = 10*log10(sum(cleanSignals.^2)./sum((cleanSignals-final).^2));
SNR2 = 10*log10(sum(cleanSignals.^2)./sum((cleanSignals-fliplr(final)).^2));
if sum(SNR2) > sum(SNR1)
    final = fliplr(final);
end

result.SNR = 10*log10(sum(cleanSignals.^2)./sum((cleanSignals-final).^2));

    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%END MAIN%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ADDITIONAL FUNCTIONS%%%%%%%%%%%%%%%%%%%%%%%%%%


function [F,HNR,amp,steps] = pitchEstimation(signals,mode,HNRthresh)

% [F,HNR,amp,steps] = pitchEstimation(signals,mode,HNRthresh)
%
%
% Inputs:
%   signals - time-domain input signals
%   mode - mode == 1 will apply 'heuristics' to the resulting pitch tracks,
%       while mode == 0 (or any other integer than 1) will not apply the
%       heuristics  (default 0)
%   HNRthresh - when mode == 1 above, this variable the threshold at which
%           pitch information is deemed unreliable (default .9)
%
% Outputs:
%   F - the final pitch tracks
%   HNR - the harmonic-to-noise ratio of each signal
%   amp - the amplitude values at each time step
%   steps - the center in the time (in seconds) of each frame

if nargin < 2
    mode = 0;
end
if nargin < 3
    HNRthresh = .9;
end

global winLength hopFactor fs numTimes; 

% get the number of signals
numSignals = size(signals,2);

% set the time step of the praat_pd function to equal the time step of the
% original STFTs
stepSize = winLength/(2^hopFactor);
timeStep = stepSize/fs;
steps = ((0:numTimes-1)*stepSize + winLength/2)/fs;
% use Bartsch's praat_pd to estimate fundamental frequency,
% harmonics-to-noise ratio and amplitude envelope for each signal
for s=1:numSignals
    [F(:,s),HNR(:,s),time,amp(:,s)] = praat_pd(signals(:,s),fs,0,timeStep);
end

% warp praat estimates to match time indices of FFT processing
numFrames = length(F);
[junk,ind] = min(abs(repmat(steps,[numFrames 1])-repmat(time,[1 numTimes])));
F = F(ind,:); HNR = HNR(ind,:); amp = amp(ind,:);


if mode == 1
    
    % time to look ahead in spurious pitch change elimination
    skipTime = .06;

    for s=1:numSignals
        % change F estimates to 0 when HNR is too low
        F(:,s) = F(:,s).*mod(mod(sign(HNR(:,s) - HNRthresh),3),2);

        % change F estimates to 0 when amp is too low
        lowAmp = max(amp(:,s))*.05;
        F(:,s) = F(:,s).*mod(mod(sign(amp(:,s) - lowAmp),3),2);

        % find the change in frequency between frames
        changeF(:,s) = diff(F(:,s));

        % if the frequency change between frames is too large, check to see if
        % any of the next three frames return to the frequency at t-1.  if so,
        % change the frequency at t to match t-1.  if not, do not adjust
        % frequency estimate
        skip = ceil(skipTime/timeStep);
        for t=2:numTimes
            if abs(changeF(t-1,s)) > F(t-1,s)*.1
                minDiff = min(abs(F(t-1,s) - F(t:min(numTimes,t+skip),s)));
                if minDiff < F(t-1,s)*.1
                    F(t,s) = F(t-1,s);
                end
            end

        end
    end
end


%--------------------------------------------------------------------------
%--------------------------------------------------------------------------

function X = stft(in,winLength,hopFactor,fs)

% X = stft(in,winLength,hopFactor,fs)
%
% Input parameters
% --------------------
% in - two channel signal input
%
% fileLength - the length (in samples) of the input signals
%
% winLength - the length of the ifft window
%
% overlap - the amount of overlap used in the stft
%
% fs - the sampling frequency of the audio signals
%
% Output values
% -----------------------
% X(t,f,x) - the complex valued time-frequency frames for x signals
%
% author - John Woodruff, May 25, 2005.

% create window vector for use in specgram

global w wInd; 
win = window('hamming',winLength);

% find the correct hop size
hop = (winLength/(2^hopFactor));

[fileLength,numSignals] = size(in);
numsteps = floor(fileLength/hop);

% for each channel, calculate the STFT using specgram.  transpose matrix to
% end up with X(time,frequency,channel).
X = zeros(numsteps,winLength,numSignals);
for x=1:numSignals
    for i=1:numsteps
        winLeft = 1 + ((i-1)* hop);
        winRight = winLeft + winLength  - 1;
        if winRight < fileLength
            signal = in(winLeft:winRight,x);
            signal = signal.*win;
        else
            signal = in(winLeft:fileLength,x);
            signal = signal.*win(1:fileLength-winLeft+1);
        end
        X(i,:,x) = fft(signal,winLength);
    end
end


%--------------------------------------------------------------------------
%--------------------------------------------------------------------------

function out = overlapAdd(X,fileLength,winLength,hopFactor)

% out = overlapAdd(X,fileLength,winLength,hopFactor)
%
% Input parameters
% --------------------
% X - Time-frequency domain representation of signals, X(t,f,s)
%
% fileLength - the length (in samples) of the desired output signals
%
% winLength - the length of the ifft window
%
% hopFactor - the hop size used is winLength/(2^hopFactor)
%
% Output values
% -----------------------
% out - the time-domain output signals
%
% author - John Woodruff, May 17, 2005.


hop = (winLength/(2^hopFactor));

% get the appropriate number of signals, sources, and time-frequency frames
[numTimes,numFreqs,numSources] = size(X);

out = zeros(fileLength,numSources);

win = window('hamming',winLength);

normFactor = zeros(fileLength,1);
for i=1:numTimes
    start = 1+(i-1)*hop;
    stop = min(fileLength,start + winLength - 1);
    normFactor(start:stop) = normFactor(start:stop)+win(1:stop-start+1);
end

for h=1:numSources
    for i=1:numTimes
        winLeft = 1 + ((i-1)*hop);
        winRight = winLeft + winLength - 1;
        outFrame = ifft(X(i,:,h));
        if winRight > fileLength, winRight = fileLength; end;
        out(winLeft:winRight,h) = out(winLeft:winRight,h) + outFrame(1:winRight-winLeft+1)';            
    end
end

out = real(out)./repmat(normFactor+eps,[1 numSources]);

function h = isHarmonic(v, f, f0) % f0: frequency resolution
if f == 0
    h = 0;
else
    for i = 1:50 % check up to 50th harmonic
        b = isWithin(v, i*f-f0, i*f+f0);
        if b == 1
            h = i;
            return;
        end
    end
    h = 0;
end

function b = isWithin(v, b1, b2)
if v >= b1 && v <= b2
    b = 1;
else
    b = 0;
end


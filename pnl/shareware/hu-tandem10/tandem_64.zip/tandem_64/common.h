#ifndef COMMON_H
#define COMMON_H

#define MAX_CHANNEL  128      		        /* maxmimum number of filters */
#define MAX_SCALE	10

#define MAX_FS		(44100)
#define MAX_D		(662)
#define MAX_ACFLEN	(2048)

#define MAX_SIG_LENGTH	(100000)

#endif

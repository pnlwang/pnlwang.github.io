The systems under which the program is tested are:
UNIX: SPARC CPU, Solaris UNIX, gcc 3.0.4
LINUX: Pentium 4, Red Hat 3.2.2, gcc 3.2.3

Modifications made to the windows' version:

1. a macro for min(x,y) is added to the beginning of the filter.c. min() is supported in Microsoft C library but not in Unix C library
2. change the relative paths of several files:
  ..\\data\\important_data\\FIR.dat ==> .//data//important_data//FIR.dat
  ..\\data\\important_data\\gammatone_delay_file ==> .//data//important_data//gammatone_delay_file.txt
  signals\\v3n7 ==> .//signals//v3n7
  data\\pitch1 ==> .//data//pitch1
  data\\pitch2 ==> .//data//pitch2
3. the gammatone group delay for each channel is stored in a binary file that is to be read by the program during run-time. Since the binary file is created on Intel-based machines, it follows the convention of little endian. However, if the program is going to be run in SPARC or other big-endian based machines, the file will not be read correctly. The modified program reads the group delay data from a txt file which does not have this little-big-endian problem. A function was added to make this happen.
4. add a makefile to allow the program to be compiled and linked in unix and linux. 

To run the test file, do:
1. type "make" in the directory containing the source and header files
2. configure the PATH so that the default executable file "multipitch" can be found
3. type "multipitch" to run the program

By Yipeng Li
Perception and Neurodynamics Lab
Department of Computer Science and Engineering
The Ohio State University
2015 Neil Ave.
Columbus, OH 43210-1277, U.S.A.

Email: liyip@cse.ohio-state.edu
Phone: 614-292-7402 (OFFICE);
URL: http://www.cis.ohio-state.edu/~liyip
2005-12-21
function [] = mixSRE( ctl, nT )
% Create a test set with SNRs from -6 dB to 18 dB at a 6 dB step size
% ctl: list of files to be corrupted by noise
% nT: noise type
% Written by Xiaojia Zhao in Sep'10

if strcmp(nT, 'babble')
    noise = 'Noise/babble.wav';
    folderName = 'Babble';
else if strcmp(nT, 'whitenoise')
        noise = 'Noise/whitenoise.wav';
        folderName = 'WN';
    else if strcmp(nT, 'factory')
            noise = 'Noise/factory.wav';
            folderName = 'Factory';
        else if strcmp(nT, 'ssn')
                noise = 'Noise/ssn.wav';
                folderName = 'SSN';
            else
                exit;
            end
        end
    end
end
        
noiseUtter = double(wavread(noise, 'native'));
nLen = length(noiseUtter);
noiseUtter = [noiseUtter; noiseUtter; noiseUtter];

SNR = [-6, 0, 6, 12, 18];


for i = 1 : 5 
    ctlFile = fopen(ctl, 'r');
    snr = SNR(i);
    mainCtlFile = fopen(['CTL/', folderName, '_', int2str(snr), 'dB.txt'], 'w');

    while 1
        line = fgetl(ctlFile);
        if ~ischar(line), break, end
        
        fprintf(1, 'Mixing the source file %s at SNR %d level!\n', line, snr);
        targetSig = dlmread(line);
        
        index = find(line == '/');
        line = line(index(end)+1:end);
        
        mixName = sprintf('/data/data1/zhaox/missData/AllSRE/Test/%s/%ddB/%s', folderName, snr, line);
        if exist([mixName, '.wav'])
            fprintf(mainCtlFile, '%s\n',mixName);
            continue;
        end
        
        tLen = length(targetSig);

        randIdx = randperm(nLen);
        start = randIdx(1);

        noiseSig = noiseUtter(start : start + tLen - 1); 
        
        scale = sqrt( ( sum(targetSig.*targetSig)/sum(noiseSig.*noiseSig) ) / 10^(snr/10) );
        new_snr = 10*log10(sum(targetSig.^2)/sum( (scale.*noiseSig).^2))
        mixture = targetSig + scale .* noiseSig;
        mixture = round(mixture);
        
        signal1 = targetSig;
        signal2 = scale .* noiseSig;
        
        gt = gammatone(signal1);
        gn = gammatone(signal2);

        ct = cochleagram(gt, 160);     
        cn = cochleagram(gn, 160);

        [numChan,numFrame] = size(ct);     

        mask = zeros(numChan, numFrame);

        for p = 1:numChan
            for q = 1:numFrame
                mask(p,q) = ct(p,q) >= cn(p,q);
            end
        end
        
        dlmwrite([mixName, '.ibm'], mask, ' ');
        
        dlmwrite(mixName, mixture);
    	wavwrite( mixture./(max(abs(mixture)) + 1), 8000, 16, [mixName, '.wav'] );
 	
        fprintf(mainCtlFile, '%s\n',mixName);
    end
    fclose(mainCtlFile);
    fclose(ctlFile);
end


end

function sid = getSID_ssn( fileRoot )
% Get the underlying true speaker identity
% fileRoot: path of the mixture
% Written by Xiaojia Zhao in Sep'10

[pathstr,name,ext,versn] = fileparts(fileRoot);
uIdx = findstr(name, '_');
tName = name(1:uIdx(1)-1);

fid = fopen('spkrList');

sid = 0;

% totally there are 330 speakers in the selected NIST dataset

for i = 1 : 330 
    line = fgetl(fid);
    if ~ischar(line), break, end
    if strcmp(line, tName)
        sid = i;
        break;
    end
end

fprintf(1, '\n Target -- %d ', sid);

fclose(fid);

function [ allGMM ] = RmBottom10( allGMM )
% Remove the first 10 chanels of a set of speaker models as the first 10
% channels of GF correspond to a frequency range below 200 Hz
% Written by Xiaojia Zhao in Sep'10

numSpkr = length(allGMM);

if numSpkr == 1
    gmm = allGMM;
    for i = 1:gmm.mixNum
        mixture = gmm.mix{i};
        mixture.mean = mixture.mean(11:end);
        mixture.var = mixture.var(11:end);  
        mixture.vecSize = 54;
        gmm.mix{i} = mixture;
    end
    gmm.vecSize = 54;
    allGMM = gmm;
else

for s = 1: numSpkr
    gmm = allGMM{s};
    
    for i = 1:gmm.mixNum
        mixture = gmm.mix{i};
        mixture.mean = mixture.mean(11:end);
        mixture.var = mixture.var(11:end);  
        mixture.vecSize = 54;
        gmm.mix{i} = mixture;
    end
    gmm.vecSize = 54;
    allGMM{s} = gmm;
    fprintf('\n Removing Bottom 10 channels for Speaker %s, done', gmm.name);
end

end
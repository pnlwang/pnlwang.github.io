function [nMix,mixWt,mean_unnorm,cov_unnorm] = readmodelfile_diagonal(modelfilename)
% Program to read the htk-format speech prior model with diagonal
% covariance. This code assumes there is dropped Gaussians in the EM
% training, otherwise please refer to readPrior.m
% modelfilename: name of the model file
% Written by by Soundararajan Srinivasan in May'05, and adapted by Xiaojia
% Zhao in Sep'10

f=fopen(modelfilename,'r');% open the model definition file
for i=1:3
    dummy=fscanf(f,'%s\n',1);% read and ignore the htk header
end
vecSize=fscanf(f,'%d\n',1);% get the dimension of the data
for i=5:14
    dummy=fscanf(f,'%s\n',1);% read and ignore the htk header
end
nMix=fscanf(f,'%d\n',1);% get the number of mixtures
mean_unnorm = zeros(vecSize,nMix);
cov_unnorm = zeros(vecSize,nMix);
mixWt = zeros(1,nMix);
mixIndex = 0;
while (mixIndex<(nMix))
    dummy=fscanf(f,'%s\n',1);% read and ignore the htk header
    mixIndex = fscanf(f,'%d\n',1);% get the current mixture index
    mixWt(mixIndex) = fscanf(f,'%f\n',1);% get the mixture weight
    dummy=fscanf(f,'%s\n',2);% read and ignore the htk header
    mean_unnorm(:,mixIndex)=(fscanf(f,'%e\n',[vecSize,1]));%get the mean of the current mixture
    dummy=fscanf(f,'%s\n',2);% read and ignore the htk header
    cov_unnorm(:,mixIndex)=((fscanf(f,'%e\n',[vecSize,1])));%get the mean of the current mixture
    dummy=fscanf(f,'%s\n',2);% read and ignore the htk header
end
fclose(f);
fprintf(1, '\n Prior model %s loaded ... %d mixtures', modelfilename, nMix);

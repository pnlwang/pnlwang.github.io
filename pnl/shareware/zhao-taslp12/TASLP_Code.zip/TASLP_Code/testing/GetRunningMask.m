function [ mask ] = GetRunningMask( fileRoot, mlp )
% Generate mask on-the-fly with the selected multi-layer perception (MLP)
% fileRoot: path of the mixture
% mlp: selected mlp
% Written by Xiaojia Zhao in Sep'10

    cmd = ['load ', mlp];
    eval(cmd);

    % load 6-dimensional pitch based features
    fea = load([fileRoot, '.fetEst']);
    feaBev = load([fileRoot, '.evfetEst']);
    
    pitchContour = load([fileRoot, '.pitch']);
    nonPitchRegions = find(pitchContour <= 0);
    nChannel = 64;

    mask = [];
    data = [];   
 
    for chan = 1:nChannel

        new = [fea(:, (chan-1)*3+[1:3]) feaBev(:,(chan-1)*3+[1:3])];  
        new(:,3) = 1./(new(:,3)+1);
        new(:,6) = 1./(new(:,6)+1);
        P = new(:,1:6)';

        Y = sim(rvnet{chan},P);
        data(:, chan) = Y';

        Y = Y > 0;    

        mask(:,chan) = Y';
	
    end

    mask(nonPitchRegions,:) = 0;
    
    mask = mask';
    clear rvnet;
end

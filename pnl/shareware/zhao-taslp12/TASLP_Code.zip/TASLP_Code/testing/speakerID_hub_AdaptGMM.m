function [ spkrID ] = speakerID_hub_AdaptGMM( data, allGMM, ubm, allMasks, LB, LB_UBM, MD_type, varHat )
% Major program to perform speaker recognition without combination strategy
% data: features
% allGMM: a list of speaker models
% ubm: universal background model (UBM)
% allMasks: CASA masks
% LB: precomputed lower bound for allGMM to facilitate bounded marginalization
% LB_UBM: precomputed lower bound for UBM to facilitate bounded marginalization
% MD_Type: label to choose recognition method
% varHat: uncertainty of reconstruction process

% spkrID: output speaker id

% Written by Yang Shao, and adapted by Xiaojia Zhao in Sep'10 

numSpkr = length(allGMM);
numMsk = length(allMasks);
LZERO = -1E+15;


%construct the likelihood table for every speaker
fprintf(1, '\nConstructing likelihood table');
LLTable = zeros(numSpkr, numMsk) + LZERO;

% get log-likelihood and top-scored Gaussian components in the UBM

[LL, gmmIdx] = calGMMLL_hub_AdaptGMM(ubm, data, allMasks{1}, LB_UBM, MD_type, varHat, 0, []);

% for each speaker, get log-likelihood based on the top-scored Gaussian components
for s = 1 : numSpkr

    spkr = allGMM{s};
    lBound = LB{s};
    for seg = 1 : numMsk
        msk = allMasks{seg};
        LL1 = calGMMLL_hub_AdaptGMM(spkr, data, msk, lBound, MD_type, varHat, 1, gmmIdx);
        LLTable(s, seg) = LL1 - LL;
    end 
    fprintf(1, '.');
end 

% print the top 2 speakers on the screen

[sortedLL, I]  = sort(LLTable, 'descend');
fprintf(1, '\nTop 2 scores are %f\t%f. Their Indexes are %d, %d\n', sortedLL(1), sortedLL(2), I(1), I(2));

[ ignore, spkrID ] = max( LLTable(:, 1) );
%if there are more than one masks, more processing here


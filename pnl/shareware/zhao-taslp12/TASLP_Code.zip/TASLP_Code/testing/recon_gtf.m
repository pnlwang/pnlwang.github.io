function [ outData, varHat ] = recon_gtf( data, binMask, nMix,mixWt,mean_unnorm,cov_nn  )
% Reconstruct spectral features (GF) based on a binary CASA mask and a speech
% prior model
% data: input features, usually spectral features, in this paper it is GF
% binMask: binary CASA mask
% nMix: number of mixtures in the speech prior model
% mixWt: weight vector consisting of weights of all the Gaussian components in the
% prior model
% mean_unnorm: a matrix where each column represents the mean vector of a
% Gaussian component in the speech prior model
% cov_nn: a matrix where each column represents the diagonal vector of
% covariance matrix of a Gaussian component in the speech prior model
% Written by by Soundararajan Srinivasan in May'05, and adapted by Xiaojia
% Zhao in Sep'10

    orig = data;
    new = data;
    borig = binMask;
    true_spec_var=ones(size(borig))*1e-20;
    varHat = zeros(size(borig));  % uncertainty of the reconstruction
    
    for frame=1:size(orig,2) % for each frame
        
        b=borig(:,frame); % get the mask
        obs=orig(:,frame); % get the observation
        if(all(b==1))
            new(:,frame)=obs;
        else
            %frame
            DR=0;
            drMtx=zeros(1,nMix);
            missing_value=zeros(size(find(b==0)));
            %check for any reliable data in a frame
            if(any(b>0))
                %obtain the realiable unit GMM likelihoods                
                exp_comp=sum(((obs(find(b==1))*ones(1,nMix)-mean_unnorm(find(b==1),:)).^2)./(cov_nn(find(b==1),:)+realmin),1); 
                drMtx = sqrt((2*pi)^(-length(find(b==1)))).*(1./(prod((sqrt(cov_nn(find(b==1),:))),1)+realmin)).*exp(-0.5*exp_comp);
                drMtx = mixWt.*drMtx;   % -- p(X_r|k) mixture likelihood    
                
                DR=sum(drMtx) +realmin; %sum over mixtures and flooring -- p(X_r)
                
                impute=mean_unnorm(find(b==0),:);  %diagonal, mean is taken as the imputed value  
                missing=obs(find(b==0))*ones(1,nMix); %generate the array of missing values
                impute(find((missing>impute)==0))=missing(find((missing>impute)==0));% if the observed value is less than the imputed value, retain the observed value
                missing_value=(drMtx*impute'/DR)';
                
                true_spec_var(find(b==0),frame)=(drMtx*(cov_nn(find(b==0),:) +(impute-mean_unnorm(find(b==0),:)).^2)'/DR)';                
                true_spec_var(find(b==1),frame)=(drMtx*(((obs(find(b==1))*ones(1,nMix))-mean_unnorm(find(b==1),:)).^2)'/DR)'; %commented on 1/4/2005
               
            else
                
                missing=obs(find(b==0));%generate the array of missing values
                impute=(mean_unnorm(find(b==0),:)*mixWt');
                impute(find((missing>impute)==0))=missing(find((missing>impute)==0));% if the observed value is less than the imputed value, retain the observed value
                missing_value=(impute);% impute the unconditional mean
                true_spec_var(find(b==0),frame)=(cov_nn(find(b==0),:)+(missing_value*ones(1,nMix)-mean_unnorm(find(b==0),:)).^2)*mixWt';  
            end
            
            missing=obs(find(b==0));%generate the array of missing values
            missing_value(find((missing>missing_value)==0))=missing(find((missing>missing_value)==0));% if the observed value is less than the imputed value, retain the observed value
            obs(find(b==0))=missing_value;% impute the missing values
            new(:,frame)=obs;% set this to be the new values
            varHat = true_spec_var;
        end%%%%%%%%%%%%
    end % for frame
    
outData = new;
 

function [snr] = DetectSNR( mixture, Msk )
% Program to estimate input SNR of a mixture based on CASA mask
% mixture: input mixture
% Msk: a CASA mask
% Written by Xiaojia Zhao in Sep'10

fprintf(1, 'Detecting SNR ... \n');

cd ../mixture/
fprintf(1, 'Synthesizing Target Signal ...\n');
sig = synthesis(mixture, Msk);
fprintf(1, 'Synthesizing Noise Signal ...\n');
nMsk = 1 - Msk;
noise = synthesis(mixture, nMsk);

cd ../testing/

% calculate SNR
snr = 10 * log10 ( sum(sig .^2) / sum(noise .^2));

end

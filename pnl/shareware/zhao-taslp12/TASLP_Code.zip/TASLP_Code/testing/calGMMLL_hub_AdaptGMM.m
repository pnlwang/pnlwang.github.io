function [ LL, topIdx ] = calGMMLL_hub( gmm, data, msk, lBound, MD_Type, varHat, bSpkr, gmmIdx )
% Program to calculate speaker reocgnition score based on given speaker
% model and all the frames are recognized in the same way as indicated by
% MD_Type
% gmm: input GMM model, which can be UBM or an individual speaker model
% data: features
% msk: CASA mask
% lBound: precomputed lower bound for the speaker model, and this is to
% faciliate potential bounded marginalization
% MD_Type: label to choose recognition method
% varHat: uncertainty of reconstruction
% bSpkr: label to indicate whether this is recognition for the UBM (0) or
% an individual speaker model (1)
% gmmIdx: this variable contains the indexes of top-scored Gaussian
% components if recognizing an invidual speaker model (bSpkr == 1)

% LL: log-likehood across all the selected frames
% topIdx: indexes of top 5 ranked Gaussian components in the UBM (bSpkr ==
% 0) for each frame

% Written by Yang Shao, and adapted by Xiaojia Zhao in Sep'10

LZERO = -1E+15;
[m, n] = size(data);
if m ~= gmm.vecSize
    fprintf(1, 'Vector size in GMM model does not match input data vector size!!!\n');
    fprintf(1, '%d and %d\n', m, gmm.vecSize);
    return;
end
lwt = log(gmm.weight);

f0 = find(msk.pitch > 0); % find active frames
if length(f0) == 0
    LL = 0;
    return;
end


frmLL = []; 
for tI = 1:length(f0)
    frmNum = f0(tI);

    frame = data(:, frmNum);
    frmMsk = msk.msk(:, frmNum);
    varH = varHat(:, frmNum);
    singleOut = [];
    
    if bSpkr == 1  % recognition on an speaker model
        idx = gmmIdx(:, tI); % indexes of the top-scored Gaussian components are stored in the 'gmmIdx'
        for i = 1:5 % only 5 top scored Gaussian components are chosen for recognition
            singleMixtureOut = calMixtureLL( gmm.mix{idx(i)}, frame, MD_Type, frmMsk, lBound(:, idx(i)), varH );
            singleOut = [singleOut; singleMixtureOut];
        end   
        tmp1 = singleOut + lwt(idx); %adding the log weight
    else % recognition on the UBM
        for i = 1:gmm.mixNum  % all the Gaussian components will be chosen for recognition
            singleMixtureOut = calMixtureLL( gmm.mix{i}, frame, MD_Type, frmMsk, lBound(:, i), varH );
            singleOut = [singleOut; singleMixtureOut];        
        end
        [A, B] = sort(singleOut, 'descend');
        gmmIdx(:, tI) = B(1:5)'; % top 5 Gaussians are recorded
        tmp1 = singleOut(B(1:5)) + lwt(B(1:5)); %adding the log weight
    end
    
    tmp2 = exp(tmp1);       %back to likelihood
    tmp3 = sum(tmp2);       %summation over mixtures
    if tmp3 == 0
        tmp4 = LZERO;
    else
        tmp4 = log(tmp3);       %log likelihood  
    end    
    frmLL = [frmLL, tmp4];
end

topIdx = gmmIdx;
LL = sum(frmLL);


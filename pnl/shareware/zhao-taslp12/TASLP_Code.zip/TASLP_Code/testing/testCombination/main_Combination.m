function main_Combination( ctl_list, mskExt, bFrame)
% Main file for the speaker recognition system combining reconstruction and
% marginalization
% ctl_list: a list of files to be recognized
% mskExt: file extension of a CASA mask
% bFrame: whether using only active frames (0) or all the frames (1)
% Written by Xiaojia Zhao in Sep'10

cd ..

outputFile = 'testCombination/Combination_Results.txt';

fprintf(1, '\n Loading speaker models ...\n');

load MDL/AdaptMDL_GFCC_54.mat;
gfccGMM = allGMM;
load MDL/AdaptMDL_GTF_54.mat;
gtfGMM = allGMM;

fprintf(1, '\n Loading speaker models is done!\n');


fprintf(1, '\n Loading universal background models ...\n');

gfccUBM = loadGMM('MDL/allGMM_gtfcc_bt_prior');
gtfUBM = loadGMM('MDL/allGMM_gtf_prior');
gtfUBM = RmBottom10(gtfUBM);
fprintf(1, '\n Loading UBMs is done!\n');

fprintf(1, '\n Calculating lower bounds of speaker models and UBMs ...\n');

gfccLB = preCptLBound(gfccGMM);
gtfLB = preCptLBound(gtfGMM);

gfcc_ubm_LB = preCptLBound(gfccUBM);
gtf_ubm_LB = preCptLBound(gtfUBM);
fprintf(1, '\n Calculating lower bounds is done!\n');


fprintf(1, '\n Loading speech prior model ...\n');
priorMdlName = 'MDL/allGMM_gtf_54_prior_2048';

% be careful with the HTK-trained prior model as some Gaussian components
% might be dropped by HTK based on some criteria. Here two of them are
% dropped, so we read the remaining 2046 Gaussian components
[nMix, mixWt, mean_unnorm, cov_nn]=readPrior( priorMdlName, 2046 ); 
fprintf(1, '\n Loading speech prior model is done!\n');


%open control file for test utterances
fd = fopen(ctl_list, 'rt');
if fd == -1
    fprintf(1, '\nthe test control file, %s, does not exist', ctl_list);
    return;
end

start = datestr(clock, 0);

uttNum = 0; uttCor = 0;

while 1
    tic;
    fileRoot = fgetl(fd);
    if ~ischar(fileRoot), break, end;
    
    fprintf(1, '\n');
        
    % load gammatone features in HTK format
    inputExt = 'gtf';
    data = loadData(fileRoot, inputExt);
    [dataChnNum dataFrmNum] = size(data);
   
    % read CASA mask
    Msk = dlmread([fileRoot, mskExt]);
    
    % adjust frame number for CASA mask and features
    [chnNum frmNum] = size(Msk); 
    if (frmNum > dataFrmNum)
        fprintf(1, '\nFrame number mismatch between data and binary masks!!! <<');
        frmNum = dataFrmNum;
        Msk = Msk(:, 1:frmNum);
    elseif (frmNum < dataFrmNum)
        fprintf(1, '\nFrame number mismatch between data and binary masks!!! >>');
        data = data(:,2:frmNum+1);
    end

    % exclude firt 10 channels which correspond to frequency range below 200 Hz
    % now the channel number is 54 instead of 64
    data = data(11:end, :);
    Msk = Msk(11:end, :);
    
    % select frames for recognition
    if (bFrame == 0)
        binMask.pitch = sum(Msk) > 0;  % all the active frames
        cnt = sum(Msk);  % get number of reliable T-F units at each frame
        T = median(cnt(cnt > 0)); % get the median number of reliable T-F units among all the active frames
        mType = cnt > (54/2) | cnt > T; % select frames with number of reliable T-F units larger than either half of the channel or the median number
        mType = 1 - mType; 
    else
        binMask.pitch = ones(1, frmNum);  % all the frames
        mType = zeros(1, frmNum);
    end
    
    
    % recontruct gammatone features based on CASA mask and pre-trained speech prior
    fprintf(1, '\n Reconstruction in process ...');
    [outData, varHat] = recon_gtf( data, Msk, nMix, mixWt, mean_unnorm, cov_nn  );
    fprintf(1, ' Done!!!');
    

    % wrap up CASA mask
    binMask.msk = Msk;
    allMasks{1} = binMask;

    
    % transform reconstructed gammatone features into gfcc features
    gtfccData = gtf2gtfcc(outData, 2, 23);
    varHat = var2ccVar(varHat, 2, 23);  % transform uncertainty into ceptral domain, not useful in this combination task
    

    % perform speaker recognition
    [spkrID] = speakerID_hub_AdaptGMM_Comb(data, gtfccData, gtfGMM, gfccGMM, gtfUBM, gfccUBM, allMasks, gtfLB, gfccLB, gtf_ubm_LB, gfcc_ubm_LB, mType, varHat);  % full frame recognition
    fprintf(1, '\nID Results: %d', spkrID);
    
    % get true speaker ID
    trueSID = getSID_ssn(fileRoot);
    fprintf(1, '\t True target -- %d', trueSID);
    
    % result check
    if spkrID == trueSID
        uttCor = uttCor + 1;
    end

    uttNum = uttNum+1;
    tim = toc;
    fprintf(1, '\t\t Used time *** %f ***', tim);
    fprintf(1, '\n Correct  %d,   Accuracy  %f', uttCor, uttCor*100/uttNum);
end

fprintf(1, '\n\nAll utterances processed, %d files in total', uttNum);
fprintf(1, '\n Correct  %d,   Accuracy  %f', uttCor, uttCor*100/uttNum);
fclose(fd);

% write results into log file
tfd = fopen(outputFile, 'a');

fprintf(tfd, '\n\n+++ %s +++', start);

if( bFrame == 0 )
    bt = 'Active Frames are used';
else    
    bt = 'All the frames are used';
end    

fprintf(tfd, '\t%s\t', bt);

fprintf(tfd, '+++ %s +++', datestr(clock, 0));
fprintf(tfd, '\n%s %s, CTL-%s : Acu-%f\n', inputExt, mskExt, ctl_list , uttCor*100/uttNum);
fclose(tfd);


cd testCombination

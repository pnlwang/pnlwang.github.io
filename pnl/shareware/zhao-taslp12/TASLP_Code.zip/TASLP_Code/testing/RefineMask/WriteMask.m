function [] = WriteMask( ctl, mskExt )
% Program to refine mask estimation. It first reads a CASA mask generated
% by universal multi-layer perceptions (MLP), and then uses it to estimate
% input SNR. Finally it chooses closest SNR-specific MLPs to do finer mask
% estimation

cd ..

fid = fopen(ctl);

while 1
    tic;
    fileRoot = fgetl(fid);
    if ~ischar(fileRoot), break, end;
    
    % load mask derived by a universal MLP
    Msk = dlmread([fileRoot, mskExt]);

    mixture = dlmread(fileRoot);
    
    % estimate input SNR
    snr = DetectSNR( mixture, Msk );
    
    % get the closest SNR-specific MLP
    mlp = GetMLP(snr);
    
    % use the selected MLP to refine mask estimation on-the-fly
    Msk  = GetRunningMask( fileRoot, mlp );
    
    dlmwrite([fileRoot, mskExt], Msk);
end

fclose(fid);

cd RefineMask

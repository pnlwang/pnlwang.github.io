function main_MFC( ctl_list )
% Main file for a baseline system using clean 22-dimensional MFCC features
% ctl_list: a list of files to be recognized
% Written by Xiaojia Zhao in Sep'10


cd ..

outputFile = 'testClean/Clean_Results.txt';

%load the speaker models
fprintf(1, '\n Loading speaker models\n');
load MDL/AdaptMDL_MFC.mat;
fprintf(1, '\n Loading speaker models is done!\n');


fprintf(1, '\n Loading universal background models ...\n');
ubm = loadGMM('MDL/allGMM_mfc_prior');
fprintf(1, '\n Loading UBMs is done!\n');

%precompute lower bound for speaker GMMs

fprintf(1, '\n Calculating lower bounds of speaker models and UBMs ...\n');
LB = preCptLBound(allGMM);
LB_UBM = preCptLBound(ubm);
fprintf(1, '\n Calculating lower bounds is done!\n');


%open control file for test utterances
fd = fopen(ctl_list, 'rt');
if fd == -1
    fprintf(1, '\nthe test control file, %s, does not exist', ctl_list);
    return;
end


start = datestr(clock, 0);

uttNum = 0; uttCor = 0;

while 1
    tic;
    fileRoot = fgetl(fd);
    if ~ischar(fileRoot), break, end;
    fprintf(1, '\n');
        
    %load the test data in HTK format
    inputExt = 'mfc';
    data = loadData(fileRoot, inputExt);
    [dataChnNum dataFrmNum] = size(data);
    
    
    Msk = ones([dataChnNum dataFrmNum]);

    binMask.pitch = sum(Msk) > 0;
    binMask.msk = Msk;
    
    allMasks{1} = binMask;
    varHat = zeros(dataChnNum, dataFrmNum);
    
    % perform speaker recognition
    MD_type = 0; % regular log-likelihood calculation    
    [spkrID] = speakerID_hub_AdaptGMM(data, allGMM, ubm, allMasks, LB, LB_UBM, MD_type, varHat);  % full frame recognition
    fprintf(1, '\nID Results: %d', spkrID);
    
    %get true speaker ID
    trueSID = getSID_ssn(fileRoot);
    fprintf(1, '\t True target -- %d', trueSID);
    
    %result check
    if spkrID == trueSID
        uttCor = uttCor + 1;
    end

    uttNum = uttNum+1;
    tim = toc;
    fprintf(1, '\t\t Used time *** %f ***', tim);
    fprintf(1, '\n Correct  %d,   Accuracy  %f', uttCor, uttCor*100/uttNum);
end
fprintf(1, '\n\nAll utterances processed, %d files in total', uttNum);
fprintf(1, '\n Correct  %d,   Accuracy  %f', uttCor, uttCor*100/uttNum);
fclose(fd);


tfd = fopen(outputFile, 'a');

fprintf(tfd, '\n\n+++ %s +++\t', start);
fprintf(tfd, '+++ %s +++', datestr(clock, 0));
fprintf(tfd, '\n%s, CTL-%s : Acu-%f\n', inputExt, ctl_list , uttCor*100/uttNum);
fclose(tfd);

cd testClean

function [ outData ] = var2ccVar( inData, ccST, ccEND )
% Apply DCT on spectral uncertainties to get cepstral uncertainties
% ccST: low cut-off coefficient
% ccEND: high cut-off coefficient
% Written by Yang Shao, and adapted by Xiaojia Zhao in Oct'11

 [chnNum frmNum] = size(inData);

 mtx = dctmtx(chnNum);
 
 for i = 1:frmNum
    frm = inData(:, i);
    mFrm = diag(frm);
    
    mOut = mtx * mFrm * mtx';
    
    out = diag( mOut );
    
    outData(:, i) = out(ccST:ccEND);
 end

    

function [ LB ] = preCptLBound( allGMM )
% Precompute the lower bound to facilitate bounded marginalization, here lower bound is
% set to 0 as features are always postive
% allGMM: GMMs corresponding to a list of speakers
% Written by Yang Shao, and adapted by Xiaojia Zhao in Sep'10

numSpkr = length(allGMM);

if numSpkr == 1
    gmm = allGMM;
    out = [];
    for i = 1:gmm.mixNum
        mixture = gmm.mix{i};
        mus = mixture.mean;
        vars = mixture.var;
        [r c] = size(mus);
        tdata =  zeros(r, c); 
        lbound = normcdf(tdata, mus, sqrt(vars));
        out = [out lbound];
    end
    LB = out;
else

for s = 1: numSpkr
    gmm = allGMM{s};
    out = [];
    for i = 1:gmm.mixNum
        mixture = gmm.mix{i};
        mus = mixture.mean;
        vars = mixture.var;
        [r c] = size(mus);
        tdata =  zeros(r, c); 
        lbound = normcdf(tdata, mus, sqrt(vars));
        out = [out lbound];
    end
    LB{s} = out;
    fprintf('\n Precompute lower bound for Speaker %s, done', gmm.name);
end

end
% tim = toc;
% fprintf('\n Lower bound time for this speaker %d', tim);
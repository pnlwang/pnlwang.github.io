function [spkrID] = speakerID_hub_AdaptGMM_Comb(data, gtfccData, gtfGMM, gfccGMM, gtfUBM, gfccUBM, allMasks, gtfLB, gfccLB, gtf_ubm_LB, gfcc_ubm_LB, mType, varHat)
% Major program to perform speaker recognition with combination strategy
% data: GF features
% gtfccData: GFCC features
% gtfGMM: speaker models trained on GF features
% gfccGMM: speaker models trained on GFCC features
% gtfUBM: universal background model (UBM) on GF features
% gfccUBM: universal background model (UBM) on GFCC features
% allMasks: CASA masks
% gtfLB: precomputed lower bound for GF-based speaker models
% gfccLB: precomputed lower bound for GFCC-based speaker models
% gtf_ubm_LB: precomputed lower bound for GF-based UBM
% gfcc_ubm_LB: precomputed lower bound for GFCC-based UBM
% mType: label vector indicating selected recognition method for each frame
% varHat: uncertainty of reconstruction process

% spkrID: output speaker id

% Written by Yang Shao, and adapted by Xiaojia Zhao in Sep'10

numSpkr = length(gtfGMM);
numMsk = length(allMasks);
LZERO = -1E+15;


fprintf(1, '\nConstructing likelihood table');

% get log-likelihood and top-scored Gaussian components in each UBM

[gfccLL, gfccGmmIdx] = calGMMLL_hub_AdaptGMM(gfccUBM, gtfccData, allMasks{1}, gfcc_ubm_LB, 0, varHat, 0, []);

[gtfLL, gtfGmmIdx] = calGMMLL_hub_AdaptGMM(gtfUBM, data, allMasks{1}, gtf_ubm_LB, 2, varHat, 0, []);

LLTable_Rec = zeros(numSpkr, sum(allMasks{1}.pitch > 0)) + LZERO;

LLTable_Mar = zeros(numSpkr, sum(allMasks{1}.pitch > 0)) + LZERO;

% for each speaker, get log-likelihood based on the top-scored Gaussian components

for s = 1 : numSpkr

    gtfSpkr = gtfGMM{s};
    gfccSpkr = gfccGMM{s};
    
    gtfLBound = gtfLB{s};
    gfccLBound = gfccLB{s};
    
    % in this case, only one CASA mask is passed here
    for seg = 1 : numMsk
        msk = allMasks{seg};

        % recognition for all the active frames based on GFCC features
        newType = mType;
        newType(:) = 0;
        gfccLL = calGMMLL_hub_AdaptGMM_Comb(gtfSpkr, gfccSpkr, data, gtfccData, msk, gtfLBound, gfccLBound, newType, varHat, 1, gtfGmmIdx, gfccGmmIdx);
        
        % recognition for all the active frames based on GF features
        newType = mType;
        newType(:) = 2;
        gtfLL = calGMMLL_hub_AdaptGMM_Comb(gtfSpkr, gfccSpkr, data, gtfccData, msk, gtfLBound, gfccLBound, newType, varHat, 1, gtfGmmIdx, gfccGmmIdx);
        
        LLTable_Rec(s, :) = gfccLL;
        LLTable_Mar(s, :) = gtfLL;
    end 
    fprintf(1, '.');
end


% find all the active frames
idx = find(allMasks{1}.pitch > 0);
mT = mType(idx);

%% Marginalization Score Normalization

marLLTable = sum(LLTable_Mar, 2);
a = max(marLLTable);
b = min(marLLTable);

marSc =  (marLLTable - b) / (a - b);


%% Reconstruction Score Normalization

% pick frames that are selected for reconstruction at the beginning,
% and this information is stored in the vector of 'mType' and 'mT'
if sum(mT == 0) ~= 0
    recLLTable = sum(LLTable_Rec(:, mT == 0), 2);
    a = max(recLLTable);
    b = min(recLLTable);
    recSc = (recLLTable - b) / (a - b);
else
    recSc = zeros(numSpkr, 1);
end

% simple score combination, further improvement can be done here
LLTable = marSc  + recSc;

% print the top 2 speakers on the screen
[sortedLL, I]  = sort(LLTable, 'descend');
fprintf(1, '\nTop 2 scores are %f\t%f. Their Indexes are %d, %d\n', sortedLL(1), sortedLL(2), I(1), I(2));

[ ignore, spkrID ] = max( LLTable(:, 1) );
%if there are more than one masks, more processing here


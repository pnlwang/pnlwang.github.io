function [ frmLL, topIdx ] =  calGMMLL_hub_AdaptGMM_Comb(gtfSpkr, gfccSpkr, data, gtfccData, msk, gtfLBound, gfccLBound, mType, varHat, bSpkr, gtfGmmIdx, gfccGmmIdx)
% Program to calculate speaker reocgnition score based on given speaker
% model and each frame is recognized in its own way indicated in mType
% gtfSpkr: speaker model trained on GF features
% gfccSpkr: speaker model trained on GFCC features
% data: GF features
% gtfccData: GFCC features
% msk: CASA mask
% gtfLBound: precomputed lower bound for gtfSpkr
% gfccLBound: precomputed lower bound for gfccSpkr
% mType: label vector indicating selected recognition method for each frame
% varHat: uncertainty of reconstruction process
% bSpkr: binary label to indicate whether this is recognition for the UBM (0) or
% an individual speaker model (1)
% gtfGmmIdx: indexes of top-scored Gaussian components if recognizing gtfSpkr (bSpkr == 1)
% gfccGmmIdx: indexes of top-scored Gaussian components if recognizing gfccSpkr (bSpkr == 1)

% frmLL: frame level log-likehood
% topIdx: indexes of top 5 ranked Gaussian components in the UBM (bSpkr ==
% 0) for each frame

% Written by Yang Shao, and adapted by Xiaojia Zhao in Sep'10

LZERO = -1E+15;


f0 = find(msk.pitch > 0);
if length(f0) == 0
    frmLL = 0;
    topIdx = [];
    return;
end

frmLL = []; 

for tI = 1:length(f0)
    frmNum = f0(tI);

    MD_Type = mType(frmNum);
    frmMsk = msk.msk(:, frmNum);
    varH = varHat(:, frmNum);

    % figure out recognition method for the current frame
    if MD_Type == 2  % bounded marginaliztion
        frame = data(:, frmNum);
        lBound = gtfLBound;
        gmmIdx = gtfGmmIdx;
        gmm = gtfSpkr; 
    else if MD_Type == 0  % recognition on the GFCC features that are converted from reconstructed GF features
            frame = gtfccData(:, frmNum);
            lBound = gfccLBound;
            gmmIdx = gfccGmmIdx;
            gmm = gfccSpkr;
        else % no speech separation, direct recognition on the noisy features
            frame = gtf2gtfcc(data(:, frmNum), 2, 23);
            lBound = gfccLBound;
            gmmIdx = gfccGmmIdx;
            gmm = gfccSpkr;
            MD_Type = 0;
        end
    end
    
    lwt = log(gmm.weight);
    
    singleOut = [];
    
    if bSpkr == 1 % recognition on an speaker model
        idx = gmmIdx(:, tI);  % indexes of the top-scored Gaussian components are stored in the 'gmmIdx'
        for i = 1 : 5  % only 5 top scored Gaussian components are chosen for recognition
            singleMixtureOut = calMixtureLL( gmm.mix{idx(i)}, frame, MD_Type, frmMsk, lBound(:, idx(i)), varH );
            singleOut = [singleOut; singleMixtureOut];
        end   
        tmp1 = singleOut + lwt(idx); %adding the log weight
    else % recognition on the UBM
        for i = 1:gmm.mixNum % all the Gaussian components will be chosen for recognition
            singleMixtureOut = calMixtureLL( gmm.mix{i}, frame, MD_Type, frmMsk, lBound(:, i), varH );
            singleOut = [singleOut; singleMixtureOut];        
        end
        [A, B] = sort(singleOut, 'descend');
        gmmIdx(:, tI) = B(1:5)'; % top 5 Gaussians are recorded
        tmp1 = singleOut(B(1:5)) + lwt(B(1:5)); %adding the log weight
    end
    
    tmp2 = exp(tmp1);       %back to likelihood
    tmp3 = sum(tmp2);       %summation over mixtures
    if tmp3 == 0
        tmp4 = LZERO;
    else
        tmp4 = log(tmp3);       %log likelihood  
    end
    
    frmLL = [frmLL, tmp4];
end

topIdx = gmmIdx;
% LL = sum(frmLL);


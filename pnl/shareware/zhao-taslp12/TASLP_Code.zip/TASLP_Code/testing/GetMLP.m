function [ mlp ] = GetMLP( snr )
% Get the closest SNR-specific multi-layer perception (MLP) based on
% estimated SNR
% snr: estimated SNR
% mlp: the path of the selected MLP
% Written by Xiaojia Zhao in Sep'10

if snr < -9
    mlp = '/data/data1/zhaox/missData/AllSRE/MaskEstimation/net/net_All_-12_F1T64.mat';
else if snr < -3
        mlp = '/data/data1/zhaox/missData/AllSRE/MaskEstimation/net/net_All_-6_F1T64.mat';
    else if snr < 3
            mlp = '/data/data1/zhaox/missData/AllSRE/MaskEstimation/net/net_All_0_F1T64.mat';
        else if snr < 9
                mlp = '/data/data1/zhaox/missData/AllSRE/MaskEstimation/net/net_All_6_F1T64.mat';
            else if snr < 15
                    mlp = '/data/data1/zhaox/missData/AllSRE/MaskEstimation/net/net_All_12_F1T64.mat';
                else
                    mlp = '/data/data1/zhaox/missData/AllSRE/MaskEstimation/net/net_All_18_F1T64.mat';
                end
            end
        end
    end
end
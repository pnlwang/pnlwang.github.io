function [ubm] = AdaptGMM( ctl, ubm, ubmStats, inputExt )

% Program to do Bayesian adaptation on the universal back ground (UBM) model 
% ctl: a list of training files
% ubm: UBM 
% ubmStats: preprocessed information from UBM
% inputExt: file extension of training files (e.g. 'gtf', 'gfcc')
% Written by Xiaojia Zhao in Sep'10


fid = fopen(ctl);

trainData = [];

while 1
    fileRoot = fgetl(fid);
    if ~ischar(fileRoot)
        break;
    end
    
    [p, n, e] = fileparts(fileRoot);

    % Read training data from a specific location, you should change here to your own location

    data = loadData(['/data/data5/zhaox/missData/ReverbSID/Train/', n], inputExt);
    trainData = [trainData, data];
end

[r, c] = size(trainData);
PosProb = zeros(c, ubm.mixNum);

for i = 1 : 500 : c
    start = i;
    over = min(i + 500 -1, c);
    PosProb(start : over, :) = GetPosterior( ubm, ubmStats, trainData(:, start : over) );
end

clear ubmStats;

Ni = sum(PosProb);

ExpData = (PosProb' * trainData')';

Ni(find(Ni == 0)) = realmin;
ExpData = ExpData ./ (ones(r, 1) * Ni);

fprintf('\nExpectation is calculated !\n');

alpha = Ni ./ (Ni + 8);

for i = 1 : ubm.mixNum
    ubm.mix{i}.mean = alpha(i) * ExpData(:, i) + (1 - alpha(i)) * ubm.mix{i}.mean;
end


    

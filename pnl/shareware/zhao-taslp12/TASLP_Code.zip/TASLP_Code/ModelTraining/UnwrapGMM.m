function [groupMean, groupVar] = UnwrapGMM( gmm, idx )

% Preprocess a GMM, stack all of its means and variances into single matrices
% gmm: GMM
% idx: the index of Gaussian components that will be extracted
% Written by Xiaojia Zhao in Sep'10



groupMean = [];
groupVar = [];

for i = 1 : gmm.mixNum
    if any(i == idx)
        groupMean = [groupMean, gmm.mix{i}.mean];
        groupVar = [groupVar, gmm.mix{i}.var];
    end
end

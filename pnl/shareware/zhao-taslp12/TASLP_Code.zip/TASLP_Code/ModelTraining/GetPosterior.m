function [Pr_x] = GetPosterior( ubm, ubmStats, data )

% Program to get posterior probability of each Gaussian component
% conditioned on the observations
% ubm: UBM
% ubmStats: preprocessed information from the UBM
% data: observations
% Pr_x: posterior probabilities conditioned on the observations
% Written by Xiaojia Zhao in Sep'10


LZERO = -1E+15;
[m, n] = size(data);
if m ~= ubm.vecSize
    fprintf(1, 'Vector size in GMM model does not match input data vector size!!!\n');
    fprintf(1, '%d and %d\n', m, ubm.vecSize);
    out = -1;
    return;
end
lwt = log(ubm.weight');


groupMean = ubmStats.groupMean;
groupVar = ubmStats.groupVar;
groupVar = groupVar + realmin;

clear ubmStats;

data = repmat(data(:), 1, ubm.mixNum);
groupMean = repmat(groupMean, n, 1);
groupVar = repmat(groupVar, n, 1);

t1 = (data - groupMean) .* (data - groupMean) ./ groupVar;
t2 = log( 2*pi*groupVar );
t = t1 + t2; 

tm = t;

singleOut = zeros(n, ubm.mixNum);
for i = 1 : n
    singleOut(i, :) = -0.5 * sum(tm((i-1)*m + 1 : i*m, :)) + lwt;
end

tmp1 = singleOut;

tmp2 = exp(tmp1');
tmp3 = sum(tmp2);
if any(tmp3 == 0)
    tmp3(tmp3 == 0) = realmin;
end

Pr_x = tmp2 ./ repmat(tmp3, ubm.mixNum, 1);

Pr_x = Pr_x';

clear ubm;

%% Old Method
% 
% singleOut = [];
% for i = 1:ubm.mixNum
%     singleMixtureOut = calMixtureLL( ubm.mix{i}, data, 0, [], [], [] );
%     singleOut = [singleOut; singleMixtureOut];        
% end
% 
% tmp1 = singleOut + lwt; %adding the log weight
% 
% tmp2 = exp(tmp1);       %back to likelihood
% tmp3 = sum(tmp2);       %summation over mixtures
% if tmp3 == 0
%     tmp3 = realmin;
%     Pr_x = tmp2 / tmp3;
% else
%     Pr_x = tmp2 / tmp3;
% end

function [ out ] = calMixtureLL(mixture, data, MD_Type, msk, lBound, varH )
% Program to calculate log-likelihood of a single frame given a single Gaussian component
% mixture: a single Gaussian component of a GMM
% data: feature vector of a frame
% MD_Type: label to choose recognition method
% MD_Type : 0 -- regular likelihood
%           1 -- marginalization MD
%           2 -- bounded marginalization MD
%           11 -- regular likelihood, but return a vector frame instead of a single number
%           -1 -- uncertainty decoding for reconstruction

% msk: CASA mask of a frame
% lBound: precomputed lower bound of a frame
% varH: uncertainty of a frame
% Written by Yang Shao, and adapted by Xiaojia Zhao in Sep'10

mus = mixture.mean;
vars = mixture.var;
vars = vars + realmin;


[r c] = size(data);
switch MD_Type
    case {-1, -2}
        vars = vars + varH;   % uncertainty decoding by adding uncertainty to the variance of Gaussian distribution
        t1 = (data - mus) .* (data - mus) ./ vars;
        t2 = log( 2*pi*vars );
        t = t1 + t2;
        tm = t; 
    case {0, -0.1} % regular Gaussian log-likelihood calculation
        t1 = (data - mus) .* (data - mus) ./ vars;
        t2 = log( 2*pi*vars );
        t = t1 + t2;
        tm = t; 
    case 1 % marginalization by zeroing out unreliable T-F units
        t1 = (data - mus) .* (data - mus) ./ vars;
        t2 = log( 2*pi*vars );
        t = t1 + t2;
        tm = t .* msk;        
    case 2 % bounded marginalization from 0 to current feature value, and precomputed lower bound is used to facilitate this process
        % get the no-zero masked units
        t1 = (data - mus) .* (data - mus) ./ vars;
        t2 = log( 2*pi*vars );
        t = t1 + t2; 
        % marginalize the 0 units
        idx = find(msk == 0);
        t(idx) = normcdf( data(idx), mus(idx), sqrt(vars(idx)) ) - lBound(idx);
        tmp = t(idx);
        tmp(find(tmp == 0)) = realmin;
        t(idx) = tmp;
        t(idx) = -2 * log( t(idx) ); %take log for log likelihood, -2 is to counter the constant -0.5 in summary
        tm = t;
    case 11 % regular Gaussian log-likelihood calculation
        t1 = (data - mus) .* (data - mus) ./ vars;
        t2 = log( 2*pi*vars );
        t = t1 + t2;
end

if MD_Type < 10
    out = -0.5 * sum(tm);
else
    out = -0.5 * t;
end

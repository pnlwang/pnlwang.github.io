function [ gmm ] = loadGMM( mdlFileName )
% Load a single GMM from a HTK-format template file
% Written by Yang Shao, and adapted by Xiaojia Zhao in Sep'10

fid = fopen(mdlFileName, 'rt');
if fid == -1
    fprintf(1, 'the GMM file, %s, does not exist', mdlFileName);
    gmm = -1;
    return;
end

%skip the first 3 lines
tline = fgetl(fid); % ~o
tline = fgetl(fid); % <STREAMINFO> 1 9
tline = fgetl(fid); % <VecSize> 9<NULLD><USER>
%gmm.vecSize = sscanf(tline, '<VECSIZE> %d<NULLD><USER><DIAGC>\n');

tmpstr = fscanf(fid, '~h "%s"\n');
gmm.name = strrep(tmpstr, '"', '');
clear tmpstr;

tline = fgetl(fid);
tline = fgetl(fid); %<BeginHMM>
tline = fgetl(fid); %<NumStates> 3
tline = fgetl(fid); %<STATE> 2

tline = fgetl(fid);
gmm.mixNum = sscanf(tline, '<NUMMIXES> %d\n');

gmm.weight = [];
num = 0;
for mixN = 1:gmm.mixNum
        tline = fgetl(fid);

        if length(tline) < 9
            break;
        else if  ~strcmp(tline(1:9), '<MIXTURE>')
                break;
            end
        end
        
        if ischar(tline)
            [ tOut count] = sscanf(tline, '<MIXTURE> %d %f\n');
        else
            tOut = [];
        end
        
        if ~isempty(tOut)
            tMix.weight = tOut(2);
            gmm.weight = [gmm.weight; tMix.weight];
            tline = fgetl(fid);
            tMix.vecSize = sscanf(tline, '<MEAN> %d\n');
            tline = fgetl(fid);
            tMix.mean = sscanf(tline, '%f ', [1 inf]);
            tMix.mean = tMix.mean';
            tline = fgetl(fid);
            %vecSize = sscanf(tline, '<VARIANCE> %d\n');    
            tline = fgetl(fid);
            tMix.var = sscanf(tline, '%f ', [1 inf]);
            tMix.var = tMix.var';
            tline = fgetl(fid); 
            tMix.gConst = sscanf(tline, '<GCONST> %f\n');
            gmm.mix{mixN,1} = tMix;
            clear tMix;
            num = num + 1;
        else
            gmm.weight = [gmm.weight; 0];
            tMix.weight = 0;
            tMix.vecSize = gmm.mix{mixN-1,1}.vecSize;
            tMix.mean = zeros(size(gmm.mix{mixN-1,1}.mean));
            tMix.var = ones(size(gmm.mix{mixN-1,1}.var));
            tMix.gConst = 0;
            gmm.mix{mixN,1} = tMix;
            clear tMix;
        end
end

gmm.vecSize = gmm.mix{1}.vecSize;
if (gmm.mixNum ~= num)
    gmm.mixNum = num;
end

fprintf(1, 'Model %s loaded, %d mixtures.\n', gmm.name, gmm.mixNum);
fclose(fid);


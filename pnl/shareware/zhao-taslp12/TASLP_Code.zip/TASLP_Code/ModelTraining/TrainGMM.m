function TrainGMM ( spkrList, num, output )
% Program to train a list of GMM-based speaker models by adapting a universial
% background model (UBM). This idea is proposed by Reynolds et al. in "Speaker
% verification using adapted Gaussian mixture models". All the speaker
% models are stored in a cell structure and saved in the specificed file
% spkrList: a list of speakers
% num: total number of speakers
% output: ouput file name
% Written by Xiaojia Zhao in Sep'10

fid = fopen(spkrList);
allGMM = cell(1, num);
idx = 0;

ubm = loadGMM(['MDL/MY_UBM']);

[ubmMean, ubmVar] = UnwrapGMM(ubm, [1 : ubm.mixNum]);
ubmStats.groupMean = ubmMean;
ubmStats.groupVar = ubmVar;
ubmStats.vecSize = ubm.vecSize;
ubmStats.mixNum = ubm.mixNum;
ubmStats.weight = ubm.weight;


while 1
    tic;
    spkr = fgetl(fid);
    if ~ischar(spkr)
        break;
    end
    idx = idx + 1;
    
    list = ['CTL/', spkr, '.ctl']; % a list of all the training files that belong to this speaker
    gmm = AdaptGMM(list, ubm, ubmStats, 'gtfcc');  % Bayesian adaptation, a UBM and file extension are needed here

    allGMM{idx} = gmm;
    tim = toc;
    fprintf(1, 'Speaker %s is done!\t\t Used time *** %f ***', spkr, tim);
    save(output, 'allGMM');
end

fclose(fid);

function PitchTracking( ctl, sampFreq )
% Track pitches for a list of files. The sampling frequency has to
% be 16 kHz. Otherwise resampling is applied
% ctl: a list of files to be processed
% sampFreq: sampling frequency, default is 16 kHz
% Written by Xiaojia Zhao in Sep'10

if ~exist(sampFreq, 'var')
    sampFreq = 16000;
end

fid = fopen(ctl);

while 1
    fileRoot = fgetl(fid);

    if ~ischar(fileRoot)
        break;
    end

    if exist([fileRoot, '.pitch'], 'file')
        continue;
    end

    sig = dlmread(fileRoot);
    
    % for 8k sampling frequency, we have to upsample it to 16k and then do pitch tracking
    if sampFreq ~= 16000
        sig = round(resample(sig, 16000, sampFreq));
    end
    
    dlmwrite([fileRoot, '_16k'], sig);
    cmd = ['! java -jar JpitchHP_2pass.jar ', fileRoot, '_16k ', fileRoot, '.pitch1 ', fileRoot, '.pitch2'];
    eval(cmd);

    pitch = load([fileRoot, '.pitch1']);
    pitch = round(pitch / 2);  % scale the estimated pitch back to 8k sampling frequency
    dlmwrite([fileRoot, '.pitch'], pitch, ' ');

    cmd = ['! rm ', fileRoot, '_16k'];
    eval(cmd);
end
fclose(fid);

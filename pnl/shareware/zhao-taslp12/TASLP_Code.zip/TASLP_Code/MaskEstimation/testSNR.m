function testSNR(ctl, T, snr, msk_ext)
% Use SNR-specific multi-layer perceptions (MLP) to estimate voiced mask
% (binary or soft) for a list of files
% ctl: a list of files
% T: threshold to binarize MLP output
% snr: an SNR that we use to choose MLP
% msk_ext: file extension for the estimated mask
% Written by Zhaozhang Jin, and adapted by Xiaojia Zhao in Sep'10

fid = fopen(ctl);

cmd = ['load net/net_All_', snr, '_F1T64.mat'];
eval(cmd);

while 1
    fileRoot = fgetl(fid);
    if ~ischar(fileRoot)
        break;
    end
    [p, n, v] = fileparts(fileRoot);
    
    fprintf(1, '%s\n', fileRoot);
    fea = load([fileRoot, '.fetEst']);
    feaBev = load([fileRoot, '.evfetEst']);
    if size(fea, 2) ~= 64*3 || size(feaBev, 2) ~= 64*3
        fprintf(1, 'Error!\n');
        break;
    end

    
    pitchContour = load([fileRoot, '.pitch']);
    nonPitchRegions = find(pitchContour <= 0);
    nChannel = 64;             

    mask = [];
    data = [];   
 
    for chan = 1:nChannel

        new = [fea(:, (chan-1)*3+[1:3]) feaBev(:,(chan-1)*3+[1:3])];  
        new(:,3) = 1./(new(:,3)+1);
        new(:,6) = 1./(new(:,6)+1);
        P = new(:,1:6)';

        Y = sim(rvnet{chan},P);
        data(:, chan) = Y';

        Y = Y > T;    

        mask(:,chan) = Y';
	
    end

    mask(nonPitchRegions,:) = 0;
    data(nonPitchRegions,:) = 0;
        
    dlmwrite([fileRoot, msk_ext], mask');    % store binary mask
%     dlmwrite([fileRoot, msk_ext], data');    % store the mlp output as soft mask for later use

end


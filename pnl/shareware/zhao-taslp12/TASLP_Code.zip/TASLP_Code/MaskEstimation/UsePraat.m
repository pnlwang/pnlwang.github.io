function UsePraat( ctl, sampFreq ) 
% Get the ground truth pitches of a list of files
% ctl: a list of files
% sampFreq: sampling frequency
% Written by Xiaojia Zhao in Sep'10

if ~exist(sampFreq, 'var')
    sampFreq = 8000;
end

winShift = sampFreq / 100;

fid = fopen(ctl, 'r');

while 1
    fileRoot = fgetl(fid);
    if ~ischar(fileRoot)
        break;
    end
    
    a = wavread([fileRoot, '.wav'])';
    
    frm = floor(length(a) / winShift) - 1;

    fprintf(1, '%s\n', fileRoot);

    [p, n, e] = fileparts(fileRoot);

    % take care of boundary frames

    for i = 1 : winShift
        a = [0, 0, a, 0, 0, 0, 0];
    end

    % output from praat is in Hz
    [f, auto, t, amp] = praat_pd(a, sampFreq, 0, 0.01, 80, 500);
    
    % convert Hz into number of samples
    f(f~=0) = sampFreq ./ f(f~=0);
    
    f = round(f(1:frm));

    dlmwrite(['/data/data1/zhaox/missData/AllSRE/MaskEstimation/Data/Pitch/', n, '.pitch'], f', ' ');

end

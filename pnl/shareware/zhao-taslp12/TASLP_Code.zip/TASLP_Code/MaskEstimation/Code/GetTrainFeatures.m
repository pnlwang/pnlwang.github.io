function GetTrainFeatures ( ctl, nT, snr )
% Generate 6-dimensional pitch-based features for the training set of mask
% estimation. Details of this 6-d features can be referred to Jin and Wang
% (2009): "A supervised learning approach to monaural segregation of
% reverberant speech" at
% http://www.cse.ohio-state.edu/~dwang/papers/Jin-Wang.taslp09.pdf
% ctl: a list of files
% nT: noise type, totally there are four types of noises incorporated in the
% training set of mask estimation
% snr: input SNR of the list of files, this is only used to locate the files,
% not used for mask estimation.



N = 50; % there are 50 utterances for mask estimation

if strcmp(nT, 'babble')
    folderName = 'Babble';
else if strcmp(nT, 'whitenoise')
        folderName = 'WN';
    else if strcmp(nT, 'factory')
            folderName = 'Factory';
        else if strcmp(nT, 'ssn')
                folderName = 'SSN';
            else
                exit;
            end
        end
    end
end

fid = fopen(ctl);

for j = 1 : N
    fileRoot = fgetl(fid);
    [p, n, v] = fileparts(fileRoot);    
    
    mixName = ['/u/zhaox/missData/AllSRE/MaskEstimation/Data/', folderName, '/', int2str(snr), 'dB/', n];
    pitch = ['/u/zhaox/missData/AllSRE/MaskEstimation/Data/Pitch/', n];
    
    cmd = ['!java GetFeatures ', mixName, ' ', pitch, '.pitch 64 ', mixName, '.fet'];  % get normalized correlogram
    eval(cmd);

    cmd = ['!java GetBandEvFeatures ', mixName, ' ', pitch, '.pitch 64 ', mixName, '.evfet']; % get normalized envelope based correlogram
    eval(cmd);

end

fclose(fid);

import java.io.*;
import java.util.*;

public class GetFeatures {

  public static void main(String args[]) {

    if (args.length != 4) {
      System.out.println("Usage: java GetFeatures inputSig pitch nChan featureOut");
      System.exit(0);
    }

    try {
      BufferedReader r = new BufferedReader(new FileReader(args[0]));

      int numSample = 0;
      String t = r.readLine();
      while (t != null) {
        numSample++;
        t = r.readLine();
      }
      System.out.println(numSample + " samples read.");
      r.close();

      int[] sig = new int[numSample];
      r = new BufferedReader(new FileReader(args[0]));
      for (int i = 0; i < numSample; i++){
        sig[i] = Integer.parseInt(r.readLine());}
      r.close();

      int nChan = Integer.parseInt(args[2]);
      Gammatone gt = new Gammatone(16000,nChan); //constructor overrided for different sF and numChannel
      float[][] hc = gt.Filter(sig);
      FrontEnd fe = new FrontEnd(hc, gt);
      fe.GuoNingFront();

      Correlogram corr = new Correlogram(fe);
      corr.GetCorrelogramN(fe.r);

      System.out.println("Reading pitch...");
      int[] pitch;
      r = new BufferedReader(new FileReader(args[1]));
      t = r.readLine();
      StringTokenizer token = new StringTokenizer(t, " ");
      pitch = new int[corr.numFrame];
      int cursor = 0;
      //while (token.hasMoreElements()) {
      while (cursor < corr.numFrame) {
        pitch[cursor] = Integer.parseInt( (String) token.nextElement());
        if (pitch[cursor] >= 200) //12.5ms max delay
          pitch[cursor] = 199;
        cursor++;
      }
      System.out.println(pitch.length);
      r.close();

      Features f = new Features(corr.acl, pitch);

      FileWriter w = new FileWriter(args[3]);
      for (int tf = 0; tf < corr.numFrame; tf++) {
        for (int chan = 0; chan < nChan; chan++)
          for (int i = 0; i < 3; i++)
            w.write(f.feature[chan][tf][i] + " ");
        w.write("\n");
      }
      w.flush();
      w.close();

      /*FileWriter ww = new FileWriter("acl", false);
      for (int tf = 0; tf < corr.numFrame; tf++) {
        for (int i = 0; i < 200; i++)
          ww.write(corr.acl[30][tf][i] + " ");
        ww.write("\n");
      }
      ww.flush();
      ww.close();*/


    }
    catch (IOException e) {
      e.printStackTrace();
    }

  }
}

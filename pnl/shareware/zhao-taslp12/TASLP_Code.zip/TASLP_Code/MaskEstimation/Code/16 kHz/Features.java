import java.io.*;
import java.util.*;

public class Features {

  private float[][][] ac;
  private int minDelay, maxDelay;
  public int numChannel, numFrame;
  public float[][][] feature;

  Features(float[][][] acIn) {
    numChannel = acIn.length;
    numFrame = acIn[0].length;
    minDelay = 32;
    maxDelay = 200;
    ac = acIn;
    GetFeatures();
  }

  Features(float[][][] acIn, int[] pitch) {
    numChannel = acIn.length;
    numFrame = acIn[0].length;
    minDelay = 32;
    maxDelay = 200;
    ac = acIn;
    GetFeatures(pitch);
  }

  private void GetFeatures(){
    int[] delay;
    feature = new float[numChannel][numFrame][3*6];
    System.out.print("Getting features...");
    for (int chan = 0; chan<numChannel; chan++){
      System.out.print(Math.round( (float) chan / numChannel * 100) + "%");
      for (int tf = 0; tf < numFrame; tf++) {
        delay = getPeaks(ac[chan][tf]);
        for (int i = 0; i<6; i++){
          if (delay[i] > 0) {
            if (ac[chan][tf][i * 3 + 0] == 0)
              feature[chan][tf][i * 3 + 0] = 0;
            else
              feature[chan][tf][i * 3 +
                  0] = ac[chan][tf][delay[i]] / ac[chan][tf][0];
            if (ZCR(ac[chan][tf]) == 1e-10f) {
              feature[chan][tf][i * 3 + 1] = 0.5f;
              feature[chan][tf][i * 3 + 2] = 0f;
            }
            else {
              feature[chan][tf][i * 3 +
                  1] = (delay[i] + 1) / ZCR(ac[chan][tf]) / 2;
              feature[chan][tf][i * 3 +
                  2] = Math.round(feature[chan][tf][i * 3 + 1]);
              feature[chan][tf][i * 3 +
                  1] = Math.abs(feature[chan][tf][i * 3 + 2] -
                                feature[chan][tf][i * 3 + 1]);
            }
          }
        }
      }
      if (Math.round( (float) chan / numChannel * 100) < 10)
        System.out.print("\b\b");
      else
        System.out.print("\b\b\b");
    }
    System.out.println("Done");
  }

  private void GetFeatures(int[] pitch) {
    feature = new float[numChannel][numFrame][3];
    System.out.print("Getting features...");
    for (int chan = 0; chan < numChannel; chan++) {
      System.out.print(Math.round( (float) chan / numChannel * 100) + "%");
      for (int tf = 0; tf < numFrame; tf++) {
        if (pitch[tf] > 0) {
          if (ac[chan][tf][0] == 0)
            feature[chan][tf][0] = 0;
          else
            feature[chan][tf][0] = ac[chan][tf][pitch[tf]] / ac[chan][tf][0];
          if (ZCR(ac[chan][tf]) == 1e-10f) {
            feature[chan][tf][1] = 0.5f;
            feature[chan][tf][2] = 0f;
          }
          else {
            feature[chan][tf][1] = (pitch[tf] + 1) / ZCR(ac[chan][tf]) / 2;
            feature[chan][tf][2] = Math.round(feature[chan][tf][1]);
            feature[chan][tf][1] = Math.abs(feature[chan][tf][2] -
                              feature[chan][tf][1]);
          }

        }
      }
      if (Math.round( (float) chan / numChannel * 100) < 10)
        System.out.print("\b\b");
      else
        System.out.print("\b\b\b");
    }
    System.out.println("Done");
  }

  private int[] getPeaks(float[] in){
    int[] peaks = new int[6];
    int index = 0;
    for (int delay = 1; delay < maxDelay-1; delay++)
      if (in[delay] > in[delay - 1] && in[delay] > in[delay + 1] && index <6) {
        peaks[index] = delay;
        index++;
      }
    return peaks;
  }

  private int getDelay(float[] in){
    int mpos = minDelay;
    float maxValue = in[minDelay];
    for (int delay = minDelay + 1; delay < maxDelay; delay++)
      if (in[delay] > maxValue) {
        mpos = delay;
        maxValue = in[delay];
      }
    return mpos;
  }

  private float ZCR(float[] in){
    float rate;
    int crossCount = 0;
    int sPoint, ePoint;
    sPoint = ePoint = 0;
    for (int i = 0; i < maxDelay - 1; i++) {
      if (in[i]*in[i+1]<0)
        crossCount ++;
      if (crossCount == 1)
        sPoint = i;
      ePoint = i;
    }
    if (crossCount > 1)
      rate = (float) (ePoint - sPoint) / (crossCount - 1);
    else if (crossCount == 1)
      rate = (float) sPoint / 2;
    else
      rate = 1e-10f;
    return rate;
  }


}
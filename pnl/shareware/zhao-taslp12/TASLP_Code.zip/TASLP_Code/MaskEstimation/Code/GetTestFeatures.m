function GetTestFeatures( ctl, nT, snr )
% Generate 6-dimensional pitch-based features for the test set. 
% Details of this 6-d features can be referred to Jin and Wang
% (2009): "A supervised learning approach to monaural segregation of
% reverberant speech" at
% http://www.cse.ohio-state.edu/~dwang/papers/Jin-Wang.taslp09.pdf
% ctl: a list of files
% nT: noise type, totally there are four types of noises incorporated in the
% training set of mask estimation
% snr: input SNR of the list of files, this is only used to locate the files,
% not used for mask estimation.

if strcmp(nT, 'babble')
    folderName = 'Babble';
else if strcmp(nT, 'whitenoise')
        folderName = 'WN';
    else if strcmp(nT, 'factory')
            folderName = 'Factory';
        else if strcmp(nT, 'ssn');
                folderName = 'SSN';
            else
                exit;
             end
        end
    end
end

fid = fopen(ctl);

while 1
    fileRoot = fgetl(fid);
    if ~ischar(fileRoot)
        break;
    end
    
    [p, n, v] = fileparts(fileRoot);
        
    mixName = ['/data/data1/zhaox/missData/AllSRE/Test/', folderName, '/', int2str(snr), 'dB/', n];
    pitch = mixName;

    cmd = ['!java GetFeatures ', mixName, ' ', pitch, '.pitch 64 ', mixName, '.fetEst1'];    % get normalized correlogram
    eval(cmd);

    cmd = ['!java GetBandEvFeatures ', mixName, ' ', pitch, '.pitch 64 ', mixName, '.evfetEst1'];  % get normalized envelope based correlogram
    eval(cmd);
end

fclose(fid);

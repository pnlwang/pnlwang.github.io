function trainAll(start, over, thr)
% Train a universal multi-layer perception (MLP) for initial voiced mask estimation
% start: first channel to be trained
% over: last channel to be trained
% thr: threshold for binarizing MLP output
% Wrtten by Zhaozhang Jin, and adapted by Xiaojia Zhao in Sep'10

if ~exist(start, 'var')
    start = 1;
end

if ~exist(over, 'var')
    over = 64;
end

if ~exist(thr, 'var')
    thr = 0;
end


N = 50;  % There are 50 test utterances for mask estimation
nChan = 64;


rvnet = cell(1,64);


Overall_fea = [];   Overall_feaBev = [];    Overall_target = []; 

noiseType = {'Babble', 'WN', 'Factory', 'SSN'};

%% Read Pitch and Place them together

for snr = -12 : 6 : 18      % SNR range from -12 dB to 18 dB
    for ty = 1 : 4
        folderName = noiseType{ty};
        fid = fopen(['CTL/', folderName, '_', int2str(snr), 'dB.txt']);
        count = 0;
        wholePitch = [];

        fprintf(1, 'reading pitches ...\n');

        for i = 1 : N
            fileRoot = fgetl(fid);
            if ~ischar(fileRoot)
                break;
            end
            [p, n, v] = fileparts(fileRoot);
            count = count + 1;
            pitch = load(['Data/Pitch/', n, '.pitch']); % load ideal pitch
            wholePitch = [wholePitch, pitch];
            nPitch(count) = length(pitch);
        end

        fclose(fid);

        fprintf(1, 'reading pitches done!\n');

        pitchRegion = find(wholePitch > 0);
        valid = pitchRegion;

        %% read features
        fea = [];   feaBev = [];    target = [];   % energy = [];

        fprintf(1, 'reading feature, energy and IBM files...');

        fid = fopen(['CTL/', folderName, '_', int2str(snr), 'dB.txt']);

        for i = 1 : N
            fileRoot = fgetl(fid);
            if ~ischar(fileRoot)
                break;
            end

            tmp = load([fileRoot, '.fet']);
            nFea(i)= size(tmp,1); 
            fea = [fea; tmp];    

            tmp = load([fileRoot, '.evfet']);
            nFeaBev(i) = size(tmp,1); 
            feaBev =[feaBev; tmp];    

            tmp = load([fileRoot, '.ibm']);
            tmp = tmp(:, 1:end-1)';
            nTarget(i) = size(tmp,1);
            target = [target; tmp];

        end

        fprintf(1, 'reading feature, energy and IBM files done!\n');

        sum(nFea-nPitch)
        sum(nFeaBev-nPitch)
        sum(nTarget-nPitch)

        confirm = sum(nFea-nPitch) + sum(nFeaBev-nPitch) + sum(nTarget-nPitch);
        if confirm~=0
            fprintf('confirmation failed, feature size incorrect.\n');
        end

        fea = fea(valid,1:end);
        feaBev = feaBev(valid,1:end);
        target = target(valid,:);
        size(target)
        size(fea)

        Overall_fea = [Overall_fea; fea];
        Overall_feaBev = [Overall_feaBev; feaBev];
        Overall_target = [Overall_target; target];
    end
end

ref = 0;
chan = start;

fea = Overall_fea;
feaBev = Overall_feaBev;
target = Overall_target;

    size(target)
    size(fea)
    
while chan <=over

    fprintf(1, 'Begin Training on Channel %d!\n', chan);

    ref = ref + 1;
    disp(chan); tic
    
    new = [fea(:,(chan-1)*3+[1:3]) feaBev(:,(chan-1)*3+[1:3]) target(:,chan)];
    new(:,3) = 1./(new(:,3)+1);
    new(:,6) = 1./(new(:,6)+1);

    P = new(:,[1:6])';
    
    T = new(:,7)';
    
    T(find(T==0)) = -1;
    
    n = length(T);
    seq = randperm(n);
    

    net = newff(P, T, 20,{'tansig' 'purelin'},'trainlm');   % initialize a feedforward neural network

    % you may want to change the tansig in the output latyer to purelin 2. logsig 3. trainscg
    net = init(net); 
    net.trainParam.show = 100;
    net.trainParam.lr = 0.05;
    net.trainParam.epochs = 100;
    net.trainParam.goal = 0.001;
    net.trainParam.mu_max=1e300;
    net.trainParam.min_grad=1e-500;
    net.divideFcn = '';
    
    [net,tr]=train(net,P(:,seq),T(:,seq));  % train the neural network with the above parameter settings
    
    
    rvnet{chan} = net;
    
    Y = sim(net,P); % simulate the neural network on the training set
    
    Y(find(Y>=thr))=1;
    Y(find(Y<thr))=-1;
    
    E = (Y-T) > 0;
    er = sum(E)/length(Y);  % false alarm error
    
    E = (Y-T) < 0;
    er = sum(E)/length(Y);  % miss error
    

    fprintf(1, 'Testing on Channel %d done!!\n', chan);
    
    chan = chan + 1;
    
    toc

end

if ~exist('net')
    mkdir('net');
end


save(['net/net_All_F', int2str(start), 'T', int2str(over), '.mat'],'rvnet');


end

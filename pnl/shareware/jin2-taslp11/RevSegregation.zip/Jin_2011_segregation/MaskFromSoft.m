function MaskFromSoft(fullFileName)


a = load([fullFileName,'.gp1.mdl1.smlpmsk']);
b = load([fullFileName,'.gp2.mdl1.smlpmsk']);
c = load([fullFileName,'.gp2.mdl2.smlpmsk']);

ep1 = load([fullFileName,'.gp1']);
ep2 = load([fullFileName,'.gp2']);

p1nr = find(ep1==0);
p2r = find(ep1>0 & ep2>0);

msk1 = a>.5;   msk1(p1nr,:) = 0;
msk1(p2r,:) = a(p2r,:)>b(p2r,:);

msk2 = a>.5;   msk2(p1nr,:) = 0;
msk2(p2r,:) = a(p2r,:)>c(p2r,:);

fp = fopen(strcat(fullFileName,'.mdl1.mlpmsk'),'w');
for tf = 1:size(a,1)
    fprintf(fp,'%d ',msk1(tf,:));
    fprintf(fp,'\n');
end
fclose(fp);

fp = fopen(strcat(fullFileName,'.mdl2.mlpmsk'),'w');
for tf = 1:size(a,1)
    fprintf(fp,'%d ',msk2(tf,:));
    fprintf(fp,'\n');
end
fclose(fp);
                

            


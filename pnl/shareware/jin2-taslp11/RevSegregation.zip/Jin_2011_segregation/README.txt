"Reverberant Speech Segregation Based on Multipitch Tracking and Classification",
IEEE Trans. Audio, Speech and Langugage Processing, vol. 19, pp. 2328-2337, 2011.

Matlab function to execute all steps described in this README file is:
"pitch_based_segregation.m"

Description of input and output for "pitch_based_segregation.m" are provided in the comments.


STEP ONE: pitch extraction from a mixture (16 kHz).
	java -jar JpitchHP_2pass.jar mixture.val mixture.p1 mixture.p2
	
STEP TWO: ideal grouping for pitch points. (assuming 1 is target pitch)
	
	*Noisy condition requires only one ideal pitch file .t1
	GroupPitchPointsNoise.jar mixture.p1 mixture.p2 mixture.t1 mixture.gp1 mixture.gp2
	
	*Two-talker condition requires two ideal pitch files .t1 and .t2
	GroupPitchPoints.jar mixture.p1 mixture.p2 mixture.t1 mixture.t2 mixture.gp1 mixture.gp2

STEP THREE: generate soft mark using each detected pitch contour

	*Soft mask using first pitch contour (gp1) and speech model (mdl1)
	GetMLPSoftMask.jar mixture.val mixture.gp1 T6f6MLP_EN_speech_c.net mixture.gp1.mdl1.smlpmsk
	
	*Soft mask using second pitch contour (gp2) and speech model (mdl1)
	GetMLPSoftMask.jar mixture.val mixture.gp2 T6f6MLP_EN_speech_c.net mixture.gp2.mdl1.smlpmsk
	
	*Soft mask using second pitch contour (gp2) and noise model (mdl2)
	GetMLPSoftMask.jar mixture.val mixture.gp2 T6f6MLP_EN_non_speech_c.net mixture.gp2.mdl2.smlpmsk

STEP FOUR: get binary masks for both hypotheses
	
	*This MATLAB script basically generates two binary masks using speech+speech model and speech+noise model
	MaskFromSoft.m
	mixture.gp1.mdl1.smlpmsk & mixture.gp2.mdl1.smlpmsk --> mixture.mdl1.mlpmsk
	mixture.gp1.mdl1.smlpmsk & mixture.gp2.mdl2.smlpmsk --> mixture.mdl2.mlpmsk

STEP FIVE: hypothesis test

	*This MATLAB script calculates probablistic scores for both models and writes into a file for future use. 
	chooseModel.m
	(model selection: 1 or 2)

STEP SIX: get the final binary mask using segmentation and grouping

	*This step picks the selected model and applies segmentation and grouping
	if (mdl1)	GNMLPe.jar mixture.val mixture.gp1 mixture.mdl1.mlpmsk mixture.mlpmskF
	if (mdl2)	GNMLPe.jar mixture.val mixture.gp1 mixture.mdl2.mlpmsk mixture.mlpmskF


function [msk,ep1,ep2] = pitch_based_segregation(signal,gtp,directory,fileName)


% [msk,ep1,ep2] = pitch_based_segregation(signal,gtp,directory,fileName)
%
% This function is written as a Matlab interface to Java/Matlab code that 
% that implements the algorithm described in Jin, Z. and Wang, D.L., 
% "Reverberant Speech Segregation Based on Multipitch Tracking and 
% Classification", IEEE Trans. Audio, Speech and Langugage Processing, 
% vol. 19, pp. 2328-2337, 2011.
% 
% Algorithm implementation by Zhaozhang Jin. See 'README.txt' for notes
% from Z. Jin on steps involved. This code simply executes the steps
% described in 'README.txt'.
% 
% Inputs:
%  signal           time domain (16 kHz) input signal (required)
%  gtp              ground truth pitch lags (integer values) for target (required) and interference (optional) 
%  directory        directory where files will be generated (optional, current directory is used if not specified)
%  fileName         file name used for generated files (optional)
%
% Outputs:
%  msk              binary time-frequency mask corresponding to target signal
%  ep1              estimated pitch points for target signal
%  ep2              estimated pitch points for interference signal
%
% John Woodruff, 7/25/2011


%%
if nargin < 3
    directory = cd;
end
if nargin < 4
    fileName = 'mixture';
end


%%
fullFileName = [directory,filesep,fileName];

%% write ground truth pitch points
% gtp should contain either one or two arrays of pitch lags (integer values, assuming 16 kHz signals)
% if one set of lags is provided, this is assumed to belong to the target source
% if two sets are provided, the first corresponds to target, the second corresponds to interference
N = min(size(gtp));
gtp = reshape(gtp,min(size(gtp)),max(size(gtp)));
for n = 1:N
    dlmwrite([fullFileName,'.t',num2str(n)],gtp(n,:),' ');
end


%% write input signal to directory
dlmwrite([fullFileName,'.val'],round(signal));

%% STEP ONE: pitch extraction from a mixture (16 kHz).
% java -jar JpitchHP_2pass.jar mixture.val mixture.p1 mixture.p2

cmd = ['!java -jar JpitchHP_2pass.jar ',fullFileName,'.val ',fullFileName,'.p1 ',fullFileName,'.p2'];
eval(cmd);


%% STEP TWO: ideal grouping for pitch points. (assuming 1 is target pitch)
if N == 1
	%*Noisy condition requires only one ideal pitch file .t1
	%GroupPitchPointsNoise.jar mixture.p1 mixture.p2 mixture.t1 mixture.gp1 mixture.gp2
	cmd = ['!java -jar GroupPitchPointsNoise.jar ',fullFileName,'.p1 ',fullFileName,'.p2 ',fullFileName,'.t1 ',fullFileName,'.gp1 ',fullFileName,'.gp2'];
    eval(cmd);
elseif N == 2
	%*Two-talker condition requires two ideal pitch files .t1 and .t2
	%GroupPitchPoints.jar mixture.p1 mixture.p2 mixture.t1 mixture.t2 mixture.gp1 mixture.gp2
	cmd = ['!java -jar GroupPitchPointsNoise.jar ',fullFileName,'.p1 ',fullFileName,'.p2 ',fullFileName,'.t1 ',fullFileName,'.t2 ',fullFileName,'.gp1 ',fullFileName,'.gp2'];
    eval(cmd);
end

%% STEP THREE: generate soft mask using each detected pitch contour

%*Soft mask using first pitch contour (gp1) and speech model (mdl1)
%GetMLPSoftMask.jar mixture.val mixture.gp1 T6f6MLP_EN_speech_c.net mixture.gp1.mdl1.smlpmsk
cmd = ['!java -jar GetMLPSoftMask.jar ',fullFileName,'.val ',fullFileName,'.gp1 T6f6MLP_EN_speech_c.net ',fullFileName,'.gp1.mdl1.smlpmsk'];
eval(cmd);

%*Soft mask using second pitch contour (gp2) and speech model (mdl1)
%GetMLPSoftMask.jar mixture.val mixture.gp2 T6f6MLP_EN_speech_c.net mixture.gp2.mdl1.smlpmsk
cmd = ['!java -jar GetMLPSoftMask.jar ',fullFileName,'.val ',fullFileName,'.gp2 T6f6MLP_EN_speech_c.net ',fullFileName,'.gp2.mdl1.smlpmsk'];
eval(cmd);

%*Soft mask using second pitch contour (gp2) and noise model (mdl2)
%GetMLPSoftMask.jar mixture.val mixture.gp2 T6f6MLP_EN_non_speech_c.net mixture.gp2.mdl2.smlpmsk
cmd = ['!java -jar GetMLPSoftMask.jar ',fullFileName,'.val ',fullFileName,'.gp2 T6f6MLP_EN_non_speech_c.net ',fullFileName,'.gp2.mdl2.smlpmsk'];
eval(cmd);

%% STEP FOUR: get binary masks for both hypotheses
%*This MATLAB script basically generates two binary masks using speech+speech model and speech+noise model 
%MaskFromSoft.m
%mixture.gp1.mdl1.smlpmsk & mixture.gp2.mdl1.smlpmsk --> mixture.mdl1.mlpmsk
%mixture.gp1.mdl1.smlpmsk & mixture.gp2.mdl2.smlpmsk --> mixture.mdl2.mlpmsk

MaskFromSoft(fullFileName);
                
                
%% STEP FIVE: hypothesis test
%*This MATLAB script calculates probablistic scores for both models and writes into a file for future use. 
%writeM1M2.m
%(model selection: 1 or 2)
mdl = chooseModel(fullFileName);

%% STEP SIX: get the final binary mask using segmentation and grouping
%*This step picks the selected model and applies segmentation and grouping
%	if (mdl1)	GNMLPe.jar mixture.val mixture.gp1 mixture.mdl1.mlpmsk mixture.mlpmskF
%	if (mdl2)	GNMLPe.jar mixture.val mixture.gp1 mixture.mdl2.mlpmsk mixture.mlpmskF
if mdl == 1
    cmd = ['!java -jar GNMLPe.jar ',fullFileName,'.val ',fullFileName,'.gp1 ',fullFileName,'.mdl1.mlpmsk ',fullFileName,'.mlpmskF'];
    eval(cmd);
elseif mdl == 0
    cmd = ['!java -jar GNMLPe.jar ',fullFileName,'.val ',fullFileName,'.gp1 ',fullFileName,'.mdl2.mlpmsk ',fullFileName,'.mlpmskF'];
    eval(cmd);
end
    
%% load data for output
ep1 = load([fullFileName,'.gp1']);
ep2 = load([fullFileName,'.gp2']);
msk = load([fullFileName,'.mlpmskF'])'==1;
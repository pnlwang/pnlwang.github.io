function mdl = chooseModel(fullFileName)



a = load([fullFileName,'.gp1.mdl1.smlpmsk']);
b = load([fullFileName,'.gp2.mdl1.smlpmsk']);
c = load([fullFileName,'.gp2.mdl2.smlpmsk']);

ep1 = load([fullFileName,'.gp1']);
ep2 = load([fullFileName,'.gp2']);

p2r = find(ep1>0 & ep2>0);

a = a(p2r,:);
b = b(p2r,:);
c = c(p2r,:);

indx = find(a<b&a<c);

if (length(p2r)==0)
    m1 = 0; m2 = 0;
else
    en = ones(size(a));
    
    m1 = (sum(log(b(indx)).*en(indx)))/sum(en(indx));
    m2 = (sum(log(c(indx)).*en(indx)))/sum(en(indx));
end

mdl = m1 >= m2;


#include <sstream>

#define EPS 2.2250738585072014e-308 /* min positive double value */
#define DBLMAX 1.7976931348623158e+308 /* max double value */

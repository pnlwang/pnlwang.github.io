function seg = onoffsegment(mixture,params)
% onset/offset segmentation (Hu & Wang'07), input signal will be converted
% to 20 kHz

mixFN = 'mixture.20k';    
if params.Srate~=20000     
    mixture20k = resample(mixture,20000,params.Srate);    
end
dlmwrite(mixFN, mixture20k, 'delimiter', ' ');

% cross-channel correlations
cmd = sprintf('!../function/getCorr %d mixture mixture.corr mixture.evCorr',params.nChan);
eval(cmd);            
% remove debug files
delete test.txt;
delete test1.txt;

% onset/offset segmentation
corrFN = sprintf('mixture.corr.%d.dat',params.nChan);
evCorrFN = sprintf('mixture.evCorr.%d.dat',params.nChan);
segFN = sprintf('mixture.%d.seg',params.nChan);
cmd = sprintf('!../function/segmentation %d mixture.20k %s %s %s',params.nChan,corrFN,evCorrFN,segFN);
eval(cmd);        

seg = binLoad(segFN,128,'int')';
This C++ program is a software implementation of the voiced speech segregation algorithm 
described in detail in the appendix of the following book chapter:

	Guoning Hu and DeLiang Wang (2006): "An auditory scene analysis approach to
	monaural speech segregation," In Topics in Acoustic Echo and Noise Control edited by
              E. H�nsler and  G. Schmidt. Springer, Heidelberg, pp. 485-515.

This algorithm is a simplified and slightly improved version of their 2004 IEEE Trans. on Neural Networks article. 

You may run the program with the following command:

	HuWang input output

	"input" is a text file that contains the waveform of input, i.e., a speech mixture.
	"output" is a text file that contains the waveform of output, i.e., resynthesized 
	target speech.


If you want to store the final speech stream, i.e., the binary mask for resynthesis (see the chapter 
for more details), you may run the program with the following command:

	HuWang input output mask        

	"mask" is a text file that stores the binary mask. Each line of the file corresponds to the
	time-frequency units in a time frame, from filter channel 1 to filter channel 128.


We have also included some sample files here. 
	"v3n3.dat": a mixture of a male voice and a "cocktail party" noise.
	"v3n3res.dat": the corresponding resynthesized speech.
	"v3n3mask.dat": the corresponding mask.


We have included the source codes here. This program is developed on Microsoft visual C++ 6.0. 
The 'HuWang.exe' file is built with the following settings:

	SAMPLING_FREQUENCY: 	the sampling frequency of input, which is set to be 16000
	MAX_SIG_LENGTH:	the maximum number of samples in input, which is set to be 200000
		(the actual size of input, can be smaller than the number, but cannot be larger).

If you need to change these numbers, specify them in the file "data.h", and then re-build 'HuWang.exe'.

We distribute this program freely, but please cite the paper if you have made any use of this program.


------------------------------------------------------------

Dr. Guoning Hu
Perception and Neurodynamics Lab.
The Ohio State University
2015 Neil Ave.
Columbus, OH 43210-1277, U.S.A.

Email: hu.117@osu.edu
Phone: 614-292-7402
URL: http://www.cse.ohio-state.edu/~hu
#include "tool.h"

void kaiserPara(float delta, float transBw, int &fLength, float &beta)
{
	float a, len;
	
	a= -20 * log10(delta);

	if (a <= 21) beta = 0;
	else if (a<= 50) beta = 0.5842 * pow(a-21, 0.4) + 0.07889 * (a-21);
	else beta = 0.1102 * (a - 8.7);

	len = (a - 7.95) / 14.36 / transBw;
	fLength = int(len);
	if ((len - fLength) < 0.5) fLength++;
	else fLength+=2;

	if (fLength%2 != 0) fLength++;
}
	
void kaiserLowPass(float *filter, int fLength, float beta, float wn)
{
	int tim, step;
	float k, sum;

	for (tim=0; tim<=fLength; tim++)
	{
		k = 2*tim/float(fLength) - 1;
		filter[tim] = bessi0( beta*sqrt(1- k*k)) / bessi0( beta );
	}

	sum=0;
	for (tim=0; tim<=fLength; tim++)
	{
		step = tim - fLength/2;
		if (step !=0) filter[tim] *= sin(wn * PI * step) / PI / step;
		else filter[tim] *= wn;

		sum += filter[tim];
	}
}

void kaiserBandPass(float *filter, int fLength, float beta, float wc, float wn)
{
	int tim;

	kaiserLowPass(filter, fLength, beta, wn);

	for (tim=0; tim<=fLength; tim++)
		filter[tim] *= 2 * cos((tim-fLength/2) * wc * PI);
}

float bessi0(float x)
{
	float ax,ans;
	float y;

	ax = fabs(x);
	if (ax < 3.75)
	{
		y = x/3.75;
		y *= y;
		ans = 1.0 + y * (3.5156229 + y * (3.0899424 + y * (1.2067492 + y * (0.2659732 + y * (0.360768e-1 + y*0.45813e-2)))));
	}
	else
	{
		y = 3.75 / ax;
		ans = (exp(ax) / sqrt(ax)) * (0.39894228 + y * (0.1328592e-1 + y * (0.225319e-2 + y * (-0.157565e-2 + y * (0.916281e-2 + y * (-0.2057706e-1 + y * (0.2635537e-1 + y * (-0.1647633e-1 + y * 0.392377e-2))))))));
	}
	return ans;
}

void fft(float *inputR, float *inputI, int N, float direct)
{
	long sigL, i, j, k, n, period, twoPeriod;
	float tmpR, tmpI, uR, uI, wR, wI;

	sigL = long(pow(2, N));

	j = 1;
	for(i=1; i<sigL; i++)
	{
		if(i < j)
		{
			tmpR = inputR[j-1];
			tmpI = inputI[j-1];

			inputR[j-1] = inputR[i-1];
			inputI[j-1] = inputI[i-1];

			inputR[i-1] = tmpR;
			inputI[i-1] = tmpI;
		}

		k = sigL/2;
		while (k < j){ j -=  k;	k /= 2;	}
		j += k;
	}

	for(n=1; n<=N; n++ )
    {  
		twoPeriod = long(pow(2, n));
        period = twoPeriod/2;
        uR = 1.0; 
        uI = 0.0; 
        wR = cos( PI/period ); 
        wI = -1.0 * sin( PI/period * direct);

        for(j=0; j<period; j++ ) 
        {  
			for(i=j; i<sigL; i+=twoPeriod)
			{
				tmpR = inputR[i+period]*uR - inputI[i+period]*uI;
                tmpI = inputR[i+period]*uI + inputI[i+period]*uR;
				
				inputR[i+period] = inputR[i] - tmpR; 
				inputI[i+period] = inputI[i] - tmpI; 
				inputR[i] += tmpR ; 
				inputI[i] += tmpI; 
			}
			tmpR = uR*wR - uI*wI; 
			tmpI = uR*wI + uI*wR; 
			uR = tmpR; 
			uI = tmpI; 
		} 
	} 
}

float findMax(float *input, int d1, int d2)
{
	float mp=input[d1];

	for(int d=d1+1; d<d2; d++)
	{
		if (input[d]>mp) mp=input[d];
	}

	return(mp);
}
/* HuWang model for monaural speech segregation
   Original code for gammatone filtering and the Meddis model of auditory transduction
   is developed at Univ. of Sheffield and adapted by Guoning Hu and DeLiang Wang, 2003. 

   This software was developed in Microsoft Visual C++ 6.0 */

#include "pitch.h"
#include <math.h>
#include <string.h>

int SigLength, NumFrame, *Unit[2], SegMark[MAX_NUMBER_SEGMENT], numSegment;
float Input[MAX_SIG_LENGTH], *Output;

feature *CorrLgm;
filter BPass;

segment Seg[MAX_NUMBER_SEGMENT];
gammaTone fChan[NUMBER_CHANNEL];

float ReadInput(char *filename)
{
	FILE *fp;
	SigLength=0;

	if ((fp = fopen(filename, "r")) == NULL){
		printf("Cannot open input file!\n");
		exit(0);
	}

	while (!feof(fp))
	{
		float f;
		fscanf(fp, "%f\n", &f);
		Input[SigLength]=f;
		SigLength++;
	}
	fclose(fp);

	float sumE=0;
	for(int n=0; n<SigLength; n++)
		sumE += Input[n]*Input[n];

	sumE /= float(SigLength);

	//for(n=0; n<SigLength; n++)
	//	Input[n] *= 1000/sqrt(sumE);

	return(1000/sqrt(sumE));
}

void initialData(void)
{
	NumFrame = SigLength/OFFSET;

	Output = new float[SigLength];

	CorrLgm = new feature[NumFrame];
	
	Unit[0] = new int[long(NumFrame * NUMBER_CHANNEL)];
	Unit[1] = new int[long(NumFrame * NUMBER_CHANNEL)];
}

void clearData(void)
{
	delete Output;
	
	delete CorrLgm;

	delete Unit[0];
	delete Unit[1];
}

void initialFilter()
{
	BPass.nFFT = 4096*4;
	BPass.nOrder = 14;
	BPass.overlap = 1024;

	BPass.rValue = new float[BPass.nFFT];
	BPass.iValue = new float[BPass.nFFT];
	BPass.inputR = new float[BPass.nFFT];
	BPass.inputI = new float[BPass.nFFT];

	for(int n=0; n<BPass.nFFT; n++)
	{
		BPass.rValue[n]=0;
		BPass.iValue[n]=0;
	}

	float beta;
	
	kaiserPara(0.01, 50 / float(SAMPLING_FREQUENCY), BPass.fLength, beta);		
	kaiserBandPass(BPass.rValue, BPass.fLength, beta, (FBP1+FBP2) / float(SAMPLING_FREQUENCY), (FBP2-FBP1) / float(SAMPLING_FREQUENCY));

	// FFT of the filter. Note that bandpass filtering is implemented using FFT
	fft(BPass.rValue, BPass.iValue, BPass.nOrder, 1);
}

void deleteFilter(void)
{
	delete BPass.rValue;
	delete BPass.iValue;
	delete BPass.inputR;
	delete BPass.inputI;
}

void main(int argc, char *argv[])
{	
	FILE *ofp, *mfp;
	int chan, frame;
	char filename[255];

	// Open input and output files, read input mixture
	if( (argc != 3) && (argc !=4) )
	{
		printf("Ussage: HuWang inputFile outputFile or HuWang inputFile outputFile maskFile\n");
		exit(0);
	}

	if ((ofp = fopen(argv[2], "w")) == NULL)
	{
		printf("Cannot open output file!\n");
		exit(0);
	}

	if(argc==4)
	{
		if ((mfp = fopen(argv[3], "w")) == NULL)
		{
			printf("Cannot open mask file!\n");
			exit(0);
		}
		sprintf(filename, "%s", argv[4]);
	}

	float ratio=ReadInput(argv[1]);

	// Initialize data and filter
	initialData();
	initialFilter();

	NumFrame = SigLength/OFFSET;
	printf("%d samples %d frames\n", SigLength, NumFrame);

	// Auditory Periphery and feature extraction
	printf(" Auditory periphery and feature extraction");

	gammaTone fChan[NUMBER_CHANNEL];
	AudiPeriph(Input, SigLength, fChan, BPass, CorrLgm);

	// Segmentation
	numSegment = Segmentation(CorrLgm, NumFrame, fChan, Unit, SegMark, Seg);
		
	// Pitch Determination
	printf("\n Pitch determination");
	PitchDtm(CorrLgm, NumFrame, Unit, SegMark, numSegment, Seg);
	
	// Final Grouping
	printf("\n Final Grouping");
	Grouping(CorrLgm, NumFrame, Unit, SegMark, numSegment, Seg);
	
	// Resynthesis
	printf("\n Resynthesis");

	for(int n=0; n<SigLength; n++)
		Input[n] *=2;

	resynthesis(Input, SigLength, fChan, CorrLgm, Output);

	// Save resynthesized target
	for(n=0; n<SigLength; n++)
		fprintf(ofp, "%f\n", Output[n]/ratio);
	fclose(ofp);

	// Save the estiamted target stream
	if(argc == 4)
	{
		for (frame=0; frame<NumFrame; frame++)
		{
			for(chan=0; chan<NUMBER_CHANNEL; chan++)
			{
				CorrLgm[frame].stream[chan] = (CorrLgm[frame].stream[chan]>0) ? 1:0;		
				fprintf(mfp, "%d ", CorrLgm[frame].stream[chan]);
			}
			fprintf(mfp, "\n");
		}

		fclose(mfp);
	}

	clearData();
	deleteFilter();
	printf("\n");
}
#include "group.h"

void unitLabel(feature *corrLgm, int numFrame, float theta1, float theta2)
{
	// Label T-F units using periodicity criterion for type-1 unit
	// and AM criterion for other unit
	int frame, chan;
	float pRatio;

	for(frame=0; frame<numFrame; frame++)
	{
		int p=corrLgm[frame].pitch;

		if (p>0)
		{
			for(chan=0; chan<NUMBER_CHANNEL; chan++)	
			{
				if (corrLgm[frame].mark[chan]==1)
				{
					pRatio = corrLgm[frame].acf[chan][p] / findMax(corrLgm[frame].acf[chan], MIN_DELAY, MAX_DELAY);
				
					 if ( pRatio>theta1 ) corrLgm[frame].label[chan]=1;
					 else corrLgm[frame].label[chan]=0;
				}

				else
				{
					 pRatio = corrLgm[frame].acfEv[chan][p] / findMax(corrLgm[frame].acfEv[chan], MIN_DELAY, MAX_DELAY);
				
					 if ( pRatio>theta2 ) corrLgm[frame].label[chan]=1;
					 else corrLgm[frame].label[chan]=0;
				}
			}
		}

		else
		{
			for(chan=0; chan<NUMBER_CHANNEL; chan++)
				corrLgm[frame].label[chan]=0;
		}
	}
}

void Grouping(feature *corrLgm, int numFrame, int *Unit[2], int *segMark, int numSegment, segment *seg)
{
	// Label T-F units
	unitLabel(corrLgm, numFrame, THETAT1, THETAT2);

	// Label segment
	obtainSegInfo(seg, numSegment, Unit, segMark, corrLgm, numFrame);

	segmentLabel(seg, numSegment);

	// Group segments
	streaming(corrLgm, numFrame, seg, numSegment, Unit, segMark);

	// Remove contiguous T-F regions all labeled as interference from estimated target
	rmLZeroSegs(corrLgm, numFrame, seg, numSegment, Unit, segMark);
	
	// Group neighboring T-F units labeled as target into the estimated target
	develope(corrLgm, numFrame);
}

void obtainSegInfo(segment *seg, int numSegment, int *Unit[2], int *segMark, feature *corrLgm, int numFrame)
{
	int i, frame, chan;
	int n, nUnit;

	nUnit = 0;
	for(i=0; i<numSegment; i++)
	{
		for(frame=0; frame<numFrame; frame++){ 
			seg[i].count[0][frame] = 0;  
			seg[i].count[1][frame] = 0; 
		}

		seg[i].sFrame = numFrame;  
		seg[i].eFrame = 0;

		for(n=nUnit; n<segMark[i]; n++)
		{
			chan = Unit[0][n];  frame = Unit[1][n];
	
			if (seg[i].sFrame> frame) seg[i].sFrame = frame;
			if (seg[i].eFrame < frame) seg[i].eFrame = frame;

			float eng = corrLgm[frame].eng[chan];
			//if ( (chan==(NUMBER_CHANNEL-1)) || (chan==0) ) eng /= 2;
			//else if ( (corrLgm[frame].cross[chan]<=THETAC) && (corrLgm[frame].cross[chan-1]<=THETAC)
			//	   && (corrLgm[frame].crossEv[chan]<=THETAC) && (corrLgm[frame].crossEv[chan-1]<=THETAC) )
			//	   eng /= 2;

			if ( corrLgm[frame].label[chan] > 0 ) seg[i].count[0][frame] += eng;
			else seg[i].count[1][frame] += eng;
		}

		seg[i].number = segMark[i] - nUnit;
		nUnit = segMark[i];
	}
}
	
void segmentLabel(segment *seg, int numSegment)
{
	int i, frame;
	float number1, number2;

	for(i=0; i<numSegment; i++)
	{
		number1 = 0;
		number2 = 0;

		for(frame=seg[i].sFrame; frame<=seg[i].eFrame; frame++)
		{
			number1 += seg[i].count[0][frame];
			number2 += seg[i].count[1][frame];
		}

		if (number1 > (number1+number2)*0.5) seg[i].label = 1;
		else seg[i].label = -1;
	}
}

void streaming(feature *corrLgm, int numFrame, segment *seg, int numSegment, int *Unit[2], int *segMark)
{
	int frame, chan, i, j, nUnit;

	for(frame=0; frame<numFrame; frame++)
		for(chan=0; chan<NUMBER_CHANNEL; chan++)
			corrLgm[frame].stream[chan]=0;

	nUnit = 0;
	for(i=0; i<numSegment; i++)
	{
		for(j=nUnit; j<seg[i].number+nUnit; j++)
		{
			chan = Unit[0][j]; frame = Unit[1][j];

			corrLgm[frame].stream[chan] = seg[i].label;
		}
		nUnit = j;
	}
}

void rmLZeroSegs(feature *corrLgm, int numFrame, segment *seg, int numSegment, int *Unit[2], int *segMark)
{
	int frame, chan, nUnit, i, n;
	mark *m, *cross;

	// Select all the T-F units labeled as interference in the estimated taret 
	m = new mark[numFrame];
	cross = new mark[numFrame];

	for(frame=0; frame<numFrame; frame++)
		for(chan=0; chan<NUMBER_CHANNEL; chan++)
		{
			m[frame].value[chan] = ( (corrLgm[frame].stream[chan] == 1) && ( corrLgm[frame].label[chan]==0) ) ? 1 : 0;
			cross[frame].value[chan] = 1;
		}


	// Generate segments of the selected T-F units
	numSegment = formSegment(m, cross, numFrame, Unit, segMark);
	
	// Remove segments longer than MIN_SEG_LENGTH from the estimated target
	obtainSegInfo(seg, numSegment, Unit, segMark, corrLgm, numFrame);
	
	nUnit = 0;
	for(i=0; i<numSegment; i++)
	{
		if ( (seg[i].eFrame - seg[i].sFrame + 1) >= MIN_SEG_LENGTH )
		{
			for(n=nUnit; n<seg[i].number+nUnit; n++)
			{
				chan = Unit[0][n]; frame = Unit[1][n];

				corrLgm[frame].stream[chan] = -1;
			}
		}
		nUnit += seg[i].number;
	}

	delete m;
	delete cross;
}
	
void develope(feature *corrLgm, int numFrame)
{
	int chan, frame, judge;
	
	judge=1;
	while(judge)
	{
		judge=0;

		for(frame=0; frame<numFrame; frame++)
			for(chan=0;chan<NUMBER_CHANNEL; chan++)
			{
				if(corrLgm[frame].stream[chan] == 1)
				{
					if(frame > 0)
					{
						if( (corrLgm[frame-1].label[chan]==1) && (corrLgm[frame-1].stream[chan] == 0) )
						{
							corrLgm[frame-1].stream[chan] = 1;
							judge++;
						}
					}

					if(frame < (numFrame-1))
					{
						if((corrLgm[frame+1].label[chan]==1) && (corrLgm[frame+1].stream[chan] == 0))
						{
							corrLgm[frame+1].stream[chan] = 1;
							judge++;
						}
					}

					if(chan > 0)
					{
						if((corrLgm[frame].label[chan-1]==1) && (corrLgm[frame].stream[chan-1] == 0))
						{
							corrLgm[frame].stream[chan-1] = 1;
							judge++;
						}
					}

					if(chan < (NUMBER_CHANNEL-1))
					{
						if((corrLgm[frame].label[chan+1]==1) && (corrLgm[frame].stream[chan+1] == 0))
						{
							corrLgm[frame].stream[chan+1] = 1;
							judge++;
						}
					}
				}
			}
	}
}
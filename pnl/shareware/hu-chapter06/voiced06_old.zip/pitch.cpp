#include "pitch.h"

void PitchDtm(feature *corrLgm, int numFrame, int *Unit[2], int *segMark, int numSegment, segment *seg)
{
	int *reliable;
	int lFrame, rFrame, sStreak, eStreak;

	reliable = new int[numFrame];

	// Find global pitch
	globalPitch(corrLgm, numFrame);

	// Preliminary grouping
	initGroup(corrLgm, numFrame, Unit, segMark, numSegment, seg);


	// Estimate pitch from the estimated target
	findPitch(corrLgm, numFrame, lFrame, rFrame);
	
	// Label T-F units with the estimated pitch
	unitLabel(corrLgm, numFrame, THETAP, 1);

	// Label segment
	obtainSegInfo(seg, numSegment, Unit, segMark, corrLgm, numFrame);

	segmentLabel(seg, numSegment);

	// Estimated target stream accoridng segment label
	streaming(corrLgm, numFrame, seg, numSegment, Unit, segMark);


	// Estimate pitch from the estimated target
	findPitch(corrLgm, numFrame, lFrame, rFrame);

	// Check pitch reliability
	for(int frame=0; frame<numFrame; frame++)
		reliable[frame] = 0;

	checkPitch(corrLgm, lFrame, rFrame, reliable, sStreak, eStreak);

	// Re-estimate the pitch periods for the frames before the longest reliable pitch streak
	leftDevelope(corrLgm, reliable, sStreak, lFrame);
			
	// Re-estimate the pitch periods for the frames after the longest reliable pitch streak
	rightDevelope(corrLgm, reliable, eStreak, rFrame);

	//Linear inteprolation for unreliable pitch
	for(frame=0; frame<numFrame; frame++)
	{
		if (reliable[frame]==0) corrLgm[frame].pitch = 0;
	}

	linearEstimate(corrLgm, lFrame, rFrame);
	
	delete reliable;
}

void globalPitch(feature *corrLgm, int numFrame)
{
	float sumCorr[MAX_DELAY], mp;
	int chan, frame, delay, p;

	for(frame=0; frame<numFrame; frame++)
	{
		for(delay=0; delay<MAX_DELAY; delay++)
		{
			sumCorr[delay]=0;

			for(chan=0; chan<NUMBER_CHANNEL; chan++)
			{
				sumCorr[delay] += corrLgm[frame].acf[chan][delay];
			}
		}

		p = MIN_DELAY;
		mp = sumCorr[MIN_DELAY];
		for(delay=MIN_DELAY+1; delay<MAX_DELAY; delay++)
		{
			if (sumCorr[delay] > mp) { mp = sumCorr[delay]; p = delay; }
		}

		corrLgm[frame].pitch = p;
	}
}

void initGroup(feature *corrLgm, int numFrame, int *Unit[2], int *segMark, int numSegment, segment *seg)
{
	int seed, frame, chan;

	// Label T-F units with the global pitch
	unitLabel(corrLgm, numFrame, THETAP, 1);

	// Label segment
	obtainSegInfo(seg, numSegment, Unit, segMark, corrLgm, numFrame);
	
	seed = relationship(seg, numSegment);

	// Preliminary grouping according the longest segment
	streaming(corrLgm, numFrame, seg, numSegment, Unit, segMark);

	// Only T-F units with mark 1 and within the time frames of the longest segment will be used for the following pitch estimation
	for(chan=0; chan<NUMBER_CHANNEL; chan++)
	{
		for(frame=0; frame<seg[seed].sFrame; frame++)
			corrLgm[frame].stream[chan]=0;

		for(frame=seg[seed].eFrame+1; frame<numFrame; frame++)
			corrLgm[frame].stream[chan]=0;

		for(frame=seg[seed].sFrame; frame<=seg[seed].eFrame; frame++)
		{
			if (corrLgm[frame].mark[chan]!=1) corrLgm[frame].stream[chan]=0;
		}
	}
}
	
//------------------------------------------------------------------------------------------------
int relationship(segment *seg, int numSegment)
{
	int i, frame, s, e;
	float number1, number2, n1, n2, n3, n4;

	//Find the seed segment that has more frames labeled as dominant source than any other segment
	int seed = findSeedSeg(seg, numSegment);
	
	// Determine whether a segment agrees with the longest segment. 
	// A segment agrees with the longest segment if they share the same label for more than 2/3 of their overlapping frames.
	for(i=0; i<numSegment; i++)
	{
		s = seg[seed].sFrame;
		if( s < seg[i].sFrame ) s = seg[i].sFrame;

		e = seg[seed].eFrame;
		if( e > seg[i].eFrame ) e = seg[i].eFrame;

		number1=0; number2=0;

		for(frame=s; frame<=e; frame++)
		{
			n1 = seg[seed].count[0][frame];
			n2 = seg[seed].count[1][frame];

			n3 = seg[i].count[0][frame];
			n4 = seg[i].count[1][frame];

			if((n1 > n2) && (n3 > n4)) number1++;
			else if((n1 < n2) && (n3 < n4)) number1++;
			else number2++;
		}

		if (number1 > (number2*2) ) seg[i].label = seg[seed].label;
		else seg[i].label = -seg[seed].label;
	}

	return(seed);
}

int findSeedSeg(segment *seg, int numSegment)
{
	// Find the seed segment that have more than half of its total frames are labeled as dominant source.
	int length=0;
	int seed=0;

	for (int i=0; i<numSegment; i++)
	{
		int count=0;
		for(int frame=seg[i].sFrame; frame<=seg[i].eFrame; frame++)
		{
			if (seg[i].count[0][frame] > seg[i].count[1][frame]) count ++;
		}	

		if ( count>length )
		{
			length = count;
			seed = i;
		}
	}

	seg[seed].label = 1;

	return(seed);
}

//------------------------------------------------------------------------------------------------	
void findPitch(feature *corrLgm, int numFrame, int &lFrame, int &rFrame)
{
	int frame, chan;
	float n1, n2;
	
	lFrame = numFrame;
	for(frame=0; frame<numFrame; frame++)
	{
		// Estimate pitch from the estimated target
		corrLgm[frame].pitch=sumAuto(corrLgm[frame].stream, corrLgm[frame].acf, MIN_DELAY, MAX_DELAY);
	   
		// Check the reliability of the esimated pitch with constraint 1
		if (corrLgm[frame].pitch>0)
		{
			int p = corrLgm[frame].pitch;

			if (frame<lFrame) lFrame=frame;
			rFrame = frame;

			n1=0; n2=0;

			for(chan=0; chan<NUMBER_CHANNEL; chan++)
			{
				if(corrLgm[frame].stream[chan] > 0)
				{
					n1 ++;
										
					float pRatio = corrLgm[frame].acf[chan][p] / findMax(corrLgm[frame].acf[chan], MIN_DELAY, MAX_DELAY);
					if ( pRatio>THETAP ) n2 ++;
				}
			}
		        
			if ((n2*2) <= n1) corrLgm[frame].pitch=0;
		}
	}
}

int sumAuto(int m[NUMBER_CHANNEL], float acg[NUMBER_CHANNEL][MAX_DELAY], int lDelay, int rDelay)
{
	int chan, delay, pos;
	float mvalue;
	
	pos=0;
	mvalue=0;
	for (delay=lDelay; delay<rDelay; delay++)
	{	
		float sum=0;
		for(chan=0; chan<NUMBER_CHANNEL; chan++)
		{
			if(m[chan] > 0) sum += acg[chan][delay];
		}
		
		if(sum > mvalue)
		{ 
			mvalue=sum; 
			pos=delay; 
		}
	}

	return(pos);
}
	
void checkPitch(feature *corrLgm, int lFrame, int rFrame, int *reliable, int &sStreak, int &eStreak)
{
	// Check the reliability of estimated pitch according to constraint 2
	int frame, sFrame, eFrame, tframe;

	// Find the longest reliable pitch streak
	sStreak = 0; eStreak = 0;
	frame = sFrame = eFrame = lFrame;

	while(frame<rFrame)
	{
		if( pitchCrn(corrLgm[frame].pitch, corrLgm[frame+1].pitch) ) eFrame=frame+1;

		else
		{
		    if( (eFrame - sFrame) > (eStreak - sStreak) )
			{
				sStreak = sFrame; eStreak = eFrame;
			}
        
			sFrame=frame+1;
			eFrame=frame+1;
		}
	   
		frame++;
	}

	if( (eFrame - sFrame) > (eStreak - sStreak) )
	{
		sStreak = sFrame; eStreak = eFrame;
	}
            
	for(tframe=sStreak; tframe<=eStreak; tframe++)
		reliable[tframe] = 1;
}

int pitchCrn(float d1, float d2)
{
	if ( (d1==0) || (d2==0) ) return(0);

	float lowerP, upperP;

	if (d1>d2)
	{
		lowerP = (1-THETAPITCH) * d1;
		upperP = (1+THETAPITCH) * d2;
	}
	else
	{
		lowerP = (1-THETAPITCH) * d2;
		upperP = (1+THETAPITCH) * d1;
	}
	
	if( (d1>lowerP) && (d1<upperP) && (d2>lowerP) && (d2<upperP) ) return(1);
	else return(0);
}

void leftDevelope(feature *corrLgm, int *reliable, int sStreak, int lFrame)
{
	// Re-estimate the pitch periods for the frames before the sStreak
	int chanMark[2][NUMBER_CHANNEL], frame, chan;

	for(chan=0; chan<NUMBER_CHANNEL; chan++)
	{
		chanMark[0][chan]=0; chanMark[1][chan]=0;
	}
	
	frame = sStreak-1;
	while(frame >= lFrame)
	{
		if (reliable[frame+1]>0) markChan(corrLgm, frame+1, chanMark[0]);
	 
		if( pitchCrn(corrLgm[frame].pitch, corrLgm[frame+1].pitch) ) reliable[frame] = 1;
		else{
            int number = 0;
			for(chan=0; chan<NUMBER_CHANNEL; chan++)
			{
				if (corrLgm[frame].stream[chan]>0) chanMark[1][chan] = chanMark[0][chan];
				else chanMark[1][chan] = 0;

				number += chanMark[1][chan];
			}

			if(number>0)
			{
				float k1 = 0.65 * float(corrLgm[frame+1].pitch + 1) - 1; 
				if (k1 < MIN_DELAY) k1 = MIN_DELAY; 
				
				float k2 = 1.55 * float(corrLgm[frame+1].pitch + 1) - 1; 
				if (k2 > (MAX_DELAY-1) ) k2 = MAX_DELAY-1;
            
				int pitch = sumAuto(chanMark[1], corrLgm[frame].acf, int(k1), int(k2)); 
                    
				if (pitchCrn(pitch, corrLgm[frame+1].pitch))
				{
					corrLgm[frame].pitch = pitch, 
					reliable[frame] = 1;
				}
                else corrLgm[frame].pitch = corrLgm[frame+1].pitch; 
			}
			else corrLgm[frame].pitch = corrLgm[frame+1].pitch; 
		}
		
		frame--;
	}
}

void rightDevelope(feature *corrLgm, int *reliable, int eStreak, int rFrame)
{
	// Re-estimate the pitch periods for the frames after the eStreak
	int chanMark[2][NUMBER_CHANNEL], frame, chan;
	for(chan=0; chan<NUMBER_CHANNEL; chan++)
	{
		chanMark[0][chan]=0; chanMark[1][chan]=0;
	}
	
	frame = eStreak+1;
	while(frame <= rFrame)
	{
		if (reliable[frame-1]>0) markChan(corrLgm, frame-1, chanMark[0]);

		if( pitchCrn(corrLgm[frame].pitch, corrLgm[frame-1].pitch) ) reliable[frame] = 1;
		else
		{
            int number=0; 
			for(chan=0; chan<NUMBER_CHANNEL; chan++)
			{
				if (corrLgm[frame].stream[chan]>0) chanMark[1][chan] = chanMark[0][chan];
				else chanMark[1][chan] = 0;

				number += chanMark[1][chan];
			}

			if(number)
			{
				float k1 = 0.65 * float(corrLgm[frame-1].pitch + 1) - 1; 
				if (k1 < MIN_DELAY) k1 = MIN_DELAY; 
				
				float k2 = 1.55 * float(corrLgm[frame-1].pitch + 1) - 1; 
				if (k2 > (MAX_DELAY-1) ) k2 = MAX_DELAY-1;
            
				int pitch = sumAuto(chanMark[1], corrLgm[frame].acf, int(k1), int(k2)); 
			
				if (pitchCrn(pitch, corrLgm[frame-1].pitch))
				{
					corrLgm[frame].pitch = pitch;
					reliable[frame] = 1;
				}
                else corrLgm[frame].pitch = corrLgm[frame-1].pitch; 
			}
			else corrLgm[frame].pitch = corrLgm[frame-1].pitch; 
		}
		
		frame++;
	}
}

void linearEstimate(feature *corrLgm, int lFrame, int rFrame)
{
	int frame, pPitch, pRFrame;

	frame=lFrame; 
	pPitch=0; 
	pRFrame=-1;
	while(frame <= rFrame)
	{
		int p=corrLgm[frame].pitch;
		if(p>0)
		{
			if( (pPitch==0) && (pRFrame>=0) )
			{
			    float step = float(p-corrLgm[pRFrame].pitch) / float(frame-pRFrame);
				
				for(int tf=pRFrame+1; tf<frame; tf++)
				{
					float pitch = float(corrLgm[pRFrame].pitch) + step * float(tf-pRFrame);
					
					corrLgm[tf].pitch = int(pitch);
					if ( (pitch - corrLgm[tf].pitch) >= 0.5) corrLgm[tf].pitch++;
				}
			}
			pRFrame=frame;
        }
		pPitch = p;
	   
		frame++;
	}
}

void markChan(feature *corrLgm, int frame, int *chanMark)
{
	int p=corrLgm[frame].pitch;

	// A channel is marked if the T-F unit at current frame belongs to estimated target stream and is labelas as target
	for(int chan=0; chan<NUMBER_CHANNEL; chan++)
	{
		chanMark[chan]=0;

		if (corrLgm[frame].stream[chan] > 0)
		{
			float pRatio = corrLgm[frame].acf[chan][p] / findMax(corrLgm[frame].acf[chan], MIN_DELAY, MAX_DELAY);
					
			if( pRatio>THETAP ) chanMark[chan]=1;
		}
	}
}
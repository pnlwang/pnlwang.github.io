#include "data.h"

#define BW_CORRECTION       1.019      			/* ERB bandwidth correction 4th order */

// Data size of FFT in calculating autocorrelation
#define NFFT_ACF				1024				
#define ORDERFFT_ACF			10

// A gammatone filter
struct gammaTone
{
	float cf, bw;					// Center frequency and bandwidth
	float midEarCoeff;				// Midear coefficient, which normalizing the amplitude of the filter response
	float p[4];						// The real part of the filter response
	float q[4];						// The imaginary part of the filter response
	float delay;					// The average delay of the filter
};


// Parameters of a middle model
#define MIDDLE_EAR_SIZE 29			
#define DB 60.0

struct middleEar
{
	float f[MIDDLE_EAR_SIZE], af[MIDDLE_EAR_SIZE], bf[MIDDLE_EAR_SIZE], tf[MIDDLE_EAR_SIZE];
};


// Parameters of the Meddis' model of auditory nerve transduction
#define MED_Y 5.05
#define MED_G 2000.0
#define MED_L 2500.0
#define MED_R 6580.0
#define MED_X 66.31
#define MED_A 3.0
#define MED_B 300.0
#define MED_H 48000.0
#define MED_M 1.0


// Calculate features of the input mixture
// Input: input - input mixture
//		  sigLength - number of samples of the input signal
//		  fChan - a gammatone filterbank, which is initialized in this program
//		  bPFilter - a specified bandpass filter for envelope extraction
// Output: corrLgm - data structure that stores features
void AudiPeriph(float *input, int sigLength, gammaTone *fChan, filter bPFilter, feature *corrLgm);

float HzToERBRate(float Hz); // convert frequency scale from Hz to ERBRate;

float ERBRateToHz(float ERBRate); // convert frequency scale from ERBRate to Hz

// Implementing gammatone filtering
// Input: input - input mixture
//		  sigLength - number of samples of the input
//		  fChan - a data structure containing parameters of the gammatone filter
// Output: output - output filter response
void gammaToneFilter(float *input, int sigLength, gammaTone fChan, float *output);  // gammatone filtering

// parameters of equal-loudness functions from BS3383,"Normal equal-loudness level
// contours for pure tones under free-field listening conditions", table 1.
middleEar initMiddleEar();

// Input: freq - input frequency
//        loudFunc - table stroing the equal-loudness functions at some frequency points
// Return: the loudness of frequency freq
float loudnessLevelInPhons(float freq, middleEar loudFunc);


// Meddis' auditory nerve transdusction
// Input: input - input signal (filter response)
//		  sigLength - number of samples of the input
// Output: output - output signal (auditory nerve firing rate)
void hairCell(float *input, int sigLength, float *output);

// Calculate the features (energy and autocorrelation) in a give channel
// Input: gOut - filter response of that channel
//		  hc - auditory nerve firing rate of that channel
//		  hev - envelope of the auditory nerve firing rate
//		  sigLength - number of samples of the input
//		  winsize - window size of autocorrelation
//		  chan - channel index
// Output: corrLgm - data structures storing the features
void computeFeature(float *gOut, float *hc, float *hev, int sigLength, int winsize, int chan, feature *corrLgm);

// Calculate the cross-channel correlation
// Input: corrLgm - data structures storing the autocorrelation in 'acf' and 'acfEv'
//		  numFrame - total number of frames
// Output: corrLgm - data structures storing the cross-channel correlation in 'cross' and 'crossEv'
void crossCorr(feature *corrLgm, int numFrame); // compute cross-channel correlation

// Extract the envelope through half-wave rectification and bandpass filtering
// Input: input - input signal
//		  sigLength - number of samples of the input
//		  bPFilter - bandpass filter
// Output: output - envelope
void envelope(float *input, int sigLength, filter bPFilter, float *output);


// Compute autocorrelation using FFT
// Input: input - input signal (auditory nerve firing rate, and its envelope)
//		  sigLength - number of samples of the input
//		  winsize - window size of autocorrelation
//		  frame - index of time frame
// Output: acf - autocorrelation
void fftACF(float *input, int sigLength, int winsize, int frame, float *acf);


// resynthesize of target signal
// Input: input - input mixture
//		  sigLength - number of samples
//		  fChan - data structure of gammatone filters
//		  corrLgm - data structures storing the mask value for each unit (stream)
// Output: resynthesized target
void resynthesis(float *input, int sigLength, gammaTone *fChan, feature *corrLgm, float *output);
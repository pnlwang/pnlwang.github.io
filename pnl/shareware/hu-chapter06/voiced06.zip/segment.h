#include "feature.h"

#define THETAC	0.99		//Threshold for cross-channel correlation
#define THETAF	1000		//Frequency below which the harmonics of target speech are generally resolved

#define MAX_NUMBER_SEGMENT	10000  //Maximum number of segments

// Data structure for temporary storing unit marks or labels
struct mark							
{
	int value[NUMBER_CHANNEL];
};

// Data structure for storing segment informatin 
struct segment
{
	int sFrame, eFrame; // starting and ending time frame

	int number;  // total number of units
	int label;	 // segment label

	float *count[2];  // total energy at each frame for units labeled as target and that for units lable as interference
};

// Generate segments according to cross-channel correlation
// Input: corrLgm - data structure storing cross-channel correlation (cross, corssEv)
//		  numFrame - total number of frames
//		  fChan - data structure stroing the center frequency of gammatone filters (cf)
// Output: Unit - recording the frame index and channel index of units in each segment
//				  units in the same segment are in continuous in index 
//         segMark - the index where a new segment starts
//		   seg - data structure stores segment information
// Return: the total number of segments
int Segmentation(feature *corrLgm, int numFrame, gammaTone *fChan, int *Uint[2], int *segMark, segment *seg);

// Mark units according to the cross-channel correlation
// Input: corrLgm - data structure storing cross-channel correlation (cross, corssEv)
//		  numFrame - total number of frames
//		  fChan - data structure stroing the center frequency of gammatone filters (cf)
// Output: corrLgm - data structure storing unit mark (mark)
void unitMark(feature *corrLgm, int numFrame, gammaTone *fChan);

// Forming segments by mergeing neighboring units with the same mark
// Input: m - unit marks
//		  numFrame - total number of frames
// Output: Unit - recording the frame index and channel index of units in each segment
//				  units in the same segment are in continuous in index 
//         segMark - the index where a new segment starts
// Return: the total number of segments
int formSegment(mark *m, mark *cross, int NumFrame, int *Unit[2], int *segMark);

// For a particular unit (mark k, indexed by n in Unit), find neighboring units with the same mark (k).
// Then add these units into Unit, and change the marks of these units (stored in m) to 0
// m - unit marks
// numFrame - total number of frames
// Unit - recording the frame index and channel index of units in each segment
//		  units in the same segment are in continuous in index 	
// n - the index of the particular unit in Unit
// k - the mark of the unit
// numUnit - the current total units recorded in Unit
void search(mark *m, mark *cross, int NumFrame, int *Unit[2], int n, int k, int &numUnit);

// Allocate memory for the data structure storing segment information
// Input: seg - the data structure storing segment information
//		  numSegment - total number of segments
//		  numFrame - total number of frame
void initialSeg(segment *seg, int numSegment, int numFrame);

// Free the memory of the data structure storing segment information
// Input: seg - the data structure storing segment information
//		  numSegment - total number of segments
void deleteSeg(segment *seg, int numSegment);
#include "segment.h"

#define THETAT1  0.85	//Threshold for labeling T-F units with periodicity criterion
#define THETAT2	 0.7	//Threshold for labeling T-F units with AM criterion

#define MIN_SEG_LENGTH	4	//Threshold for remove contiguous T-F regions all labeled as interference from estimated target

// Label T-F units using periodicity criterion and AM criterion
void unitLabel(feature *corrLgm, int numFrame, float theta1, float theta2);

// Grouping segments accorinding to unit labels
void Grouping(feature *corrLgm, int numFrame, int *Unit[2], int *segMark, int numSegment, segment *seg);

// Collect information for each segment
void obtainSegInfo(segment *seg, int numSegment, int *Unit[2], int *segMark, feature *corrLgm, int numFrame);

// Label segment
void segmentLabel(segment *seg, int numSegment);

// Grouping segments
void streaming(feature *corrLgm, int numFrame, segment *seg, int numSegment, int *Unit[2], int *segMark);

// Remove contiguous T-F regions all labeled as interference from estimated target
void rmLZeroSegs(feature *corrLgm, int numFrame, segment *seg, int numSegment, int *Unit[2], int *segMark);

// Group neighboring T-F units labeled as target into the estimated target
void develope(feature *corrLgm, int numFrame);
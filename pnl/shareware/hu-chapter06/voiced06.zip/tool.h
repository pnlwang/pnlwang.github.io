#include <math.h>

#define PI (3.1415926535897932384626433832795)

void kaiserPara(float delta, float transBw, int &fLength, float &beta);
	
void kaiserLowPass(float *filter, int fLength, float beta, float wn);

void kaiserBandPass(float *filter, int fLength, float beta, float wc, float wn);

float bessi0(float x);

void fft(float *inputR, float *inputI, int N, float direct);

float findMax(float *input, int d1, int d2);

#include "group.h"

#define THETAP	0.95	//Parameter for labeling T-F unit
#define THETAPITCH 0.2  //Constraint of pitch smoothness

// Pitch determination
// Input: corrLgm - data structure storing features
//		  numFrame - total number of frames
//		  Unit - recording the frame index and channel index of units in each segment
//				 units in the same segment are in continuous in index 
//        segMark - the index where a new segment starts
//		  numSegment - the total number of segments
//		  seg - data structure stores segment information		
// Output: corrLgm - data structure storing pitch (pitch). A frame is considered not pitched if the corresponding value is 0
void PitchDtm(feature *corrLgm, int numFrame, int *Unit[2], int *segMark, int numSegment, segment *seg);

// Estimate global pitch
// Input: corrLgm - data structure storing autocorrelation (acf)
//		  numFrame - total number of frames
// Output: corrLgm - data structure storing global pitch (pitch)
void globalPitch(feature *corrLgm, int numFrame);

// Preliminary grouping
// Input: corrLgm - data structure storing features
//		  numFrame - total number of frames
//		  Unit - recording the frame index and channel index of units in each segment
//				 units in the same segment are in continuous in index 
//        segMark - the index where a new segment starts
//		  numSegment - the total number of segments
//		  seg - data structure stores segment information		
// Output: corrLgm - data structure storing stream label of each T-F unit (stream)
void initGroup(feature *corrLgm, int numFrame, int *Unit[2], int *segMark, int numSegment, segment *seg);

// Input: seg - data structure stores segment information		
//		  numSegment - the total number of segments
// Output: seg - data structure storing label of segment (label)
int relationship(segment *seg, int numSegment);

// Input: seg - data structure stores segment information		
//		  numSegment - the total number of segments
// Return: the index of the seed segment that has more frames labeled as dominant source than other segments
int findSeedSeg(segment *seg, int numSegment);

// Pitch estimation from estiamted target
// Input: seg - data structure stores segment information		
//		  numSegment - the total number of segments
// Output: lFrame, rFrame - the begining and end of the estimated pitch contour
void findPitch(feature *corrLgm, int numFrame, int &lFrame, int &rFrame);

// Pitch estimation from summary correlation at a particular frame
// Input: m - channel mark indicating for each channel whether it is considered for pitch estimation or not
//		  acf - autocorrelation
//		  lDelay, rDelay - the plausible pitch range
// Return: the estimated pitch
int sumAuto(int m[NUMBER_CHANNEL], float acf[NUMBER_CHANNEL][MAX_DELAY], int lDelay, int rDelay);

// Check pitch reliability
// Input: corrLgm - data structure storing features
//		  lFrame, rFrame - begining and end of the estimated pitch contour
// Output: reliable - recording the reliability of estimated pitch
//		   sStreak, eStreak - begining and end of the longest reliable pitch streak
void checkPitch(feature *corrLgm, int lFrame, int rFrame, int *reliable, int &sStreak, int &eStreak);

// Check the smoothness of estimated pitch at two consecutive frames according to constraint 2
// Input: d1, d2 - estimated pitch at two consecutive frames
// Reture: 0 - d1 and d2 violates constraint 2
//		   1 - d1 and d2 satisfies constraint 2 reliable - storing temporary pitch value
int pitchCrn(float d1, float d2);

// Re-estimate the pitch periods for the frames before the longest reliable pitch streak
// Input: corrLgm - data structure storing features
//		  reliable - recording the reliability of estimated pitch
//		  sStreak - begining frame of the longest reliable pitch streak
//		  lFrame - begining frame of the estimated pitch contour
// Output: corrLgm - data structure storing estimated pitch (pitch)
void leftDevelope(feature *corrLgm, int *reliable, int sStreak, int lFrame);

// Re-estimate the pitch periods for the frames after the longest reliable pitch streak
// Input: corrLgm - data structure storing features
//		  reliable - recording the reliability of estimated pitch
//		  eStreak - ending frame of the longest reliable pitch streak
//		  rFrame - ending frame of the estimated pitch contour
// Output: corrLgm - data structure storing estimated pitch (pitch)
void rightDevelope(feature *corrLgm, int *reliable, int eStreak, int rFrame);

// Linear inteprolation of unreliable pitch
// Input: corrLgm - data structure storing reliable estimated pitch (pitch)
//		  lFrame, rFrame - starting and ending frame of the estimated pitch contour
// Output: corrLgm - data structure storing estimated pitch
void linearEstimate(feature *corrLgm, int lFrame, int rFrame);

// Mark channels where the corresponding T-F units is labeled as target and is included in the estimated target stream at a particular frame
// Input: corrLgm - data structure storing features
//		  frame - frame index
// Output: chanMark - channel mark
void markChan(feature *corrLgm, int frame, int *chanMark);
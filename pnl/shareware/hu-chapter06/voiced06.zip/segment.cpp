#include "segment.h"

int Segmentation(feature *corrLgm, int numFrame, gammaTone *fChan, int *Unit[2], int *segMark, segment *seg)
{
	int frame, chan;

	// Determine the mark of each unit
	unitMark(corrLgm, numFrame, fChan);

	// Initialize a temporary matrix that stores the mark of units.
	mark *m2, *cross;
	m2 = new mark[numFrame];
	cross = new mark[numFrame];

	for(frame=0; frame<numFrame; frame++)
		for(chan=0; chan<NUMBER_CHANNEL; chan++)
		{
			m2[frame].value[chan] = corrLgm[frame].mark[chan];
			if (m2[frame].value[chan]==1) cross[frame].value[chan] = (corrLgm[frame].cross[chan]>THETAC) ? 1:0;
			else if (m2[frame].value[chan]==2) cross[frame].value[chan] = (corrLgm[frame].crossEv[chan]>THETAC) ? 2:0;
			else cross[frame].value[chan] = 0;
		}

	// Generate segments
	int numSegment = formSegment(m2, cross, numFrame, Unit, segMark);

	delete m2;
	delete cross;

	// Initialize the structure (seg) for storing segment information
	initialSeg(seg, numSegment, numFrame);

	return(numSegment);
}

void unitMark(feature *corrLgm, int numFrame, gammaTone *fChan)
{
	int frame, chan;

	for(frame=0; frame<numFrame; frame++)
		for(chan=0; chan<NUMBER_CHANNEL; chan++)
			corrLgm[frame].mark[chan]=0;

	for(frame=0; frame<numFrame; frame++)
		for(chan=0; chan<(NUMBER_CHANNEL-1); chan++)
		{
			// Mark unit 1 if the cross-channel correlation of response is higher than THETAC
			if (corrLgm[frame].cross[chan]>THETAC)
			{ 
				corrLgm[frame].mark[chan]=1; corrLgm[frame].mark[chan+1]=1;
			}

			// Otherwise, mark unit 2 if the cross-channel correlation of response envelope is 
			// higher than THETAC and the correspond channel is centered above THETAF.
			else if ( (corrLgm[frame].crossEv[chan]>(THETAC)) && (fChan[chan].cf>THETAF))
			{
				if (corrLgm[frame].mark[chan]==0)
				{ 
					corrLgm[frame].mark[chan]=2; corrLgm[frame].mark[chan+1]=2;
				}
			}
		}
}

int formSegment(mark *m, mark *cross, int numFrame, int *Unit[2], int *segMark)
{
	int frame, chan, numSegment;
	int numUnit, activeUnit;
	
	numSegment = 0;
	numUnit = 0;
	for(frame=1; frame<(numFrame-1); frame++)
		for(chan=0; chan<NUMBER_CHANNEL; chan++)
		{
			if( m[frame].value[chan]>0)  // Start with a T-F unit with mark 1 or 2
			{		
				int k=m[frame].value[chan];
				Unit[0][numUnit] = chan;
				Unit[1][numUnit] = frame;
				m[frame].value[chan]=0;

				activeUnit = numUnit;
				numUnit ++;

				// Iteratively find neighboring T-F units with the same label and store them in Unit
				// In addition set their mark stored in m to 0
				while(activeUnit < numUnit)
				{
					search(m, cross, numFrame, Unit, activeUnit, k, numUnit);
					activeUnit ++;
				}

				segMark[numSegment] = numUnit;
				numSegment ++;
			}
		}

	return(numSegment);
}

void search(mark *m, mark *cross, int numFrame, int *Unit[2], int n, int k, int &numUnit)
{				
	int chan, frame;

	chan = Unit[0][n];
	frame = Unit[1][n];
	if(frame > 0) 
	{
		// For each T-F unit, check its four neighbors
		if ( (m[frame-1].value[chan]==k) && (cross[frame].value[chan]==k) && (cross[frame-1].value[chan]==k) )
		{
			Unit[0][numUnit] = chan;
			Unit[1][numUnit] = frame-1;

			numUnit ++;
			m[frame-1].value[chan] = 0;
		}
	}
		
	if(frame < (numFrame-1) )
	{
		if( (m[frame+1].value[chan]==k) && (cross[frame].value[chan]==k) && (cross[frame+1].value[chan]==k) )
		{
			Unit[0][numUnit] = chan;
			Unit[1][numUnit] = frame+1;

			numUnit ++;
			m[frame+1].value[chan] = 0;
		}
	}

	if(chan > 0)
	{
		if( (m[frame].value[chan-1]==k) && (cross[frame].value[chan-1]==k))
		{
			Unit[0][numUnit] = chan-1;
			Unit[1][numUnit] = frame;

			numUnit ++;
			m[frame].value[chan-1] = 0;
		}
	}
						
	if(chan < (NUMBER_CHANNEL-1))
	{
		if( (m[frame].value[chan+1]==k) && (cross[frame].value[chan]==k) )
		{
			Unit[0][numUnit] = chan+1;
			Unit[1][numUnit] = frame;

			numUnit ++;
			m[frame].value[chan+1]=0;
		}
	}
}

void initialSeg(segment *seg, int numSegment, int numFrame)
{	
	for(int i=0; i<numSegment; i++)
	{
		seg[i].count[0] = new float[numFrame];  
		seg[i].count[1] = new float[numFrame];
	}
}

void deleteSeg(segment *seg, int numSegment)
{	
	for(int i=0; i<numSegment; i++)
	{
		delete seg[i].count[0];
		delete seg[i].count[1];
	}
}	

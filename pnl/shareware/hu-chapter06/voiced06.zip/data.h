#ifndef NUMBER_CHANNEL

#include "tool.h"
#include <stdio.h>
#include <stdlib.h>


#define SAMPLING_FREQUENCY		16000			// Sampling frequency
#define MAX_SIG_LENGTH			200000			// Maxmimun length of input - 10 s


// Frequency range and number of gammatone filters of the filterbank
#define NUMBER_CHANNEL  128      		        
#define MINCF			80						
#define MAXCF			5000


// Plausible F0 range [80 Hz, 500 Hz]
#define	MAX_DELAY	(SAMPLING_FREQUENCY/80)	
#define MIN_DELAY	(SAMPLING_FREQUENCY/500)


// 20-ms time frames with 10-ms overlapping between consecutive frames.
#define WINDOW	    (SAMPLING_FREQUENCY/50)		
#define OFFSET		(WINDOW/2)


// Passband for envelope extraction
#define FBP1		50
#define FBP2		550

// Features at each time frame: energy, autocorrelation of response, cross-channel correlation of response
//								autocorrelation of response envelope, cross-channel correlation of response envelope
//								pitch, unit mark, unit label, the stream an unit belongs to
struct feature{
	float eng[NUMBER_CHANNEL];					

	float acf[NUMBER_CHANNEL][MAX_DELAY];		
	float cross[NUMBER_CHANNEL];
	
	float acfEv[NUMBER_CHANNEL][MAX_DELAY];
	float crossEv[NUMBER_CHANNEL];

	int pitch;

	int mark[NUMBER_CHANNEL];
	int label[NUMBER_CHANNEL];
	int stream[NUMBER_CHANNEL];
};

// A lowpass or a bandPass filter
struct filter
{
	int fLength, nOrder, nFFT, overlap;
	
	float *rValue;
	float *iValue;

	float *inputR;
	float *inputI;
};


float ReadInput(char *filename);		// Read input mixture

void initialData(void);				// Allocate memory for data representing features and segments

void clearData(void);				// Free memory

void initialFilter(void);			// Initialize the value of the bandPass filter

void deleteFilter(void);			// Free the memory of the bandPass filter


#endif

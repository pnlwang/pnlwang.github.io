This C++ program is used for producing the results presented in the following article:

	Guoning Hu and DeLiang Wang (2004): "Monaural speech segregation based on pitch 
	tracking and amplitude Modulation," IEEE Transactions on Neural Networks, vol. 15, pp. 1135-1150 .

Note that you can find a later version which is simplified and slightly improved from the following chapter:

	Guoning Hu and DeLiang Wang (2006): "An auditory scene analysis approach to
	monaural speech segregation," In Topics in Acoustic Echo and Noise Control edited by
              E. H�nsler and  G. Schmidt. Springer, Heidelberg, pp. 485-515.

The above chapter contains a detailed description of the algorithm in the appendix. We recommend
that you use that program, which can be found at:

	http://www.cse.ohio-state.edu/pnl/software.html


To run this program, a number of constants need to be specified in the file "huwang.h":

	SAMPLING_FREQUENCY: 	the sampling frequency of input
	MAX_SIG_LENGTH:	the maximum number of samples in input (the actual size of input 
	can be smaller than the number, but cannot be larger).

	
You may run the program with the following command:

		huwang input output

	"input" is a text file that contains the waveform of input, i.e., a speech mixture.
	"output" is a text file that contains the waveform of output, i.e., resynthesized 
	target speech.


If you want to store the final speech stream, i.e., the binary mask for resynthesis (see the article 
for more details), you may run the program with the following command:

		huwang input output mask        

	"mask" is a text file that stores the binary mask. Each line of the file corresponds to the
	time-frequency units in a time frame, from filter channel 1 to filter channel 128.


We have also included some sample files here. 
	"v3n3.dat": the mixture used in the paper as an illustrative example: 
		which is a voiced utterance mixed with a "cocktail party" noise.
	"v3n3res.dat": the corresponding resynthesized speech.
	"v3n3mask.dat": the corresponding mask.

This program is developed on Microsoft visual C++ 6.0. We distribute this program freely, 
but please cite the paper if you have made any use of this program.


--------------------------------------------------------------

Dr. Guoning Hu
Perception and Neurodynamics Lab.
The Ohio State University
2015 Neil Ave.
Columbus, OH 43210-1277, U.S.A.

Email: hu.117@osu.edu
Phone: 614-292-7402
URL: http://www.cse.ohio-state.edu/~hu

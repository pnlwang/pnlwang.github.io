function y = sigmoid_grad(x)

y = x.*(1-x);